// swapAmriceAdressount: wei
class DexPriceAddress {
  constructor(routerAddress, factoryAddress, price) {
    this.price = price;
    this.factoryAddress = factoryAddress;
    this.routerAddress = routerAddress;
  }

}

module.exports = DexPriceAddress;
