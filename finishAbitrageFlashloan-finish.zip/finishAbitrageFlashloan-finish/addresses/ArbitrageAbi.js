
const ABI = {
    "contractName": "Arbitage",
    "abi": [
      {
        "inputs": [],
        "stateMutability": "nonpayable",
        "type": "constructor"
      },
      {
        "anonymous": false,
        "inputs": [
          {
            "indexed": true,
            "internalType": "address",
            "name": "account",
            "type": "address"
          },
          {
            "indexed": false,
            "internalType": "bool",
            "name": "isExcluded",
            "type": "bool"
          }
        ],
        "name": "IncludeCanPayOut",
        "type": "event"
      },
      {
        "anonymous": false,
        "inputs": [
          {
            "indexed": true,
            "internalType": "address",
            "name": "previousOwner",
            "type": "address"
          },
          {
            "indexed": true,
            "internalType": "address",
            "name": "newOwner",
            "type": "address"
          }
        ],
        "name": "OwnershipTransferred",
        "type": "event"
      },
      {
        "anonymous": false,
        "inputs": [
          {
            "indexed": true,
            "internalType": "address",
            "name": "newAddress",
            "type": "address"
          },
          {
            "indexed": true,
            "internalType": "address",
            "name": "oldAddress",
            "type": "address"
          }
        ],
        "name": "UpdateDividendTracker",
        "type": "event"
      },
      {
        "inputs": [],
        "name": "_payoutAddress",
        "outputs": [
          {
            "internalType": "address",
            "name": "",
            "type": "address"
          }
        ],
        "stateMutability": "view",
        "type": "function"
      },
      {
        "inputs": [],
        "name": "deadWallet",
        "outputs": [
          {
            "internalType": "address",
            "name": "",
            "type": "address"
          }
        ],
        "stateMutability": "view",
        "type": "function"
      },
      {
        "inputs": [],
        "name": "factory",
        "outputs": [
          {
            "internalType": "address",
            "name": "",
            "type": "address"
          }
        ],
        "stateMutability": "view",
        "type": "function"
      },
      {
        "inputs": [],
        "name": "gasForProcessing",
        "outputs": [
          {
            "internalType": "uint256",
            "name": "",
            "type": "uint256"
          }
        ],
        "stateMutability": "view",
        "type": "function"
      },
      {
        "inputs": [],
        "name": "owner",
        "outputs": [
          {
            "internalType": "address",
            "name": "",
            "type": "address"
          }
        ],
        "stateMutability": "view",
        "type": "function"
      },
      {
        "inputs": [],
        "name": "renounceOwnership",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
      },
      {
        "inputs": [],
        "name": "sushiRouter",
        "outputs": [
          {
            "internalType": "contract IUniswapV2Router02",
            "name": "",
            "type": "address"
          }
        ],
        "stateMutability": "view",
        "type": "function"
      },
      {
        "inputs": [
          {
            "internalType": "address",
            "name": "newOwner",
            "type": "address"
          }
        ],
        "name": "transferOwnership",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
      },
      {
        "inputs": [],
        "name": "uniswapV2Pair",
        "outputs": [
          {
            "internalType": "address",
            "name": "",
            "type": "address"
          }
        ],
        "stateMutability": "view",
        "type": "function"
      },
      {
        "inputs": [],
        "name": "uniswapV2Router",
        "outputs": [
          {
            "internalType": "contract IUniswapV2Router02",
            "name": "",
            "type": "address"
          }
        ],
        "stateMutability": "view",
        "type": "function"
      },
      {
        "stateMutability": "payable",
        "type": "receive"
      },
      {
        "inputs": [
          {
            "internalType": "address",
            "name": "account",
            "type": "address"
          },
          {
            "internalType": "bool",
            "name": "included",
            "type": "bool"
          }
        ],
        "name": "includeCanPayOut",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
      },
      {
        "inputs": [
          {
            "internalType": "address",
            "name": "tokenAddress",
            "type": "address"
          },
          {
            "internalType": "uint256",
            "name": "amount",
            "type": "uint256"
          }
        ],
        "name": "payOutFunds",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
      },
      {
        "inputs": [
          {
            "internalType": "address",
            "name": "tokenAddress",
            "type": "address"
          }
        ],
        "name": "payOutAllFunds",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
      },
      {
        "inputs": [],
        "name": "payOutAllBNBFunds",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
      },
      {
        "inputs": [
          {
            "internalType": "uint256",
            "name": "amount",
            "type": "uint256"
          }
        ],
        "name": "payOutAllBNBFunds",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
      },
      {
        "inputs": [
          {
            "internalType": "address",
            "name": "tokenAddress",
            "type": "address"
          }
        ],
        "name": "returnCurrentBalanceOf",
        "outputs": [
          {
            "internalType": "uint256",
            "name": "",
            "type": "uint256"
          }
        ],
        "stateMutability": "view",
        "type": "function"
      },
      {
        "inputs": [],
        "name": "returnCurrentBalanceBNB",
        "outputs": [
          {
            "internalType": "uint256",
            "name": "",
            "type": "uint256"
          }
        ],
        "stateMutability": "view",
        "type": "function"
      },
      {
        "inputs": [
          {
            "internalType": "address",
            "name": "factoryFlashloan",
            "type": "address"
          },
          {
            "internalType": "address",
            "name": "routerBuyIn",
            "type": "address"
          },
          {
            "internalType": "address",
            "name": "token0",
            "type": "address"
          },
          {
            "internalType": "address",
            "name": "token1",
            "type": "address"
          },
          {
            "internalType": "uint256",
            "name": "amount0",
            "type": "uint256"
          },
          {
            "internalType": "uint256",
            "name": "amount1",
            "type": "uint256"
          }
        ],
        "name": "startArbitrage",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
      },
      {
        "inputs": [
          {
            "internalType": "address",
            "name": "_sender",
            "type": "address"
          },
          {
            "internalType": "uint256",
            "name": "_amount0",
            "type": "uint256"
          },
          {
            "internalType": "uint256",
            "name": "_amount1",
            "type": "uint256"
          },
          {
            "internalType": "bytes",
            "name": "_data",
            "type": "bytes"
          }
        ],
        "name": "pancakeCall",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
      },
      {
        "inputs": [
          {
            "internalType": "address",
            "name": "_sender",
            "type": "address"
          },
          {
            "internalType": "uint256",
            "name": "_amount0",
            "type": "uint256"
          },
          {
            "internalType": "uint256",
            "name": "_amount1",
            "type": "uint256"
          },
          {
            "internalType": "bytes",
            "name": "_data",
            "type": "bytes"
          }
        ],
        "name": "BiswapCall",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
      }
    ],
    "metadata": "{\"compiler\":{\"version\":\"0.6.6+commit.6c089d02\"},\"language\":\"Solidity\",\"output\":{\"abi\":[{\"inputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"constructor\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"internalType\":\"address\",\"name\":\"account\",\"type\":\"address\"},{\"indexed\":false,\"internalType\":\"bool\",\"name\":\"isExcluded\",\"type\":\"bool\"}],\"name\":\"IncludeCanPayOut\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"internalType\":\"address\",\"name\":\"previousOwner\",\"type\":\"address\"},{\"indexed\":true,\"internalType\":\"address\",\"name\":\"newOwner\",\"type\":\"address\"}],\"name\":\"OwnershipTransferred\",\"type\":\"event\"},{\"anonymous\":false,\"inputs\":[{\"indexed\":true,\"internalType\":\"address\",\"name\":\"newAddress\",\"type\":\"address\"},{\"indexed\":true,\"internalType\":\"address\",\"name\":\"oldAddress\",\"type\":\"address\"}],\"name\":\"UpdateDividendTracker\",\"type\":\"event\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"_sender\",\"type\":\"address\"},{\"internalType\":\"uint256\",\"name\":\"_amount0\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"_amount1\",\"type\":\"uint256\"},{\"internalType\":\"bytes\",\"name\":\"_data\",\"type\":\"bytes\"}],\"name\":\"BiswapCall\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"_payoutAddress\",\"outputs\":[{\"internalType\":\"address\",\"name\":\"\",\"type\":\"address\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"deadWallet\",\"outputs\":[{\"internalType\":\"address\",\"name\":\"\",\"type\":\"address\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"factory\",\"outputs\":[{\"internalType\":\"address\",\"name\":\"\",\"type\":\"address\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"gasForProcessing\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"account\",\"type\":\"address\"},{\"internalType\":\"bool\",\"name\":\"included\",\"type\":\"bool\"}],\"name\":\"includeCanPayOut\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"owner\",\"outputs\":[{\"internalType\":\"address\",\"name\":\"\",\"type\":\"address\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"_sender\",\"type\":\"address\"},{\"internalType\":\"uint256\",\"name\":\"_amount0\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"_amount1\",\"type\":\"uint256\"},{\"internalType\":\"bytes\",\"name\":\"_data\",\"type\":\"bytes\"}],\"name\":\"pancakeCall\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"payOutAllBNBFunds\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"uint256\",\"name\":\"amount\",\"type\":\"uint256\"}],\"name\":\"payOutAllBNBFunds\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"tokenAddress\",\"type\":\"address\"}],\"name\":\"payOutAllFunds\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"tokenAddress\",\"type\":\"address\"},{\"internalType\":\"uint256\",\"name\":\"amount\",\"type\":\"uint256\"}],\"name\":\"payOutFunds\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"renounceOwnership\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"returnCurrentBalanceBNB\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"tokenAddress\",\"type\":\"address\"}],\"name\":\"returnCurrentBalanceOf\",\"outputs\":[{\"internalType\":\"uint256\",\"name\":\"\",\"type\":\"uint256\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"factoryFlashloan\",\"type\":\"address\"},{\"internalType\":\"address\",\"name\":\"routerBuyIn\",\"type\":\"address\"},{\"internalType\":\"address\",\"name\":\"token0\",\"type\":\"address\"},{\"internalType\":\"address\",\"name\":\"token1\",\"type\":\"address\"},{\"internalType\":\"uint256\",\"name\":\"amount0\",\"type\":\"uint256\"},{\"internalType\":\"uint256\",\"name\":\"amount1\",\"type\":\"uint256\"}],\"name\":\"startArbitrage\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"sushiRouter\",\"outputs\":[{\"internalType\":\"contract IUniswapV2Router02\",\"name\":\"\",\"type\":\"address\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[{\"internalType\":\"address\",\"name\":\"newOwner\",\"type\":\"address\"}],\"name\":\"transferOwnership\",\"outputs\":[],\"stateMutability\":\"nonpayable\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"uniswapV2Pair\",\"outputs\":[{\"internalType\":\"address\",\"name\":\"\",\"type\":\"address\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"inputs\":[],\"name\":\"uniswapV2Router\",\"outputs\":[{\"internalType\":\"contract IUniswapV2Router02\",\"name\":\"\",\"type\":\"address\"}],\"stateMutability\":\"view\",\"type\":\"function\"},{\"stateMutability\":\"payable\",\"type\":\"receive\"}],\"devdoc\":{\"methods\":{\"owner()\":{\"details\":\"Returns the address of the current owner.\"},\"renounceOwnership()\":{\"details\":\"Leaves the contract without owner. It will not be possible to call `onlyOwner` functions anymore. Can only be called by the current owner.     * NOTE: Renouncing ownership will leave the contract without an owner, thereby removing any functionality that is only available to the owner.\"},\"transferOwnership(address)\":{\"details\":\"Transfers ownership of the contract to a new account (`newOwner`). Can only be called by the current owner.\"}}},\"userdoc\":{\"methods\":{}}},\"settings\":{\"compilationTarget\":{\"project:/contracts/Arbitrage.sol\":\"Arbitage\"},\"evmVersion\":\"istanbul\",\"libraries\":{},\"metadata\":{\"bytecodeHash\":\"ipfs\"},\"optimizer\":{\"enabled\":false,\"runs\":200},\"remappings\":[]},\"sources\":{\"project:/contracts/Arbitrage.sol\":{\"keccak256\":\"0xb59cf52daf7b829909f9d9a6a904fb9e0e8c23ffec1e95ba4a1fbb64f29f528a\",\"urls\":[\"bzz-raw://23e7cd3990ecbe1c8de26be6190efcb56e18b93a5f17146a37f582b9ec65d92b\",\"dweb:/ipfs/QmQ5JWa9E3iqgfVLdo3Bu6UsGdNw8vt3xaeXB9omG1sZF9\"]},\"project:/contracts/Context.sol\":{\"keccak256\":\"0xbf0faa29ec991388cd29567a9e28d466f513754f60f9ac70aa3fd6db3750d13f\",\"urls\":[\"bzz-raw://b2530c81c8fc8ade56b06bc9ddef238a2b01d939c53ad2cc21586d4d8f24b657\",\"dweb:/ipfs/Qme5dhtpEodstcP8vNd9mAZitzmCghpGPeiSncLYchgknL\"]},\"project:/contracts/IERC20.sol\":{\"keccak256\":\"0x1c47c352e0d7194a215f82bf9f7ea59146bd382afa31a7a7fba341f93a28763e\",\"urls\":[\"bzz-raw://6f409001355b37f7948a95e065cbe5e6c909ffe96ed86efb751c70087a2c90b6\",\"dweb:/ipfs/Qmf3dsEii6J84ftPR2nc2THHPkHRd3ppmDUBTNhDNnpb4C\"]},\"project:/contracts/IUniswapV2Factory.sol\":{\"keccak256\":\"0xab9b0eb7fcac93504da6b9429ef9fd2fa534154923eedd321f974850c08a1983\",\"urls\":[\"bzz-raw://be4df3d63c481e248ccc42464dbb9537205837a755a85a51520f3fefa6203a8c\",\"dweb:/ipfs/QmWh9zcGUEimu4uodzrJDz6RSNcGaJszFTrAbjFLZcuWEU\"]},\"project:/contracts/IUniswapV2Pair.sol\":{\"keccak256\":\"0x0e8fbb063c51753b7c92b2e824dc3af71ce60d4877cbdd9d25b1bde2b090f60d\",\"urls\":[\"bzz-raw://d7b9fdae4a08eab0d50ee1ba109e043391b51ba9b12e6cb737b5f300b42e95b7\",\"dweb:/ipfs/QmQKf1SL67GxwCUUGbw3xLFszDwo6APzTjsXLD3WXds5se\"]},\"project:/contracts/IUniswapV2Router.sol\":{\"keccak256\":\"0x7ddd123d44ed52d192f37356ca45e1a782451b3c9ed1c032a3c8d7598de17411\",\"urls\":[\"bzz-raw://96fe2c1f8889411020ed8b92b936f8973962ea0e414c490b7823c394764f7081\",\"dweb:/ipfs/QmY9FrDiqRRo5PcM3ZsgdY8K775JcDvZU1uRpF56bvmeq5\"]},\"project:/contracts/Ownable.sol\":{\"keccak256\":\"0x801fdbc363b87fe9e669fae01e5f03c757f27b8d94b9b2577bd37558f7336787\",\"urls\":[\"bzz-raw://9342e6b8925059711512b25999ad25414de9a39a4dcf0fa55ef620ebcef12a68\",\"dweb:/ipfs/QmPxmvaAokKp4299un2rrPgmdVLXP4BGva35HvKi15bRC1\"]},\"project:/contracts/SafeMath.sol\":{\"keccak256\":\"0x3106334ea2418f1d5e5004e2d3c829ff260bdf35701d88b83269b090840d8351\",\"urls\":[\"bzz-raw://fab54880057e1eaa860d9df56911796e394403fe03ad9faf9434463223e070c6\",\"dweb:/ipfs/QmSjhJZQJigTy6c2gVFXTzN2cG4YTfqNaBkh3eNUwEDnsS\"]},\"project:/contracts/UniswapV2Library.sol\":{\"keccak256\":\"0x86a043f11c120c5f4a4259c1016c107e37ea5b6acf2b1bf4e985b1b22b777010\",\"urls\":[\"bzz-raw://8a04d5cb4af4f96304c2ec9d62bddb9437149d3af878658e3d6f4cbbe72555d3\",\"dweb:/ipfs/QmZptRHER4hpwBFVPzRTFKnSrrKo3ZWTT1ho1kmvorqyYz\"]}},\"version\":1}",
    "bytecode": "0x608060405261dead600560006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff16021790555073e9e7cea3dedca5984780bafc599bd69add087d56600660006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff160217905550732170ed0880ac9a755fd29b2688956bd959f933f8600760006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff160217905550737fca1307e2006fb27c34df951052585bce2a1919600860006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff160217905550620493e06009553480156200015a57600080fd5b506200017b6200016f620001d860201b60201c565b620001e060201b60201c565b6200019d6200018f620002a460201b60201c565b6001620002cd60201b60201c565b620001d2600860009054906101000a900473ffffffffffffffffffffffffffffffffffffffff166001620002cd60201b60201c565b620004e5565b600033905090565b60008060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff169050816000806101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff1602179055508173ffffffffffffffffffffffffffffffffffffffff168173ffffffffffffffffffffffffffffffffffffffff167f8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e060405160405180910390a35050565b60008060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff16905090565b620002dd620001d860201b60201c565b73ffffffffffffffffffffffffffffffffffffffff1662000303620002a460201b60201c565b73ffffffffffffffffffffffffffffffffffffffff16146200038d576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260208152602001807f4f776e61626c653a2063616c6c6572206973206e6f7420746865206f776e657281525060200191505060405180910390fd5b801515600a60008473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060009054906101000a900460ff161515141562000438576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252602a81526020018062003739602a913960400191505060405180910390fd5b80600a60008473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060006101000a81548160ff0219169083151502179055508173ffffffffffffffffffffffffffffffffffffffff167f6c15ef90fba2d4b2963354c25c0aeeaca02ca606c82e7c9e5bf320a365776f0c82604051808215151515815260200191505060405180910390a25050565b61324480620004f56000396000f3fe6080604052600436106101235760003560e01c8063957ca639116100a0578063c45a015511610064578063c45a0155146106dc578063e4a773a914610733578063ee652fc51461076e578063ef7e6e2b146107cb578063f2fde38b146107f65761012a565b8063957ca6391461058d5780639c1b8af5146105a45780639c60c375146105cf578063a07e544d14610626578063be11e0c11461068b5761012a565b80636d13582c116100e75780636d13582c146103b7578063715018a61461040e578063848008121461042557806385141a77146104df5780638da5cb5b146105365761012a565b8063084275931461012f5780631694505e1461018a57806325073e6b146101e157806349bd5a5e146102a65780635b3bc4fe146102fd5761012a565b3661012a57005b600080fd5b34801561013b57600080fd5b506101886004803603604081101561015257600080fd5b81019080803573ffffffffffffffffffffffffffffffffffffffff16906020019092919080359060200190929190505050610847565b005b34801561019657600080fd5b5061019f610a51565b604051808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060405180910390f35b3480156101ed57600080fd5b506102a4600480360360c081101561020457600080fd5b81019080803573ffffffffffffffffffffffffffffffffffffffff169060200190929190803573ffffffffffffffffffffffffffffffffffffffff169060200190929190803573ffffffffffffffffffffffffffffffffffffffff169060200190929190803573ffffffffffffffffffffffffffffffffffffffff1690602001909291908035906020019092919080359060200190929190505050610a77565b005b3480156102b257600080fd5b506102bb610e00565b604051808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060405180910390f35b34801561030957600080fd5b506103b56004803603608081101561032057600080fd5b81019080803573ffffffffffffffffffffffffffffffffffffffff16906020019092919080359060200190929190803590602001909291908035906020019064010000000081111561037157600080fd5b82018360208201111561038357600080fd5b803590602001918460018302840111640100000000831117156103a557600080fd5b9091929391929390505050610e26565b005b3480156103c357600080fd5b506103cc6115fb565b604051808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060405180910390f35b34801561041a57600080fd5b50610423611621565b005b34801561043157600080fd5b506104dd6004803603608081101561044857600080fd5b81019080803573ffffffffffffffffffffffffffffffffffffffff16906020019092919080359060200190929190803590602001909291908035906020019064010000000081111561049957600080fd5b8201836020820111156104ab57600080fd5b803590602001918460018302840111640100000000831117156104cd57600080fd5b90919293919293905050506116dc565b005b3480156104eb57600080fd5b506104f4611eb1565b604051808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060405180910390f35b34801561054257600080fd5b5061054b611ed7565b604051808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060405180910390f35b34801561059957600080fd5b506105a2611f00565b005b3480156105b057600080fd5b506105b9612008565b6040518082815260200191505060405180910390f35b3480156105db57600080fd5b506105e461200e565b604051808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060405180910390f35b34801561063257600080fd5b506106756004803603602081101561064957600080fd5b81019080803573ffffffffffffffffffffffffffffffffffffffff169060200190929190505050612034565b6040518082815260200191505060405180910390f35b34801561069757600080fd5b506106da600480360360208110156106ae57600080fd5b81019080803573ffffffffffffffffffffffffffffffffffffffff1690602001909291905050506120f5565b005b3480156106e857600080fd5b506106f1612288565b604051808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060405180910390f35b34801561073f57600080fd5b5061076c6004803603602081101561075657600080fd5b81019080803590602001909291905050506122ae565b005b34801561077a57600080fd5b506107c96004803603604081101561079157600080fd5b81019080803573ffffffffffffffffffffffffffffffffffffffff16906020019092919080351515906020019092919050505061243a565b005b3480156107d757600080fd5b506107e061263f565b6040518082815260200191505060405180910390f35b34801561080257600080fd5b506108456004803603602081101561081957600080fd5b81019080803573ffffffffffffffffffffffffffffffffffffffff169060200190929190505050612647565b005b600a60003373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060009054906101000a900460ff16610906576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260188152602001807f4e6f742061626c6520746f20646f20746861742042726f21000000000000000081525060200191505060405180910390fd5b600061091183612034565b905080821115610989576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260138152602001807f416d6f756e7420697320746f6f2068696768210000000000000000000000000081525060200191505060405180910390fd5b8273ffffffffffffffffffffffffffffffffffffffff1663a9059cbb33846040518363ffffffff1660e01b8152600401808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200182815260200192505050602060405180830381600087803b158015610a1057600080fd5b505af1158015610a24573d6000803e3d6000fd5b505050506040513d6020811015610a3a57600080fd5b810190808051906020019092919050505050505050565b600160009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1681565b85600360006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff16021790555084600460006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff1602179055506000600360009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663e6a4390586866040518363ffffffff1660e01b8152600401808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1681526020018273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1681526020019250505060206040518083038186803b158015610bce57600080fd5b505afa158015610be2573d6000803e3d6000fd5b505050506040513d6020811015610bf857600080fd5b81019080805190602001909291905050509050600073ffffffffffffffffffffffffffffffffffffffff168173ffffffffffffffffffffffffffffffffffffffff161415610cae576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260188152602001807f5468697320706f6f6c20646f6573206e6f74206578697374000000000000000081525060200191505060405180910390fd5b8073ffffffffffffffffffffffffffffffffffffffff1663022c0d9f8484306040518060400160405280600981526020017f6e6f7420656d70747900000000000000000000000000000000000000000000008152506040518563ffffffff1660e01b8152600401808581526020018481526020018373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200180602001828103825283818151815260200191508051906020019080838360005b83811015610d90578082015181840152602081019050610d75565b50505050905090810190601f168015610dbd5780820380516001836020036101000a031916815260200191505b5095505050505050600060405180830381600087803b158015610ddf57600080fd5b505af1158015610df3573d6000803e3d6000fd5b5050505050505050505050565b600260009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1681565b6060600267ffffffffffffffff81118015610e4057600080fd5b50604051908082528060200260200182016040528015610e6f5781602001602082028036833780820191505090505b5090506000808614610e815785610e83565b845b905060003373ffffffffffffffffffffffffffffffffffffffff16630dfe16816040518163ffffffff1660e01b815260040160206040518083038186803b158015610ecd57600080fd5b505afa158015610ee1573d6000803e3d6000fd5b505050506040513d6020811015610ef757600080fd5b8101908080519060200190929190505050905060003373ffffffffffffffffffffffffffffffffffffffff1663d21220a76040518163ffffffff1660e01b815260040160206040518083038186803b158015610f5257600080fd5b505afa158015610f66573d6000803e3d6000fd5b505050506040513d6020811015610f7c57600080fd5b81019080805190602001909291905050509050610fbc600360009054906101000a900473ffffffffffffffffffffffffffffffffffffffff168383612788565b73ffffffffffffffffffffffffffffffffffffffff163373ffffffffffffffffffffffffffffffffffffffff161461105c576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252600c8152602001807f556e617574686f72697a6564000000000000000000000000000000000000000081525060200191505060405180910390fd5b600088148061106b5750600087145b61107457600080fd5b600088146110825781611084565b805b8460008151811061109157fe5b602002602001019073ffffffffffffffffffffffffffffffffffffffff16908173ffffffffffffffffffffffffffffffffffffffff1681525050600088146110d957806110db565b815b846001815181106110e857fe5b602002602001019073ffffffffffffffffffffffffffffffffffffffff16908173ffffffffffffffffffffffffffffffffffffffff168152505060008089146111315782611133565b815b90508073ffffffffffffffffffffffffffffffffffffffff1663095ea7b3600460009054906101000a900473ffffffffffffffffffffffffffffffffffffffff16866040518363ffffffff1660e01b8152600401808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200182815260200192505050602060405180830381600087803b1580156111de57600080fd5b505af11580156111f2573d6000803e3d6000fd5b505050506040513d602081101561120857600080fd5b8101908080519060200190929190505050506000611249600360009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1686886128e3565b60008151811061125557fe5b602002602001015190506000600460009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff166338ed173987848a33620d2f006040518663ffffffff1660e01b815260040180868152602001858152602001806020018473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001838152602001828103825285818151815260200191508051906020019060200280838360005b8381101561133d578082015181840152602081019050611322565b505050509050019650505050505050600060405180830381600087803b15801561136657600080fd5b505af115801561137a573d6000803e3d6000fd5b505050506040513d6000823e3d601f19601f8201168201806040525060208110156113a457600080fd5b81019080805160405193929190846401000000008211156113c457600080fd5b838201915060208201858111156113da57600080fd5b82518660208202830111640100000000821117156113f757600080fd5b8083526020830192505050908051906020019060200280838360005b8381101561142e578082015181840152602081019050611413565b5050505090500160405250505060018151811061144757fe5b602002602001015190506000808c146114605784611462565b855b90508073ffffffffffffffffffffffffffffffffffffffff1663a9059cbb33856040518363ffffffff1660e01b8152600401808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200182815260200192505050602060405180830381600087803b1580156114eb57600080fd5b505af11580156114ff573d6000803e3d6000fd5b505050506040513d602081101561151557600080fd5b8101908080519060200190929190505050508073ffffffffffffffffffffffffffffffffffffffff1663a9059cbb328585036040518363ffffffff1660e01b8152600401808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200182815260200192505050602060405180830381600087803b1580156115b057600080fd5b505af11580156115c4573d6000803e3d6000fd5b505050506040513d60208110156115da57600080fd5b81019080805190602001909291905050505050505050505050505050505050565b600460009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1681565b611629612a63565b73ffffffffffffffffffffffffffffffffffffffff16611647611ed7565b73ffffffffffffffffffffffffffffffffffffffff16146116d0576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260208152602001807f4f776e61626c653a2063616c6c6572206973206e6f7420746865206f776e657281525060200191505060405180910390fd5b6116da6000612a6b565b565b6060600267ffffffffffffffff811180156116f657600080fd5b506040519080825280602002602001820160405280156117255781602001602082028036833780820191505090505b50905060008086146117375785611739565b845b905060003373ffffffffffffffffffffffffffffffffffffffff16630dfe16816040518163ffffffff1660e01b815260040160206040518083038186803b15801561178357600080fd5b505afa158015611797573d6000803e3d6000fd5b505050506040513d60208110156117ad57600080fd5b8101908080519060200190929190505050905060003373ffffffffffffffffffffffffffffffffffffffff1663d21220a76040518163ffffffff1660e01b815260040160206040518083038186803b15801561180857600080fd5b505afa15801561181c573d6000803e3d6000fd5b505050506040513d602081101561183257600080fd5b81019080805190602001909291905050509050611872600360009054906101000a900473ffffffffffffffffffffffffffffffffffffffff168383612788565b73ffffffffffffffffffffffffffffffffffffffff163373ffffffffffffffffffffffffffffffffffffffff1614611912576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252600c8152602001807f556e617574686f72697a6564000000000000000000000000000000000000000081525060200191505060405180910390fd5b60008814806119215750600087145b61192a57600080fd5b60008814611938578161193a565b805b8460008151811061194757fe5b602002602001019073ffffffffffffffffffffffffffffffffffffffff16908173ffffffffffffffffffffffffffffffffffffffff16815250506000881461198f5780611991565b815b8460018151811061199e57fe5b602002602001019073ffffffffffffffffffffffffffffffffffffffff16908173ffffffffffffffffffffffffffffffffffffffff168152505060008089146119e757826119e9565b815b90508073ffffffffffffffffffffffffffffffffffffffff1663095ea7b3600460009054906101000a900473ffffffffffffffffffffffffffffffffffffffff16866040518363ffffffff1660e01b8152600401808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200182815260200192505050602060405180830381600087803b158015611a9457600080fd5b505af1158015611aa8573d6000803e3d6000fd5b505050506040513d6020811015611abe57600080fd5b8101908080519060200190929190505050506000611aff600360009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1686886128e3565b600081518110611b0b57fe5b602002602001015190506000600460009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff166338ed173987848a33620d2f006040518663ffffffff1660e01b815260040180868152602001858152602001806020018473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001838152602001828103825285818151815260200191508051906020019060200280838360005b83811015611bf3578082015181840152602081019050611bd8565b505050509050019650505050505050600060405180830381600087803b158015611c1c57600080fd5b505af1158015611c30573d6000803e3d6000fd5b505050506040513d6000823e3d601f19601f820116820180604052506020811015611c5a57600080fd5b8101908080516040519392919084640100000000821115611c7a57600080fd5b83820191506020820185811115611c9057600080fd5b8251866020820283011164010000000082111715611cad57600080fd5b8083526020830192505050908051906020019060200280838360005b83811015611ce4578082015181840152602081019050611cc9565b50505050905001604052505050600181518110611cfd57fe5b602002602001015190506000808c14611d165784611d18565b855b90508073ffffffffffffffffffffffffffffffffffffffff1663a9059cbb33856040518363ffffffff1660e01b8152600401808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200182815260200192505050602060405180830381600087803b158015611da157600080fd5b505af1158015611db5573d6000803e3d6000fd5b505050506040513d6020811015611dcb57600080fd5b8101908080519060200190929190505050508073ffffffffffffffffffffffffffffffffffffffff1663a9059cbb328585036040518363ffffffff1660e01b8152600401808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200182815260200192505050602060405180830381600087803b158015611e6657600080fd5b505af1158015611e7a573d6000803e3d6000fd5b505050506040513d6020811015611e9057600080fd5b81019080805190602001909291905050505050505050505050505050505050565b600560009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1681565b60008060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff16905090565b600a60003373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060009054906101000a900460ff16611fbf576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260188152602001807f4e6f742061626c6520746f20646f20746861742042726f21000000000000000081525060200191505060405180910390fd5b3373ffffffffffffffffffffffffffffffffffffffff166108fc479081150290604051600060405180830381858888f19350505050158015612005573d6000803e3d6000fd5b50565b60095481565b600860009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1681565b60008173ffffffffffffffffffffffffffffffffffffffff166370a08231306040518263ffffffff1660e01b8152600401808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060206040518083038186803b1580156120b357600080fd5b505afa1580156120c7573d6000803e3d6000fd5b505050506040513d60208110156120dd57600080fd5b81019080805190602001909291905050509050919050565b600a60003373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060009054906101000a900460ff166121b4576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260188152602001807f4e6f742061626c6520746f20646f20746861742042726f21000000000000000081525060200191505060405180910390fd5b60006121bf82612034565b90508173ffffffffffffffffffffffffffffffffffffffff1663a9059cbb33836040518363ffffffff1660e01b8152600401808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200182815260200192505050602060405180830381600087803b15801561224857600080fd5b505af115801561225c573d6000803e3d6000fd5b505050506040513d602081101561227257600080fd5b8101908080519060200190929190505050505050565b600360009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1681565b600a60003373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060009054906101000a900460ff1661236d576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260188152602001807f4e6f742061626c6520746f20646f20746861742042726f21000000000000000081525060200191505060405180910390fd5b600061237761263f565b9050808211156123ef576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260138152602001807f416d6f756e7420697320746f6f2068696768210000000000000000000000000081525060200191505060405180910390fd5b3373ffffffffffffffffffffffffffffffffffffffff166108fc839081150290604051600060405180830381858888f19350505050158015612435573d6000803e3d6000fd5b505050565b612442612a63565b73ffffffffffffffffffffffffffffffffffffffff16612460611ed7565b73ffffffffffffffffffffffffffffffffffffffff16146124e9576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260208152602001807f4f776e61626c653a2063616c6c6572206973206e6f7420746865206f776e657281525060200191505060405180910390fd5b801515600a60008473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060009054906101000a900460ff1615151415612592576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252602a815260200180613125602a913960400191505060405180910390fd5b80600a60008473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060006101000a81548160ff0219169083151502179055508173ffffffffffffffffffffffffffffffffffffffff167f6c15ef90fba2d4b2963354c25c0aeeaca02ca606c82e7c9e5bf320a365776f0c82604051808215151515815260200191505060405180910390a25050565b600047905090565b61264f612a63565b73ffffffffffffffffffffffffffffffffffffffff1661266d611ed7565b73ffffffffffffffffffffffffffffffffffffffff16146126f6576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260208152602001807f4f776e61626c653a2063616c6c6572206973206e6f7420746865206f776e657281525060200191505060405180910390fd5b600073ffffffffffffffffffffffffffffffffffffffff168173ffffffffffffffffffffffffffffffffffffffff16141561277c576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252602681526020018061314f6026913960400191505060405180910390fd5b61278581612a6b565b50565b60008060006127978585612b2f565b91509150858282604051602001808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1660601b81526014018273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1660601b8152601401925050506040516020818303038152906040528051906020012060405160200180807fff000000000000000000000000000000000000000000000000000000000000008152506001018373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1660601b8152601401828152602001807f96e8ac4277198ff8b6f785478aa9a39f403cb768dd02cbee326c3e7da348845f815250602001925050506040516020818303038152906040528051906020012060001c925050509392505050565b606060028251101561295d576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252601e8152602001807f556e697377617056324c6962726172793a20494e56414c49445f50415448000081525060200191505060405180910390fd5b815167ffffffffffffffff8111801561297557600080fd5b506040519080825280602002602001820160405280156129a45781602001602082028036833780820191505090505b50905082816001835103815181106129b857fe5b6020026020010181815250506000600183510390505b6000811115612a5b57600080612a0e878660018603815181106129ed57fe5b6020026020010151878681518110612a0157fe5b6020026020010151612ca6565b91509150612a30848481518110612a2157fe5b60200260200101518383612dcf565b846001850381518110612a3f57fe5b60200260200101818152505050508080600190039150506129ce565b509392505050565b600033905090565b60008060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff169050816000806101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff1602179055508173ffffffffffffffffffffffffffffffffffffffff168173ffffffffffffffffffffffffffffffffffffffff167f8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e060405160405180910390a35050565b6000808273ffffffffffffffffffffffffffffffffffffffff168473ffffffffffffffffffffffffffffffffffffffff161415612bb7576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260258152602001806131a16025913960400191505060405180910390fd5b8273ffffffffffffffffffffffffffffffffffffffff168473ffffffffffffffffffffffffffffffffffffffff1610612bf1578284612bf4565b83835b8092508193505050600073ffffffffffffffffffffffffffffffffffffffff168273ffffffffffffffffffffffffffffffffffffffff161415612c9f576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252601e8152602001807f556e697377617056324c6962726172793a205a45524f5f41444452455353000081525060200191505060405180910390fd5b9250929050565b6000806000612cb58585612b2f565b509050600080612cc6888888612788565b73ffffffffffffffffffffffffffffffffffffffff16630902f1ac6040518163ffffffff1660e01b815260040160606040518083038186803b158015612d0b57600080fd5b505afa158015612d1f573d6000803e3d6000fd5b505050506040513d6060811015612d3557600080fd5b81019080805190602001909291908051906020019092919080519060200190929190505050506dffffffffffffffffffffffffffff1691506dffffffffffffffffffffffffffff1691508273ffffffffffffffffffffffffffffffffffffffff168773ffffffffffffffffffffffffffffffffffffffff1614612db9578082612dbc565b81815b8095508196505050505050935093915050565b6000808411612e29576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252602c815260200180613175602c913960400191505060405180910390fd5b600083118015612e395750600082115b612e8e576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260288152602001806131c66028913960400191505060405180910390fd5b6000612eb76103e8612ea98787612f0c90919063ffffffff16565b612f0c90919063ffffffff16565b90506000612ee26103e5612ed48887612f9290919063ffffffff16565b612f0c90919063ffffffff16565b9050612f016001828481612ef257fe5b04612fdc90919063ffffffff16565b925050509392505050565b600080831415612f1f5760009050612f8c565b6000828402905082848281612f3057fe5b0414612f87576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260218152602001806131ee6021913960400191505060405180910390fd5b809150505b92915050565b6000612fd483836040518060400160405280601e81526020017f536166654d6174683a207375627472616374696f6e206f766572666c6f770000815250613064565b905092915050565b60008082840190508381101561305a576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252601b8152602001807f536166654d6174683a206164646974696f6e206f766572666c6f77000000000081525060200191505060405180910390fd5b8091505092915050565b6000838311158290613111576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825283818151815260200191508051906020019080838360005b838110156130d65780820151818401526020810190506130bb565b50505050905090810190601f1680156131035780820380516001836020036101000a031916815260200191505b509250505060405180910390fd5b506000838503905080915050939250505056fe4163636f756e7420697320616c7265616479207468652076616c7565206f662027696e636c75646564274f776e61626c653a206e6577206f776e657220697320746865207a65726f2061646472657373556e697377617056324c6962726172793a20494e53554646494349454e545f4f55545055545f414d4f554e54556e697377617056324c6962726172793a204944454e544943414c5f414444524553534553556e697377617056324c6962726172793a20494e53554646494349454e545f4c4951554944495459536166654d6174683a206d756c7469706c69636174696f6e206f766572666c6f77a2646970667358221220233ad4247819ac32e5e7acc335c7a2a4cfd0edc8fbef05570c6100be888baa3264736f6c634300060600334163636f756e7420697320616c7265616479207468652076616c7565206f662027696e636c7564656427",
    "deployedBytecode": "0x6080604052600436106101235760003560e01c8063957ca639116100a0578063c45a015511610064578063c45a0155146106dc578063e4a773a914610733578063ee652fc51461076e578063ef7e6e2b146107cb578063f2fde38b146107f65761012a565b8063957ca6391461058d5780639c1b8af5146105a45780639c60c375146105cf578063a07e544d14610626578063be11e0c11461068b5761012a565b80636d13582c116100e75780636d13582c146103b7578063715018a61461040e578063848008121461042557806385141a77146104df5780638da5cb5b146105365761012a565b8063084275931461012f5780631694505e1461018a57806325073e6b146101e157806349bd5a5e146102a65780635b3bc4fe146102fd5761012a565b3661012a57005b600080fd5b34801561013b57600080fd5b506101886004803603604081101561015257600080fd5b81019080803573ffffffffffffffffffffffffffffffffffffffff16906020019092919080359060200190929190505050610847565b005b34801561019657600080fd5b5061019f610a51565b604051808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060405180910390f35b3480156101ed57600080fd5b506102a4600480360360c081101561020457600080fd5b81019080803573ffffffffffffffffffffffffffffffffffffffff169060200190929190803573ffffffffffffffffffffffffffffffffffffffff169060200190929190803573ffffffffffffffffffffffffffffffffffffffff169060200190929190803573ffffffffffffffffffffffffffffffffffffffff1690602001909291908035906020019092919080359060200190929190505050610a77565b005b3480156102b257600080fd5b506102bb610e00565b604051808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060405180910390f35b34801561030957600080fd5b506103b56004803603608081101561032057600080fd5b81019080803573ffffffffffffffffffffffffffffffffffffffff16906020019092919080359060200190929190803590602001909291908035906020019064010000000081111561037157600080fd5b82018360208201111561038357600080fd5b803590602001918460018302840111640100000000831117156103a557600080fd5b9091929391929390505050610e26565b005b3480156103c357600080fd5b506103cc6115fb565b604051808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060405180910390f35b34801561041a57600080fd5b50610423611621565b005b34801561043157600080fd5b506104dd6004803603608081101561044857600080fd5b81019080803573ffffffffffffffffffffffffffffffffffffffff16906020019092919080359060200190929190803590602001909291908035906020019064010000000081111561049957600080fd5b8201836020820111156104ab57600080fd5b803590602001918460018302840111640100000000831117156104cd57600080fd5b90919293919293905050506116dc565b005b3480156104eb57600080fd5b506104f4611eb1565b604051808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060405180910390f35b34801561054257600080fd5b5061054b611ed7565b604051808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060405180910390f35b34801561059957600080fd5b506105a2611f00565b005b3480156105b057600080fd5b506105b9612008565b6040518082815260200191505060405180910390f35b3480156105db57600080fd5b506105e461200e565b604051808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060405180910390f35b34801561063257600080fd5b506106756004803603602081101561064957600080fd5b81019080803573ffffffffffffffffffffffffffffffffffffffff169060200190929190505050612034565b6040518082815260200191505060405180910390f35b34801561069757600080fd5b506106da600480360360208110156106ae57600080fd5b81019080803573ffffffffffffffffffffffffffffffffffffffff1690602001909291905050506120f5565b005b3480156106e857600080fd5b506106f1612288565b604051808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060405180910390f35b34801561073f57600080fd5b5061076c6004803603602081101561075657600080fd5b81019080803590602001909291905050506122ae565b005b34801561077a57600080fd5b506107c96004803603604081101561079157600080fd5b81019080803573ffffffffffffffffffffffffffffffffffffffff16906020019092919080351515906020019092919050505061243a565b005b3480156107d757600080fd5b506107e061263f565b6040518082815260200191505060405180910390f35b34801561080257600080fd5b506108456004803603602081101561081957600080fd5b81019080803573ffffffffffffffffffffffffffffffffffffffff169060200190929190505050612647565b005b600a60003373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060009054906101000a900460ff16610906576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260188152602001807f4e6f742061626c6520746f20646f20746861742042726f21000000000000000081525060200191505060405180910390fd5b600061091183612034565b905080821115610989576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260138152602001807f416d6f756e7420697320746f6f2068696768210000000000000000000000000081525060200191505060405180910390fd5b8273ffffffffffffffffffffffffffffffffffffffff1663a9059cbb33846040518363ffffffff1660e01b8152600401808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200182815260200192505050602060405180830381600087803b158015610a1057600080fd5b505af1158015610a24573d6000803e3d6000fd5b505050506040513d6020811015610a3a57600080fd5b810190808051906020019092919050505050505050565b600160009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1681565b85600360006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff16021790555084600460006101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff1602179055506000600360009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1663e6a4390586866040518363ffffffff1660e01b8152600401808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1681526020018273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1681526020019250505060206040518083038186803b158015610bce57600080fd5b505afa158015610be2573d6000803e3d6000fd5b505050506040513d6020811015610bf857600080fd5b81019080805190602001909291905050509050600073ffffffffffffffffffffffffffffffffffffffff168173ffffffffffffffffffffffffffffffffffffffff161415610cae576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260188152602001807f5468697320706f6f6c20646f6573206e6f74206578697374000000000000000081525060200191505060405180910390fd5b8073ffffffffffffffffffffffffffffffffffffffff1663022c0d9f8484306040518060400160405280600981526020017f6e6f7420656d70747900000000000000000000000000000000000000000000008152506040518563ffffffff1660e01b8152600401808581526020018481526020018373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200180602001828103825283818151815260200191508051906020019080838360005b83811015610d90578082015181840152602081019050610d75565b50505050905090810190601f168015610dbd5780820380516001836020036101000a031916815260200191505b5095505050505050600060405180830381600087803b158015610ddf57600080fd5b505af1158015610df3573d6000803e3d6000fd5b5050505050505050505050565b600260009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1681565b6060600267ffffffffffffffff81118015610e4057600080fd5b50604051908082528060200260200182016040528015610e6f5781602001602082028036833780820191505090505b5090506000808614610e815785610e83565b845b905060003373ffffffffffffffffffffffffffffffffffffffff16630dfe16816040518163ffffffff1660e01b815260040160206040518083038186803b158015610ecd57600080fd5b505afa158015610ee1573d6000803e3d6000fd5b505050506040513d6020811015610ef757600080fd5b8101908080519060200190929190505050905060003373ffffffffffffffffffffffffffffffffffffffff1663d21220a76040518163ffffffff1660e01b815260040160206040518083038186803b158015610f5257600080fd5b505afa158015610f66573d6000803e3d6000fd5b505050506040513d6020811015610f7c57600080fd5b81019080805190602001909291905050509050610fbc600360009054906101000a900473ffffffffffffffffffffffffffffffffffffffff168383612788565b73ffffffffffffffffffffffffffffffffffffffff163373ffffffffffffffffffffffffffffffffffffffff161461105c576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252600c8152602001807f556e617574686f72697a6564000000000000000000000000000000000000000081525060200191505060405180910390fd5b600088148061106b5750600087145b61107457600080fd5b600088146110825781611084565b805b8460008151811061109157fe5b602002602001019073ffffffffffffffffffffffffffffffffffffffff16908173ffffffffffffffffffffffffffffffffffffffff1681525050600088146110d957806110db565b815b846001815181106110e857fe5b602002602001019073ffffffffffffffffffffffffffffffffffffffff16908173ffffffffffffffffffffffffffffffffffffffff168152505060008089146111315782611133565b815b90508073ffffffffffffffffffffffffffffffffffffffff1663095ea7b3600460009054906101000a900473ffffffffffffffffffffffffffffffffffffffff16866040518363ffffffff1660e01b8152600401808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200182815260200192505050602060405180830381600087803b1580156111de57600080fd5b505af11580156111f2573d6000803e3d6000fd5b505050506040513d602081101561120857600080fd5b8101908080519060200190929190505050506000611249600360009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1686886128e3565b60008151811061125557fe5b602002602001015190506000600460009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff166338ed173987848a33620d2f006040518663ffffffff1660e01b815260040180868152602001858152602001806020018473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001838152602001828103825285818151815260200191508051906020019060200280838360005b8381101561133d578082015181840152602081019050611322565b505050509050019650505050505050600060405180830381600087803b15801561136657600080fd5b505af115801561137a573d6000803e3d6000fd5b505050506040513d6000823e3d601f19601f8201168201806040525060208110156113a457600080fd5b81019080805160405193929190846401000000008211156113c457600080fd5b838201915060208201858111156113da57600080fd5b82518660208202830111640100000000821117156113f757600080fd5b8083526020830192505050908051906020019060200280838360005b8381101561142e578082015181840152602081019050611413565b5050505090500160405250505060018151811061144757fe5b602002602001015190506000808c146114605784611462565b855b90508073ffffffffffffffffffffffffffffffffffffffff1663a9059cbb33856040518363ffffffff1660e01b8152600401808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200182815260200192505050602060405180830381600087803b1580156114eb57600080fd5b505af11580156114ff573d6000803e3d6000fd5b505050506040513d602081101561151557600080fd5b8101908080519060200190929190505050508073ffffffffffffffffffffffffffffffffffffffff1663a9059cbb328585036040518363ffffffff1660e01b8152600401808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200182815260200192505050602060405180830381600087803b1580156115b057600080fd5b505af11580156115c4573d6000803e3d6000fd5b505050506040513d60208110156115da57600080fd5b81019080805190602001909291905050505050505050505050505050505050565b600460009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1681565b611629612a63565b73ffffffffffffffffffffffffffffffffffffffff16611647611ed7565b73ffffffffffffffffffffffffffffffffffffffff16146116d0576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260208152602001807f4f776e61626c653a2063616c6c6572206973206e6f7420746865206f776e657281525060200191505060405180910390fd5b6116da6000612a6b565b565b6060600267ffffffffffffffff811180156116f657600080fd5b506040519080825280602002602001820160405280156117255781602001602082028036833780820191505090505b50905060008086146117375785611739565b845b905060003373ffffffffffffffffffffffffffffffffffffffff16630dfe16816040518163ffffffff1660e01b815260040160206040518083038186803b15801561178357600080fd5b505afa158015611797573d6000803e3d6000fd5b505050506040513d60208110156117ad57600080fd5b8101908080519060200190929190505050905060003373ffffffffffffffffffffffffffffffffffffffff1663d21220a76040518163ffffffff1660e01b815260040160206040518083038186803b15801561180857600080fd5b505afa15801561181c573d6000803e3d6000fd5b505050506040513d602081101561183257600080fd5b81019080805190602001909291905050509050611872600360009054906101000a900473ffffffffffffffffffffffffffffffffffffffff168383612788565b73ffffffffffffffffffffffffffffffffffffffff163373ffffffffffffffffffffffffffffffffffffffff1614611912576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252600c8152602001807f556e617574686f72697a6564000000000000000000000000000000000000000081525060200191505060405180910390fd5b60008814806119215750600087145b61192a57600080fd5b60008814611938578161193a565b805b8460008151811061194757fe5b602002602001019073ffffffffffffffffffffffffffffffffffffffff16908173ffffffffffffffffffffffffffffffffffffffff16815250506000881461198f5780611991565b815b8460018151811061199e57fe5b602002602001019073ffffffffffffffffffffffffffffffffffffffff16908173ffffffffffffffffffffffffffffffffffffffff168152505060008089146119e757826119e9565b815b90508073ffffffffffffffffffffffffffffffffffffffff1663095ea7b3600460009054906101000a900473ffffffffffffffffffffffffffffffffffffffff16866040518363ffffffff1660e01b8152600401808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200182815260200192505050602060405180830381600087803b158015611a9457600080fd5b505af1158015611aa8573d6000803e3d6000fd5b505050506040513d6020811015611abe57600080fd5b8101908080519060200190929190505050506000611aff600360009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1686886128e3565b600081518110611b0b57fe5b602002602001015190506000600460009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff166338ed173987848a33620d2f006040518663ffffffff1660e01b815260040180868152602001858152602001806020018473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff168152602001838152602001828103825285818151815260200191508051906020019060200280838360005b83811015611bf3578082015181840152602081019050611bd8565b505050509050019650505050505050600060405180830381600087803b158015611c1c57600080fd5b505af1158015611c30573d6000803e3d6000fd5b505050506040513d6000823e3d601f19601f820116820180604052506020811015611c5a57600080fd5b8101908080516040519392919084640100000000821115611c7a57600080fd5b83820191506020820185811115611c9057600080fd5b8251866020820283011164010000000082111715611cad57600080fd5b8083526020830192505050908051906020019060200280838360005b83811015611ce4578082015181840152602081019050611cc9565b50505050905001604052505050600181518110611cfd57fe5b602002602001015190506000808c14611d165784611d18565b855b90508073ffffffffffffffffffffffffffffffffffffffff1663a9059cbb33856040518363ffffffff1660e01b8152600401808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200182815260200192505050602060405180830381600087803b158015611da157600080fd5b505af1158015611db5573d6000803e3d6000fd5b505050506040513d6020811015611dcb57600080fd5b8101908080519060200190929190505050508073ffffffffffffffffffffffffffffffffffffffff1663a9059cbb328585036040518363ffffffff1660e01b8152600401808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200182815260200192505050602060405180830381600087803b158015611e6657600080fd5b505af1158015611e7a573d6000803e3d6000fd5b505050506040513d6020811015611e9057600080fd5b81019080805190602001909291905050505050505050505050505050505050565b600560009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1681565b60008060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff16905090565b600a60003373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060009054906101000a900460ff16611fbf576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260188152602001807f4e6f742061626c6520746f20646f20746861742042726f21000000000000000081525060200191505060405180910390fd5b3373ffffffffffffffffffffffffffffffffffffffff166108fc479081150290604051600060405180830381858888f19350505050158015612005573d6000803e3d6000fd5b50565b60095481565b600860009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1681565b60008173ffffffffffffffffffffffffffffffffffffffff166370a08231306040518263ffffffff1660e01b8152600401808273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200191505060206040518083038186803b1580156120b357600080fd5b505afa1580156120c7573d6000803e3d6000fd5b505050506040513d60208110156120dd57600080fd5b81019080805190602001909291905050509050919050565b600a60003373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060009054906101000a900460ff166121b4576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260188152602001807f4e6f742061626c6520746f20646f20746861742042726f21000000000000000081525060200191505060405180910390fd5b60006121bf82612034565b90508173ffffffffffffffffffffffffffffffffffffffff1663a9059cbb33836040518363ffffffff1660e01b8152600401808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200182815260200192505050602060405180830381600087803b15801561224857600080fd5b505af115801561225c573d6000803e3d6000fd5b505050506040513d602081101561227257600080fd5b8101908080519060200190929190505050505050565b600360009054906101000a900473ffffffffffffffffffffffffffffffffffffffff1681565b600a60003373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060009054906101000a900460ff1661236d576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260188152602001807f4e6f742061626c6520746f20646f20746861742042726f21000000000000000081525060200191505060405180910390fd5b600061237761263f565b9050808211156123ef576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260138152602001807f416d6f756e7420697320746f6f2068696768210000000000000000000000000081525060200191505060405180910390fd5b3373ffffffffffffffffffffffffffffffffffffffff166108fc839081150290604051600060405180830381858888f19350505050158015612435573d6000803e3d6000fd5b505050565b612442612a63565b73ffffffffffffffffffffffffffffffffffffffff16612460611ed7565b73ffffffffffffffffffffffffffffffffffffffff16146124e9576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260208152602001807f4f776e61626c653a2063616c6c6572206973206e6f7420746865206f776e657281525060200191505060405180910390fd5b801515600a60008473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060009054906101000a900460ff1615151415612592576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252602a815260200180613125602a913960400191505060405180910390fd5b80600a60008473ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff16815260200190815260200160002060006101000a81548160ff0219169083151502179055508173ffffffffffffffffffffffffffffffffffffffff167f6c15ef90fba2d4b2963354c25c0aeeaca02ca606c82e7c9e5bf320a365776f0c82604051808215151515815260200191505060405180910390a25050565b600047905090565b61264f612a63565b73ffffffffffffffffffffffffffffffffffffffff1661266d611ed7565b73ffffffffffffffffffffffffffffffffffffffff16146126f6576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260208152602001807f4f776e61626c653a2063616c6c6572206973206e6f7420746865206f776e657281525060200191505060405180910390fd5b600073ffffffffffffffffffffffffffffffffffffffff168173ffffffffffffffffffffffffffffffffffffffff16141561277c576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252602681526020018061314f6026913960400191505060405180910390fd5b61278581612a6b565b50565b60008060006127978585612b2f565b91509150858282604051602001808373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1660601b81526014018273ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1660601b8152601401925050506040516020818303038152906040528051906020012060405160200180807fff000000000000000000000000000000000000000000000000000000000000008152506001018373ffffffffffffffffffffffffffffffffffffffff1673ffffffffffffffffffffffffffffffffffffffff1660601b8152601401828152602001807f96e8ac4277198ff8b6f785478aa9a39f403cb768dd02cbee326c3e7da348845f815250602001925050506040516020818303038152906040528051906020012060001c925050509392505050565b606060028251101561295d576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252601e8152602001807f556e697377617056324c6962726172793a20494e56414c49445f50415448000081525060200191505060405180910390fd5b815167ffffffffffffffff8111801561297557600080fd5b506040519080825280602002602001820160405280156129a45781602001602082028036833780820191505090505b50905082816001835103815181106129b857fe5b6020026020010181815250506000600183510390505b6000811115612a5b57600080612a0e878660018603815181106129ed57fe5b6020026020010151878681518110612a0157fe5b6020026020010151612ca6565b91509150612a30848481518110612a2157fe5b60200260200101518383612dcf565b846001850381518110612a3f57fe5b60200260200101818152505050508080600190039150506129ce565b509392505050565b600033905090565b60008060009054906101000a900473ffffffffffffffffffffffffffffffffffffffff169050816000806101000a81548173ffffffffffffffffffffffffffffffffffffffff021916908373ffffffffffffffffffffffffffffffffffffffff1602179055508173ffffffffffffffffffffffffffffffffffffffff168173ffffffffffffffffffffffffffffffffffffffff167f8be0079c531659141344cd1fd0a4f28419497f9722a3daafe3b4186f6b6457e060405160405180910390a35050565b6000808273ffffffffffffffffffffffffffffffffffffffff168473ffffffffffffffffffffffffffffffffffffffff161415612bb7576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260258152602001806131a16025913960400191505060405180910390fd5b8273ffffffffffffffffffffffffffffffffffffffff168473ffffffffffffffffffffffffffffffffffffffff1610612bf1578284612bf4565b83835b8092508193505050600073ffffffffffffffffffffffffffffffffffffffff168273ffffffffffffffffffffffffffffffffffffffff161415612c9f576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252601e8152602001807f556e697377617056324c6962726172793a205a45524f5f41444452455353000081525060200191505060405180910390fd5b9250929050565b6000806000612cb58585612b2f565b509050600080612cc6888888612788565b73ffffffffffffffffffffffffffffffffffffffff16630902f1ac6040518163ffffffff1660e01b815260040160606040518083038186803b158015612d0b57600080fd5b505afa158015612d1f573d6000803e3d6000fd5b505050506040513d6060811015612d3557600080fd5b81019080805190602001909291908051906020019092919080519060200190929190505050506dffffffffffffffffffffffffffff1691506dffffffffffffffffffffffffffff1691508273ffffffffffffffffffffffffffffffffffffffff168773ffffffffffffffffffffffffffffffffffffffff1614612db9578082612dbc565b81815b8095508196505050505050935093915050565b6000808411612e29576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252602c815260200180613175602c913960400191505060405180910390fd5b600083118015612e395750600082115b612e8e576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260288152602001806131c66028913960400191505060405180910390fd5b6000612eb76103e8612ea98787612f0c90919063ffffffff16565b612f0c90919063ffffffff16565b90506000612ee26103e5612ed48887612f9290919063ffffffff16565b612f0c90919063ffffffff16565b9050612f016001828481612ef257fe5b04612fdc90919063ffffffff16565b925050509392505050565b600080831415612f1f5760009050612f8c565b6000828402905082848281612f3057fe5b0414612f87576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825260218152602001806131ee6021913960400191505060405180910390fd5b809150505b92915050565b6000612fd483836040518060400160405280601e81526020017f536166654d6174683a207375627472616374696f6e206f766572666c6f770000815250613064565b905092915050565b60008082840190508381101561305a576040517f08c379a000000000000000000000000000000000000000000000000000000000815260040180806020018281038252601b8152602001807f536166654d6174683a206164646974696f6e206f766572666c6f77000000000081525060200191505060405180910390fd5b8091505092915050565b6000838311158290613111576040517f08c379a00000000000000000000000000000000000000000000000000000000081526004018080602001828103825283818151815260200191508051906020019080838360005b838110156130d65780820151818401526020810190506130bb565b50505050905090810190601f1680156131035780820380516001836020036101000a031916815260200191505b509250505060405180910390fd5b506000838503905080915050939250505056fe4163636f756e7420697320616c7265616479207468652076616c7565206f662027696e636c75646564274f776e61626c653a206e6577206f776e657220697320746865207a65726f2061646472657373556e697377617056324c6962726172793a20494e53554646494349454e545f4f55545055545f414d4f554e54556e697377617056324c6962726172793a204944454e544943414c5f414444524553534553556e697377617056324c6962726172793a20494e53554646494349454e545f4c4951554944495459536166654d6174683a206d756c7469706c69636174696f6e206f766572666c6f77a2646970667358221220233ad4247819ac32e5e7acc335c7a2a4cfd0edc8fbef05570c6100be888baa3264736f6c63430006060033",
    "immutableReferences": {},
    "sourceMap": "334:9510:0:-:0;;;632:42;604:70;;;;;;;;;;;;;;;;;;;;717:42;685:75;;;;;;;;;;;;;;;;;;;;799:42;767:75;;;;;;;;;;;;;;;;;;;;886:42;854:74;;;;;;;;;;;;;;;;;;;;975:6;941:40;;1255:1175;5:9:-1;2:2;;;27:1;24;17:12;2:2;1255:1175:0;866:23:7;876:12;:10;;;:12;;:::i;:::-;866:9;;;:23;;:::i;:::-;1934:31:0;1951:7;:5;;;:7;;:::i;:::-;1960:4;1934:16;;;:31;;:::i;:::-;1975:38;1992:14;;;;;;;;;;;2008:4;1975:16;;;:38;;:::i;:::-;334:9510;;587:96:1;640:7;666:10;659:17;;587:96;:::o;2040:169:7:-;2095:16;2114:6;;;;;;;;;;;2095:25;;2139:8;2130:6;;:17;;;;;;;;;;;;;;;;;;2193:8;2162:40;;2183:8;2162:40;;;;;;;;;;;;2040:169;;:::o;972:85::-;1018:7;1044:6;;;;;;;;;;;1037:13;;972:85;:::o;2480:269:0:-;1195:12:7;:10;;;:12;;:::i;:::-;1184:23;;:7;:5;;;:7;;:::i;:::-;:23;;;1176:68;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;2596:8:0::1;2573:31;;:10;:19;2584:7;2573:19;;;;;;;;;;;;;;;;;;;;;;;;;:31;;;;2565:86;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;2683:8;2661:10;:19;2672:7;2661:19;;;;;;;;;;;;;;;;:30;;;;;;;;;;;;;;;;;;2724:7;2707:35;;;2733:8;2707:35;;;;;;;;;;;;;;;;;;;;;;2480:269:::0;;:::o;334:9510::-;;;;;;;",
    "deployedSourceMap": "334:9510:0:-:0;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;12:1:-1;9;2:12;2759:347:0;;5:9:-1;2:2;;;27:1;24;17:12;2:2;2759:347:0;;;;;;15:2:-1;10:3;7:11;4:2;;;31:1;28;21:12;4:2;2759:347:0;;;;;;;;;;;;;;;;;;;;;;;;;;;;:::i;:::-;;402:41;;5:9:-1;2:2;;;27:1;24;17:12;2:2;402:41:0;;;:::i;:::-;;;;;;;;;;;;;;;;;;;;;;;4187:531;;5:9:-1;2:2;;;27:1;24;17:12;2:2;4187:531:0;;;;;;15:3:-1;10;7:12;4:2;;;32:1;29;22:12;4:2;4187:531:0;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:::i;:::-;;449:29;;5:9:-1;2:2;;;27:1;24;17:12;2:2;449:29:0;;;:::i;:::-;;;;;;;;;;;;;;;;;;;;;;;5924:1195;;5:9:-1;2:2;;;27:1;24;17:12;2:2;5924:1195:0;;;;;;15:3:-1;10;7:12;4:2;;;32:1;29;22:12;4:2;5924:1195:0;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;27:11:-1;14;11:28;8:2;;;52:1;49;42:12;8:2;5924:1195:0;;41:9:-1;34:4;18:14;14:25;11:40;8:2;;;64:1;61;54:12;8:2;5924:1195:0;;;;;;100:9:-1;95:1;81:12;77:20;67:8;63:35;60:50;39:11;25:12;22:29;11:107;8:2;;;131:1;128;121:12;8:2;5924:1195:0;;;;;;;;;;;;:::i;:::-;;555:37;;5:9:-1;2:2;;;27:1;24;17:12;2:2;555:37:0;;;:::i;:::-;;;;;;;;;;;;;;;;;;;;;;;1604:92:7;;5:9:-1;2:2;;;27:1;24;17:12;2:2;1604:92:7;;;:::i;:::-;;4722:1196:0;;5:9:-1;2:2;;;27:1;24;17:12;2:2;4722:1196:0;;;;;;15:3:-1;10;7:12;4:2;;;32:1;29;22:12;4:2;4722:1196:0;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;27:11:-1;14;11:28;8:2;;;52:1;49;42:12;8:2;4722:1196:0;;41:9:-1;34:4;18:14;14:25;11:40;8:2;;;64:1;61;54:12;8:2;4722:1196:0;;;;;;100:9:-1;95:1;81:12;77:20;67:8;63:35;60:50;39:11;25:12;22:29;11:107;8:2;;;131:1;128;121:12;8:2;4722:1196:0;;;;;;;;;;;;:::i;:::-;;604:70;;5:9:-1;2:2;;;27:1;24;17:12;2:2;604:70:0;;;:::i;:::-;;;;;;;;;;;;;;;;;;;;;;;972:85:7;;5:9:-1;2:2;;;27:1;24;17:12;2:2;972:85:7;;;:::i;:::-;;;;;;;;;;;;;;;;;;;;;;;3393:182:0;;5:9:-1;2:2;;;27:1;24;17:12;2:2;3393:182:0;;;:::i;:::-;;941:40;;5:9:-1;2:2;;;27:1;24;17:12;2:2;941:40:0;;;:::i;:::-;;;;;;;;;;;;;;;;;;;854:74;;5:9:-1;2:2;;;27:1;24;17:12;2:2;854:74:0;;;:::i;:::-;;;;;;;;;;;;;;;;;;;;;;;3899:153;;5:9:-1;2:2;;;27:1;24;17:12;2:2;3899:153:0;;;;;;15:2:-1;10:3;7:11;4:2;;;31:1;28;21:12;4:2;3899:153:0;;;;;;;;;;;;;;;;;;;:::i;:::-;;;;;;;;;;;;;;;;;;;3111:276;;5:9:-1;2:2;;;27:1;24;17:12;2:2;3111:276:0;;;;;;15:2:-1;10:3;7:11;4:2;;;31:1;28;21:12;4:2;3111:276:0;;;;;;;;;;;;;;;;;;;:::i;:::-;;489:22;;5:9:-1;2:2;;;27:1;24;17:12;2:2;489:22:0;;;:::i;:::-;;;;;;;;;;;;;;;;;;;;;;;3582:307;;5:9:-1;2:2;;;27:1;24;17:12;2:2;3582:307:0;;;;;;15:2:-1;10:3;7:11;4:2;;;31:1;28;21:12;4:2;3582:307:0;;;;;;;;;;;;;;;;;:::i;:::-;;2480:269;;5:9:-1;2:2;;;27:1;24;17:12;2:2;2480:269:0;;;;;;15:2:-1;10:3;7:11;4:2;;;31:1;28;21:12;4:2;2480:269:0;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;:::i;:::-;;4062:110;;5:9:-1;2:2;;;27:1;24;17:12;2:2;4062:110:0;;;:::i;:::-;;;;;;;;;;;;;;;;;;;1845:189:7;;5:9:-1;2:2;;;27:1;24;17:12;2:2;1845:189:7;;;;;;15:2:-1;10:3;7:11;4:2;;;31:1;28;21:12;4:2;1845:189:7;;;;;;;;;;;;;;;;;;;:::i;:::-;;2759:347:0;2843:10;:22;2854:10;2843:22;;;;;;;;;;;;;;;;;;;;;;;;;2835:59;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;2904:22;2929:36;2952:12;2929:22;:36::i;:::-;2904:61;;2993:14;2983:6;:24;;2975:56;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;3048:12;3041:29;;;3071:10;3083:6;3041:49;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;5:9:-1;2:2;;;27:1;24;17:12;2:2;3041:49:0;;;;8:9:-1;5:2;;;45:16;42:1;39;24:38;77:16;74:1;67:27;5:2;3041:49:0;;;;;;;15:2:-1;10:3;7:11;4:2;;;31:1;28;21:12;4:2;3041:49:0;;;;;;;;;;;;;;;;;2759:347;;;:::o;402:41::-;;;;;;;;;;;;;:::o;4187:531::-;4374:16;4364:7;;:26;;;;;;;;;;;;;;;;;;4431:11;4398;;:45;;;;;;;;;;;;;;;;;;4449:19;4489:7;;;;;;;;;;;4471:34;;;4506:6;4514;4471:50;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;5:9:-1;2:2;;;27:1;24;17:12;2:2;4471:50:0;;;;8:9:-1;5:2;;;45:16;42:1;39;24:38;77:16;74:1;67:27;5:2;4471:50:0;;;;;;;15:2:-1;10:3;7:11;4:2;;;31:1;28;21:12;4:2;4471:50:0;;;;;;;;;;;;;;;;4449:72;;4558:1;4535:25;;:11;:25;;;;4527:62;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;4610:11;4595:32;;;4635:7;4651;4675:4;4689:18;;;;;;;;;;;;;;;;;4595:118;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;23:1:-1;8:100;33:3;30:1;27:10;8:100;;;99:1;94:3;90:11;84:18;80:1;75:3;71:11;64:39;52:2;49:1;45:10;40:15;;8:100;;;12:14;4595:118:0;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;5:9:-1;2:2;;;27:1;24;17:12;2:2;4595:118:0;;;;8:9:-1;5:2;;;45:16;42:1;39;24:38;77:16;74:1;67:27;5:2;4595:118:0;;;;4187:531;;;;;;;:::o;449:29::-;;;;;;;;;;;;;:::o;5924:1195::-;6051:21;6089:1;6075:16;;;5:9:-1;2:2;;;27:1;24;17:12;2:2;6075:16:0;;;;;;;;;;;;;;;;;;;;;;;29:2:-1;21:6;17:15;125:4;109:14;101:6;88:42;156:4;148:6;144:17;134:27;;0:165;6075:16:0;;;;6051:40;;6097:16;6128:1;6116:8;:13;:35;;6143:8;6116:35;;;6132:8;6116:35;6097:54;;6162:14;6194:10;6179:33;;;:35;;;;;;;;;;;;;;;;;;;;;;5:9:-1;2:2;;;27:1;24;17:12;2:2;6179:35:0;;;;8:9:-1;5:2;;;45:16;42:1;39;24:38;77:16;74:1;67:27;5:2;6179:35:0;;;;;;;15:2:-1;10:3;7:11;4:2;;;31:1;28;21:12;4:2;6179:35:0;;;;;;;;;;;;;;;;6162:52;;6220:14;6252:10;6237:33;;;:35;;;;;;;;;;;;;;;;;;;;;;5:9:-1;2:2;;;27:1;24;17:12;2:2;6237:35:0;;;;8:9:-1;5:2;;;45:16;42:1;39;24:38;77:16;74:1;67:27;5:2;6237:35:0;;;;;;;15:2:-1;10:3;7:11;4:2;;;31:1;28;21:12;4:2;6237:35:0;;;;;;;;;;;;;;;;6220:52;;6308:49;6333:7;;;;;;;;;;;6342:6;6350;6308:24;:49::i;:::-;6294:63;;:10;:63;;;6279:107;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;6413:1;6401:8;:13;:30;;;;6430:1;6418:8;:13;6401:30;6393:39;;12:1:-1;9;2:12;6393:39:0;6461:1;6449:8;:13;:31;;6474:6;6449:31;;;6465:6;6449:31;6439:4;6444:1;6439:7;;;;;;;;;;;;;:41;;;;;;;;;;;6508:1;6496:8;:13;:31;;6521:6;6496:31;;;6512:6;6496:31;6486:4;6491:1;6486:7;;;;;;;;;;;;;:41;;;;;;;;;;;6534:12;6568:1;6556:8;:13;:31;;6581:6;6556:31;;;6572:6;6556:31;6534:54;;6599:5;:13;;;6621:11;;;;;;;;;;;6635;6599:48;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;5:9:-1;2:2;;;27:1;24;17:12;2:2;6599:48:0;;;;8:9:-1;5:2;;;45:16;42:1;39;24:38;77:16;74:1;67:27;5:2;6599:48:0;;;;;;;15:2:-1;10:3;7:11;4:2;;;31:1;28;21:12;4:2;6599:48:0;;;;;;;;;;;;;;;;;6654:19;6676:83;6713:7;;;;;;;;;;;6729:11;6749:4;6676:29;:83::i;:::-;6760:1;6676:86;;;;;;;;;;;;;;6654:108;;6768:19;6790:11;;;;;;;;;;;:36;;;6834:11;6854:14;6877:4;6890:10;542:7;6790:133;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;23:1:-1;8:100;33:3;30:1;27:10;8:100;;;99:1;94:3;90:11;84:18;80:1;75:3;71:11;64:39;52:2;49:1;45:10;40:15;;8:100;;;12:14;6790:133:0;;;;;;;;;;;;;;;;;;;;;;;;;;5:9:-1;2:2;;;27:1;24;17:12;2:2;6790:133:0;;;;8:9:-1;5:2;;;45:16;42:1;39;24:38;77:16;74:1;67:27;5:2;6790:133:0;;;;;;39:16:-1;36:1;17:17;2:54;6790:133:0;101:4:-1;97:9;90:4;84;80:15;76:31;69:5;65:43;126:6;120:4;113:20;0:138;15:2;10:3;7:11;4:2;;;31:1;28;21:12;4:2;6790:133:0;;;;;;;;;;;;;19:11:-1;14:3;11:20;8:2;;;44:1;41;34:12;8:2;71:11;66:3;62:21;55:28;;123:4;118:3;114:14;159:9;141:16;138:31;135:2;;;182:1;179;172:12;135:2;219:3;213:10;331:9;325:2;311:12;307:21;289:16;285:44;282:59;261:11;247:12;244:29;233:116;230:2;;;362:1;359;352:12;230:2;385:12;380:3;373:25;421:4;416:3;412:14;405:21;;0:433;;6790:133:0;;;;;;;;;;;;23:1:-1;8:100;33:3;30:1;27:10;8:100;;;99:1;94:3;90:11;84:18;80:1;75:3;71:11;64:39;52:2;49:1;45:10;40:15;;8:100;;;12:14;6790:133:0;;;;;;;;;;;6924:1;6790:136;;;;;;;;;;;;;;6768:158;;6933:17;6972:1;6960:8;:13;:31;;6985:6;6960:31;;;6976:6;6960:31;6933:59;;6998:10;:19;;;7018:10;7030:14;6998:47;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;5:9:-1;2:2;;;27:1;24;17:12;2:2;6998:47:0;;;;8:9:-1;5:2;;;45:16;42:1;39;24:38;77:16;74:1;67:27;5:2;6998:47:0;;;;;;;15:2:-1;10:3;7:11;4:2;;;31:1;28;21:12;4:2;6998:47:0;;;;;;;;;;;;;;;;;7051:10;:19;;;7071:9;7099:14;7082;:31;7051:63;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;5:9:-1;2:2;;;27:1;24;17:12;2:2;7051:63:0;;;;8:9:-1;5:2;;;45:16;42:1;39;24:38;77:16;74:1;67:27;5:2;7051:63:0;;;;;;;15:2:-1;10:3;7:11;4:2;;;31:1;28;21:12;4:2;7051:63:0;;;;;;;;;;;;;;;;;5924:1195;;;;;;;;;;;;;:::o;555:37::-;;;;;;;;;;;;;:::o;1604:92:7:-;1195:12;:10;:12::i;:::-;1184:23;;:7;:5;:7::i;:::-;:23;;;1176:68;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;1668:21:::1;1686:1;1668:9;:21::i;:::-;1604:92::o:0;4722:1196:0:-;4850:21;4888:1;4874:16;;;5:9:-1;2:2;;;27:1;24;17:12;2:2;4874:16:0;;;;;;;;;;;;;;;;;;;;;;;29:2:-1;21:6;17:15;125:4;109:14;101:6;88:42;156:4;148:6;144:17;134:27;;0:165;4874:16:0;;;;4850:40;;4896:16;4927:1;4915:8;:13;:35;;4942:8;4915:35;;;4931:8;4915:35;4896:54;;4961:14;4993:10;4978:33;;;:35;;;;;;;;;;;;;;;;;;;;;;5:9:-1;2:2;;;27:1;24;17:12;2:2;4978:35:0;;;;8:9:-1;5:2;;;45:16;42:1;39;24:38;77:16;74:1;67:27;5:2;4978:35:0;;;;;;;15:2:-1;10:3;7:11;4:2;;;31:1;28;21:12;4:2;4978:35:0;;;;;;;;;;;;;;;;4961:52;;5019:14;5051:10;5036:33;;;:35;;;;;;;;;;;;;;;;;;;;;;5:9:-1;2:2;;;27:1;24;17:12;2:2;5036:35:0;;;;8:9:-1;5:2;;;45:16;42:1;39;24:38;77:16;74:1;67:27;5:2;5036:35:0;;;;;;;15:2:-1;10:3;7:11;4:2;;;31:1;28;21:12;4:2;5036:35:0;;;;;;;;;;;;;;;;5019:52;;5107:49;5132:7;;;;;;;;;;;5141:6;5149;5107:24;:49::i;:::-;5093:63;;:10;:63;;;5078:107;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;5212:1;5200:8;:13;:30;;;;5229:1;5217:8;:13;5200:30;5192:39;;12:1:-1;9;2:12;5192:39:0;5260:1;5248:8;:13;:31;;5273:6;5248:31;;;5264:6;5248:31;5238:4;5243:1;5238:7;;;;;;;;;;;;;:41;;;;;;;;;;;5307:1;5295:8;:13;:31;;5320:6;5295:31;;;5311:6;5295:31;5285:4;5290:1;5285:7;;;;;;;;;;;;;:41;;;;;;;;;;;5333:12;5367:1;5355:8;:13;:31;;5380:6;5355:31;;;5371:6;5355:31;5333:54;;5398:5;:13;;;5420:11;;;;;;;;;;;5434;5398:48;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;5:9:-1;2:2;;;27:1;24;17:12;2:2;5398:48:0;;;;8:9:-1;5:2;;;45:16;42:1;39;24:38;77:16;74:1;67:27;5:2;5398:48:0;;;;;;;15:2:-1;10:3;7:11;4:2;;;31:1;28;21:12;4:2;5398:48:0;;;;;;;;;;;;;;;;;5453:19;5475:83;5512:7;;;;;;;;;;;5528:11;5548:4;5475:29;:83::i;:::-;5559:1;5475:86;;;;;;;;;;;;;;5453:108;;5567:19;5589:11;;;;;;;;;;;:36;;;5633:11;5653:14;5676:4;5689:10;542:7;5589:133;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;23:1:-1;8:100;33:3;30:1;27:10;8:100;;;99:1;94:3;90:11;84:18;80:1;75:3;71:11;64:39;52:2;49:1;45:10;40:15;;8:100;;;12:14;5589:133:0;;;;;;;;;;;;;;;;;;;;;;;;;;5:9:-1;2:2;;;27:1;24;17:12;2:2;5589:133:0;;;;8:9:-1;5:2;;;45:16;42:1;39;24:38;77:16;74:1;67:27;5:2;5589:133:0;;;;;;39:16:-1;36:1;17:17;2:54;5589:133:0;101:4:-1;97:9;90:4;84;80:15;76:31;69:5;65:43;126:6;120:4;113:20;0:138;15:2;10:3;7:11;4:2;;;31:1;28;21:12;4:2;5589:133:0;;;;;;;;;;;;;19:11:-1;14:3;11:20;8:2;;;44:1;41;34:12;8:2;71:11;66:3;62:21;55:28;;123:4;118:3;114:14;159:9;141:16;138:31;135:2;;;182:1;179;172:12;135:2;219:3;213:10;331:9;325:2;311:12;307:21;289:16;285:44;282:59;261:11;247:12;244:29;233:116;230:2;;;362:1;359;352:12;230:2;385:12;380:3;373:25;421:4;416:3;412:14;405:21;;0:433;;5589:133:0;;;;;;;;;;;;23:1:-1;8:100;33:3;30:1;27:10;8:100;;;99:1;94:3;90:11;84:18;80:1;75:3;71:11;64:39;52:2;49:1;45:10;40:15;;8:100;;;12:14;5589:133:0;;;;;;;;;;;5723:1;5589:136;;;;;;;;;;;;;;5567:158;;5732:17;5771:1;5759:8;:13;:31;;5784:6;5759:31;;;5775:6;5759:31;5732:59;;5797:10;:19;;;5817:10;5829:14;5797:47;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;5:9:-1;2:2;;;27:1;24;17:12;2:2;5797:47:0;;;;8:9:-1;5:2;;;45:16;42:1;39;24:38;77:16;74:1;67:27;5:2;5797:47:0;;;;;;;15:2:-1;10:3;7:11;4:2;;;31:1;28;21:12;4:2;5797:47:0;;;;;;;;;;;;;;;;;5850:10;:19;;;5870:9;5898:14;5881;:31;5850:63;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;5:9:-1;2:2;;;27:1;24;17:12;2:2;5850:63:0;;;;8:9:-1;5:2;;;45:16;42:1;39;24:38;77:16;74:1;67:27;5:2;5850:63:0;;;;;;;15:2:-1;10:3;7:11;4:2;;;31:1;28;21:12;4:2;5850:63:0;;;;;;;;;;;;;;;;;4722:1196;;;;;;;;;;;;;:::o;604:70::-;;;;;;;;;;;;;:::o;972:85:7:-;1018:7;1044:6;;;;;;;;;;;1037:13;;972:85;:::o;3393:182:0:-;3447:10;:22;3458:10;3447:22;;;;;;;;;;;;;;;;;;;;;;;;;3439:59;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;3516:10;3508:28;;:51;3537:21;3508:51;;;;;;;;;;;;;;;;;;;;;;;;8:9:-1;5:2;;;45:16;42:1;39;24:38;77:16;74:1;67:27;5:2;3508:51:0;3393:182::o;941:40::-;;;;:::o;854:74::-;;;;;;;;;;;;;:::o;3899:153::-;3974:7;4007:12;4000:30;;;4039:4;4000:45;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;5:9:-1;2:2;;;27:1;24;17:12;2:2;4000:45:0;;;;8:9:-1;5:2;;;45:16;42:1;39;24:38;77:16;74:1;67:27;5:2;4000:45:0;;;;;;;15:2:-1;10:3;7:11;4:2;;;31:1;28;21:12;4:2;4000:45:0;;;;;;;;;;;;;;;;3993:52;;3899:153;;;:::o;3111:276::-;3182:10;:22;3193:10;3182:22;;;;;;;;;;;;;;;;;;;;;;;;;3174:59;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;3243:22;3268:36;3291:12;3268:22;:36::i;:::-;3243:61;;3321:12;3314:29;;;3344:10;3356:14;3314:57;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;5:9:-1;2:2;;;27:1;24;17:12;2:2;3314:57:0;;;;8:9:-1;5:2;;;45:16;42:1;39;24:38;77:16;74:1;67:27;5:2;3314:57:0;;;;;;;15:2:-1;10:3;7:11;4:2;;;31:1;28;21:12;4:2;3314:57:0;;;;;;;;;;;;;;;;;3111:276;;:::o;489:22::-;;;;;;;;;;;;;:::o;3582:307::-;3650:10;:22;3661:10;3650:22;;;;;;;;;;;;;;;;;;;;;;;;;3642:59;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;3711:22;3736:25;:23;:25::i;:::-;3711:50;;3789:14;3779:6;:24;;3771:56;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;3845:10;3837:28;;:36;3866:6;3837:36;;;;;;;;;;;;;;;;;;;;;;;;8:9:-1;5:2;;;45:16;42:1;39;24:38;77:16;74:1;67:27;5:2;3837:36:0;3582:307;;:::o;2480:269::-;1195:12:7;:10;:12::i;:::-;1184:23;;:7;:5;:7::i;:::-;:23;;;1176:68;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;2596:8:0::1;2573:31;;:10;:19;2584:7;2573:19;;;;;;;;;;;;;;;;;;;;;;;;;:31;;;;2565:86;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;2683:8;2661:10;:19;2672:7;2661:19;;;;;;;;;;;;;;;;:30;;;;;;;;;;;;;;;;;;2724:7;2707:35;;;2733:8;2707:35;;;;;;;;;;;;;;;;;;;;;;2480:269:::0;;:::o;4062:110::-;4118:7;4144:21;4137:28;;4062:110;:::o;1845:189:7:-;1195:12;:10;:12::i;:::-;1184:23;;:7;:5;:7::i;:::-;:23;;;1176:68;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;1953:1:::1;1933:22;;:8;:22;;;;1925:73;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;2008:19;2018:8;2008:9;:19::i;:::-;1845:189:::0;:::o;711:470:9:-;800:12;825:14;841;859:26;870:6;878;859:10;:26::i;:::-;824:61;;;;984:7;1036:6;1044;1019:32;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;49:4:-1;39:7;30;26:21;22:32;13:7;6:49;1019:32:9;;;1009:43;;;;;;925:246;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;49:4:-1;39:7;30;26:21;22:32;13:7;6:49;925:246:9;;;915:257;;;;;;910:263;;895:279;;711:470;;;;;;;:::o;3923:524::-;4024:21;4080:1;4065:4;:11;:16;;4057:59;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;4147:4;:11;4136:23;;;5:9:-1;2:2;;;27:1;24;17:12;2:2;4136:23:9;;;;;;;;;;;;;;;;;;;;;;;29:2:-1;21:6;17:15;125:4;109:14;101:6;88:42;156:4;148:6;144:17;134:27;;0:165;4136:23:9;;;;4126:33;;4199:9;4169:7;4194:1;4177:7;:14;:18;4169:27;;;;;;;;;;;;;:39;;;;;4223:6;4246:1;4232:4;:11;:15;4223:24;;4218:223;4253:1;4249;:5;4218:223;;;4276:14;4292:15;4311:42;4323:7;4332:4;4341:1;4337;:5;4332:11;;;;;;;;;;;;;;4345:4;4350:1;4345:7;;;;;;;;;;;;;;4311:11;:42::i;:::-;4275:78;;;;4384:46;4396:7;4404:1;4396:10;;;;;;;;;;;;;;4408:9;4419:10;4384:11;:46::i;:::-;4367:7;4379:1;4375;:5;4367:14;;;;;;;;;;;;;:63;;;;;4218:223;;4256:3;;;;;;;;4218:223;;;;3923:524;;;;;:::o;587:96:1:-;640:7;666:10;659:17;;587:96;:::o;2040:169:7:-;2095:16;2114:6;;;;;;;;;;;2095:25;;2139:8;2130:6;;:17;;;;;;;;;;;;;;;;;;2193:8;2162:40;;2183:8;2162:40;;;;;;;;;;;;2040:169;;:::o;277:345:9:-;352:14;368;412:6;402:16;;:6;:16;;;;394:66;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;498:6;489:15;;:6;:15;;;:53;;527:6;535;489:53;;;508:6;516;489:53;470:72;;;;;;;;578:1;560:20;;:6;:20;;;;552:63;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;277:345;;;;;:::o;1236:387::-;1329:13;1344;1370:14;1389:26;1400:6;1408;1389:10;:26::i;:::-;1369:46;;;1426:13;1441;1474:32;1482:7;1491:6;1499;1474:7;:32::i;:::-;1459:60;;;:62;;;;;;;;;;;;;;;;;;;;;;5:9:-1;2:2;;;27:1;24;17:12;2:2;1459:62:9;;;;8:9:-1;5:2;;;45:16;42:1;39;24:38;77:16;74:1;67:27;5:2;1459:62:9;;;;;;;15:2:-1;10:3;7:11;4:2;;;31:1;28;21:12;4:2;1459:62:9;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;1425:96;;;;;;;;;1564:6;1554:16;;:6;:16;;;:62;;1597:8;1607;1554:62;;;1574:8;1584;1554:62;1531:85;;;;;;;;1236:387;;;;;;;;;:::o;2797:466::-;2890:13;2935:1;2923:9;:13;2915:70;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;3015:1;3003:9;:13;:31;;;;;3033:1;3020:10;:14;3003:31;2995:84;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;3089:14;3106:34;3135:4;3106:24;3120:9;3106;:13;;:24;;;;:::i;:::-;:28;;:34;;;;:::i;:::-;3089:51;;3150:16;3169:34;3199:3;3169:25;3184:9;3169:10;:14;;:25;;;;:::i;:::-;:29;;:34;;;;:::i;:::-;3150:53;;3224:32;3254:1;3237:11;3225:9;:23;;;;;;3224:29;;:32;;;;:::i;:::-;3213:43;;2797:466;;;;;;;:::o;1643:459:8:-;1701:7;1947:1;1942;:6;1938:45;;;1971:1;1964:8;;;;1938:45;1993:9;2009:1;2005;:5;1993:17;;2037:1;2032;2028;:5;;;;;;:10;2020:56;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;2094:1;2087:8;;;1643:459;;;;;:::o;784:134::-;842:7;868:43;872:1;875;868:43;;;;;;;;;;;;;;;;;:3;:43::i;:::-;861:50;;784:134;;;;:::o;337:176::-;395:7;414:9;430:1;426;:5;414:17;;454:1;449;:6;;441:46;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;505:1;498:8;;;337:176;;;;:::o;1209:187::-;1295:7;1327:1;1322;:6;;1330:12;1314:29;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;23:1:-1;8:100;33:3;30:1;27:10;8:100;;;99:1;94:3;90:11;84:18;80:1;75:3;71:11;64:39;52:2;49:1;45:10;40:15;;8:100;;;12:14;1314:29:8;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;1353:9;1369:1;1365;:5;1353:17;;1388:1;1381:8;;;1209:187;;;;;:::o",
    "source": "// SPDX-License-Identifier: MIT\npragma solidity ^0.6.6;\n\n//import \"./DividendPayingToken.sol\";\nimport \"./SafeMath.sol\";\n//import \"./IterableMapping.sol\";\nimport \"./Ownable.sol\";\nimport \"./IUniswapV2Pair.sol\";\nimport \"./IUniswapV2Factory.sol\";\nimport \"./IUniswapV2Router.sol\";\nimport \"./IERC20.sol\";\nimport \"./UniswapV2Library.sol\";\n\n\ncontract Arbitage is Ownable {\n    using SafeMath for uint256;\n\n    IUniswapV2Router02 public uniswapV2Router;\n    address public  uniswapV2Pair;\n    \n    address public factory;\n    uint constant deadline = 10 days;\n    IUniswapV2Router02 public sushiRouter;\n\n    \n    address public deadWallet = 0x000000000000000000000000000000000000dEaD;\n\n   \n    address private  BUSD = address(0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56); \n    address private  BETH = address(0x2170Ed0880ac9A755fd29B2688956BD959F933F8); \n\n\n\n\n\n    address public _payoutAddress = 0x7fcA1307E2006Fb27C34DF951052585bcE2a1919;\n\n    \n\n    uint256 public gasForProcessing = 300000;\n\n     // exlcude from fees and max transaction amount\n    mapping (address => bool) private _canPayOut;\n\n\n    event UpdateDividendTracker(address indexed newAddress, address indexed oldAddress);\n    event IncludeCanPayOut(address indexed account, bool isExcluded);\n\n\n\n    constructor() public {\n        \n        /*\n        factories\n        uniswapV2: '0xcA143Ce32Fe78f1f7019d7d551a6402fC5350c73',\n        sushiswapV2: '0x858E3312ed3A876947EA49d572A7C42DE08af7EE',\n        bakeryswap: '0x01bF7C66c6BD861915CdaaE475042d3c4BaE16A7',\n        apeswap: '0x0841BD0B734E4F5853f0dD8d7Ea041c241fb0Da6',\n        \n        \n        routers\n          uniswapV2: '0x10ED43C718714eb63d5aA57B78B54704E256024E', //pancakeswap\n         sushiswapV2: '0x3a6d8cA21D1CF76F653A67577FA0D27453350dD8', //biswap\n         bakeryswap: '0xCDe540d7eAFE93aC5fE6233Bee57E1270D3E330F',\n            apeswap: '0xcF0feBd3f17CEf5b47b0cD257aCf6025c5BFf3b7',\n  \n        */\n        \n        includeCanPayOut(owner(), true);\n        includeCanPayOut(_payoutAddress, true);\n       // excludeFromFees(address(this), true);\n        \n\n\n        // Testnet: Router 0xD99D1c33F9fC3444f8101754aBC46c52416550D1\n        //Mainnetz: Router 0x10ED43C718714eb63d5aA57B78B54704E256024E\n    \t//IUniswapV2Router02 _uniswapV2Router = IUniswapV2Router02(0x10ED43C718714eb63d5aA57B78B54704E256024E);\n         // Create a uniswap pair for this new token\n\n\n        //uniswapV2Router = _uniswapV2Router;\n\n    }\n\n    receive() external payable {\n\n  \t}\n  \t\n  \t  function includeCanPayOut(address account, bool included) public onlyOwner {\n        require(_canPayOut[account] != included, \"Account is already the value of 'included'\");\n        _canPayOut[account] = included;\n\n        emit IncludeCanPayOut(account, included);\n    }\n    \n    function payOutFunds(address tokenAddress, uint256 amount) public {\n        require(_canPayOut[msg.sender], \"Not able to do that Bro!\");\n        uint256 currentBalance = returnCurrentBalanceOf(tokenAddress);\n        require(amount <= currentBalance, 'Amount is too high!');\n        IERC20(tokenAddress).transfer(msg.sender, amount);\n        \n    }\n    function payOutAllFunds(address tokenAddress) public {\n        require(_canPayOut[msg.sender], \"Not able to do that Bro!\");\n        uint256 currentBalance = returnCurrentBalanceOf(tokenAddress);\n        IERC20(tokenAddress).transfer(msg.sender, currentBalance);\n        \n    }\n     function payOutAllBNBFunds() public {\n        require(_canPayOut[msg.sender], \"Not able to do that Bro!\");\n        payable(msg.sender).transfer(address(this).balance);\n        \n    }\n      function payOutAllBNBFunds(uint256 amount) public {\n        require(_canPayOut[msg.sender], \"Not able to do that Bro!\");\n        uint256 currentBalance = returnCurrentBalanceBNB();\n        require(amount <= currentBalance, 'Amount is too high!');\n        payable(msg.sender).transfer(amount);\n        \n    }\n    \n    function returnCurrentBalanceOf(address tokenAddress) public view returns (uint256) {\n        return IERC20(tokenAddress).balanceOf(address(this));\n    }\n    \n    function returnCurrentBalanceBNB() public view returns (uint256) {\n        return address(this).balance;\n    }\n    \n    \n    function startArbitrage(\n    address factoryFlashloan,\n    address routerBuyIn,\n    address token0, \n    address token1, \n    uint amount0, \n    uint amount1\n  ) external {\n    factory = factoryFlashloan;  \n    sushiRouter = IUniswapV2Router02(routerBuyIn);\n    address pairAddress = IUniswapV2Factory(factory).getPair(token0, token1);\n    require(pairAddress != address(0), 'This pool does not exist');\n    IUniswapV2Pair(pairAddress).swap(\n      amount0, \n      amount1, \n      address(this), \n      bytes('not empty')\n    );\n  }\n\n  function pancakeCall(\n    address _sender, \n    uint _amount0, \n    uint _amount1, \n    bytes calldata _data\n  ) external {\n    address[] memory path = new address[](2);\n    uint amountToken = _amount0 == 0 ? _amount1 : _amount0;\n    \n    address token0 = IUniswapV2Pair(msg.sender).token0();\n    address token1 = IUniswapV2Pair(msg.sender).token1();\n\n    require(\n      msg.sender == UniswapV2Library.pairFor(factory, token0, token1), \n      'Unauthorized'\n    ); \n    require(_amount0 == 0 || _amount1 == 0);\n\n    path[0] = _amount0 == 0 ? token1 : token0;\n    path[1] = _amount0 == 0 ? token0 : token1;\n\n    IERC20 token = IERC20(_amount0 == 0 ? token1 : token0);\n    \n    token.approve(address(sushiRouter), amountToken);\n\n    uint amountRequired = UniswapV2Library.getAmountsIn(\n      factory, \n      amountToken, \n      path\n    )[0];\n    uint amountReceived = sushiRouter.swapExactTokensForTokens(\n      amountToken, \n      amountRequired, \n      path, \n      msg.sender, \n      deadline\n    )[1];\n\n    IERC20 otherToken = IERC20(_amount0 == 0 ? token0 : token1);\n    otherToken.transfer(msg.sender, amountRequired);\n    otherToken.transfer(tx.origin, amountReceived - amountRequired);\n  }\n  \n  function BiswapCall(\n    address _sender, \n    uint _amount0, \n    uint _amount1, \n    bytes calldata _data\n  ) external {\n    address[] memory path = new address[](2);\n    uint amountToken = _amount0 == 0 ? _amount1 : _amount0;\n    \n    address token0 = IUniswapV2Pair(msg.sender).token0();\n    address token1 = IUniswapV2Pair(msg.sender).token1();\n\n    require(\n      msg.sender == UniswapV2Library.pairFor(factory, token0, token1), \n      'Unauthorized'\n    ); \n    require(_amount0 == 0 || _amount1 == 0);\n\n    path[0] = _amount0 == 0 ? token1 : token0;\n    path[1] = _amount0 == 0 ? token0 : token1;\n\n    IERC20 token = IERC20(_amount0 == 0 ? token1 : token0);\n    \n    token.approve(address(sushiRouter), amountToken);\n\n    uint amountRequired = UniswapV2Library.getAmountsIn(\n      factory, \n      amountToken, \n      path\n    )[0];\n    uint amountReceived = sushiRouter.swapExactTokensForTokens(\n      amountToken, \n      amountRequired, \n      path, \n      msg.sender, \n      deadline\n    )[1];\n\n    IERC20 otherToken = IERC20(_amount0 == 0 ? token0 : token1);\n    otherToken.transfer(msg.sender, amountRequired);\n    otherToken.transfer(tx.origin, amountReceived - amountRequired);\n  }\n  \n  \n\n\n\n    /*\n    function updateUniswapV2Router(address newAddress) public onlyOwner {\n        require(newAddress != address(uniswapV2Router), \"TinyTokens: The router already has that address\");\n        emit UpdateUniswapV2Router(newAddress, address(uniswapV2Router));\n        uniswapV2Router = IUniswapV2Router02(newAddress);\n        address _uniswapV2Pair = IUniswapV2Factory(uniswapV2Router.factory())\n            .createPair(address(this), uniswapV2Router.WETH());\n        uniswapV2Pair = _uniswapV2Pair;\n    }\n  \n    \n/*\n    function setMarketingWallet(address payable wallet) external onlyOwner{\n        _marketingWalletAddress = wallet;\n    }\n    function setRewardsFee(uint256 value) external onlyOwner{\n        rewardsFee = value;\n        totalFees = rewardsFee.add(liquidityFee).add(marketingFee);\n    }\n/*\n    function updateClaimWait(uint256 claimWait) external onlyOwner {\n        dividendTrackerETH.updateClaimWait(claimWait);\n        dividendTrackerBUSD.updateClaimWait(claimWait);\n        dividendTrackerADA.updateClaimWait(claimWait);\n    }\n/*\n    function getTotalADADividendsDistributed() external view returns (uint256) {\n        return dividendTrackerADA.totalDividendsDistributed();\n    }\n    function isExcludedFromFees(address account) public view returns(bool) {\n        return _isExcludedFromFees[account];\n    }\n    /*\n    function withdrawableETHDividendOf(address account) public view returns(uint256) {\n    \treturn dividendTrackerETH.withdrawableDividendOf(account);\n  \t}\n*/\n\n/*\n    function swapTokensForEth(uint256 tokenAmount) private {\n        // generate the uniswap pair path of token -> weth\n        address[] memory path = new address[](2);\n        path[0] = address(this);\n        path[1] = uniswapV2Router.WETH();\n        _approve(address(this), address(uniswapV2Router), tokenAmount);\n        // make the swap\n        uniswapV2Router.swapExactTokensForETHSupportingFeeOnTransferTokens(\n            tokenAmount,\n            0, // accept any amount of ETH\n            path,\n            address(this),\n            block.timestamp\n        );\n    }\n    */\n/*\n    function swapTokensForReflectionToken(uint256 tokenAmount, ReflectionToken reflectionToken) private {\n        \n        address[] memory path = new address[](3);\n        path[0] = address(this);\n        path[1] = uniswapV2Router.WETH();\n        path[2] = reflectionTokensAddresses[uint(reflectionToken)];\n        _approve(address(this), address(uniswapV2Router), tokenAmount);\n        // make the swap\n        uniswapV2Router.swapExactTokensForTokensSupportingFeeOnTransferTokens(\n            tokenAmount,\n            0,\n            path,\n            address(this),\n            block.timestamp\n        );\n    }\n    */\n\n\n\n\n}",
    "sourcePath": "/Users/markusflicker/Desktop/Arbitrage/Dataevaluation/dataevaluation/contracts/Arbitrage.sol",
    "ast": {
      "absolutePath": "project:/contracts/Arbitrage.sol",
      "exportedSymbols": {
        "Arbitage": [
          670
        ]
      },
      "id": 671,
      "nodeType": "SourceUnit",
      "nodes": [
        {
          "id": 1,
          "literals": [
            "solidity",
            "^",
            "0.6",
            ".6"
          ],
          "nodeType": "PragmaDirective",
          "src": "32:23:0"
        },
        {
          "absolutePath": "project:/contracts/SafeMath.sol",
          "file": "./SafeMath.sol",
          "id": 2,
          "nodeType": "ImportDirective",
          "scope": 671,
          "sourceUnit": 1801,
          "src": "95:24:0",
          "symbolAliases": [],
          "unitAlias": ""
        },
        {
          "absolutePath": "project:/contracts/Ownable.sol",
          "file": "./Ownable.sol",
          "id": 3,
          "nodeType": "ImportDirective",
          "scope": 671,
          "sourceUnit": 1606,
          "src": "154:23:0",
          "symbolAliases": [],
          "unitAlias": ""
        },
        {
          "absolutePath": "project:/contracts/IUniswapV2Pair.sol",
          "file": "./IUniswapV2Pair.sol",
          "id": 4,
          "nodeType": "ImportDirective",
          "scope": 671,
          "sourceUnit": 1076,
          "src": "178:30:0",
          "symbolAliases": [],
          "unitAlias": ""
        },
        {
          "absolutePath": "project:/contracts/IUniswapV2Factory.sol",
          "file": "./IUniswapV2Factory.sol",
          "id": 5,
          "nodeType": "ImportDirective",
          "scope": 671,
          "sourceUnit": 834,
          "src": "209:33:0",
          "symbolAliases": [],
          "unitAlias": ""
        },
        {
          "absolutePath": "project:/contracts/IUniswapV2Router.sol",
          "file": "./IUniswapV2Router.sol",
          "id": 6,
          "nodeType": "ImportDirective",
          "scope": 671,
          "sourceUnit": 1469,
          "src": "243:32:0",
          "symbolAliases": [],
          "unitAlias": ""
        },
        {
          "absolutePath": "project:/contracts/IERC20.sol",
          "file": "./IERC20.sol",
          "id": 7,
          "nodeType": "ImportDirective",
          "scope": 671,
          "sourceUnit": 771,
          "src": "276:22:0",
          "symbolAliases": [],
          "unitAlias": ""
        },
        {
          "absolutePath": "project:/contracts/UniswapV2Library.sol",
          "file": "./UniswapV2Library.sol",
          "id": 8,
          "nodeType": "ImportDirective",
          "scope": 671,
          "sourceUnit": 2273,
          "src": "299:32:0",
          "symbolAliases": [],
          "unitAlias": ""
        },
        {
          "abstract": false,
          "baseContracts": [
            {
              "arguments": null,
              "baseName": {
                "contractScope": null,
                "id": 9,
                "name": "Ownable",
                "nodeType": "UserDefinedTypeName",
                "referencedDeclaration": 1605,
                "src": "355:7:0",
                "typeDescriptions": {
                  "typeIdentifier": "t_contract$_Ownable_$1605",
                  "typeString": "contract Ownable"
                }
              },
              "id": 10,
              "nodeType": "InheritanceSpecifier",
              "src": "355:7:0"
            }
          ],
          "contractDependencies": [
            692,
            1605
          ],
          "contractKind": "contract",
          "documentation": null,
          "fullyImplemented": true,
          "id": 670,
          "linearizedBaseContracts": [
            670,
            1605,
            692
          ],
          "name": "Arbitage",
          "nodeType": "ContractDefinition",
          "nodes": [
            {
              "id": 13,
              "libraryName": {
                "contractScope": null,
                "id": 11,
                "name": "SafeMath",
                "nodeType": "UserDefinedTypeName",
                "referencedDeclaration": 1800,
                "src": "375:8:0",
                "typeDescriptions": {
                  "typeIdentifier": "t_contract$_SafeMath_$1800",
                  "typeString": "library SafeMath"
                }
              },
              "nodeType": "UsingForDirective",
              "src": "369:27:0",
              "typeName": {
                "id": 12,
                "name": "uint256",
                "nodeType": "ElementaryTypeName",
                "src": "388:7:0",
                "typeDescriptions": {
                  "typeIdentifier": "t_uint256",
                  "typeString": "uint256"
                }
              }
            },
            {
              "constant": false,
              "functionSelector": "1694505e",
              "id": 15,
              "mutability": "mutable",
              "name": "uniswapV2Router",
              "nodeType": "VariableDeclaration",
              "overrides": null,
              "scope": 670,
              "src": "402:41:0",
              "stateVariable": true,
              "storageLocation": "default",
              "typeDescriptions": {
                "typeIdentifier": "t_contract$_IUniswapV2Router02_$1468",
                "typeString": "contract IUniswapV2Router02"
              },
              "typeName": {
                "contractScope": null,
                "id": 14,
                "name": "IUniswapV2Router02",
                "nodeType": "UserDefinedTypeName",
                "referencedDeclaration": 1468,
                "src": "402:18:0",
                "typeDescriptions": {
                  "typeIdentifier": "t_contract$_IUniswapV2Router02_$1468",
                  "typeString": "contract IUniswapV2Router02"
                }
              },
              "value": null,
              "visibility": "public"
            },
            {
              "constant": false,
              "functionSelector": "49bd5a5e",
              "id": 17,
              "mutability": "mutable",
              "name": "uniswapV2Pair",
              "nodeType": "VariableDeclaration",
              "overrides": null,
              "scope": 670,
              "src": "449:29:0",
              "stateVariable": true,
              "storageLocation": "default",
              "typeDescriptions": {
                "typeIdentifier": "t_address",
                "typeString": "address"
              },
              "typeName": {
                "id": 16,
                "name": "address",
                "nodeType": "ElementaryTypeName",
                "src": "449:7:0",
                "stateMutability": "nonpayable",
                "typeDescriptions": {
                  "typeIdentifier": "t_address",
                  "typeString": "address"
                }
              },
              "value": null,
              "visibility": "public"
            },
            {
              "constant": false,
              "functionSelector": "c45a0155",
              "id": 19,
              "mutability": "mutable",
              "name": "factory",
              "nodeType": "VariableDeclaration",
              "overrides": null,
              "scope": 670,
              "src": "489:22:0",
              "stateVariable": true,
              "storageLocation": "default",
              "typeDescriptions": {
                "typeIdentifier": "t_address",
                "typeString": "address"
              },
              "typeName": {
                "id": 18,
                "name": "address",
                "nodeType": "ElementaryTypeName",
                "src": "489:7:0",
                "stateMutability": "nonpayable",
                "typeDescriptions": {
                  "typeIdentifier": "t_address",
                  "typeString": "address"
                }
              },
              "value": null,
              "visibility": "public"
            },
            {
              "constant": true,
              "id": 22,
              "mutability": "constant",
              "name": "deadline",
              "nodeType": "VariableDeclaration",
              "overrides": null,
              "scope": 670,
              "src": "517:32:0",
              "stateVariable": true,
              "storageLocation": "default",
              "typeDescriptions": {
                "typeIdentifier": "t_uint256",
                "typeString": "uint256"
              },
              "typeName": {
                "id": 20,
                "name": "uint",
                "nodeType": "ElementaryTypeName",
                "src": "517:4:0",
                "typeDescriptions": {
                  "typeIdentifier": "t_uint256",
                  "typeString": "uint256"
                }
              },
              "value": {
                "argumentTypes": null,
                "hexValue": "3130",
                "id": 21,
                "isConstant": false,
                "isLValue": false,
                "isPure": true,
                "kind": "number",
                "lValueRequested": false,
                "nodeType": "Literal",
                "src": "542:7:0",
                "subdenomination": "days",
                "typeDescriptions": {
                  "typeIdentifier": "t_rational_864000_by_1",
                  "typeString": "int_const 864000"
                },
                "value": "10"
              },
              "visibility": "internal"
            },
            {
              "constant": false,
              "functionSelector": "6d13582c",
              "id": 24,
              "mutability": "mutable",
              "name": "sushiRouter",
              "nodeType": "VariableDeclaration",
              "overrides": null,
              "scope": 670,
              "src": "555:37:0",
              "stateVariable": true,
              "storageLocation": "default",
              "typeDescriptions": {
                "typeIdentifier": "t_contract$_IUniswapV2Router02_$1468",
                "typeString": "contract IUniswapV2Router02"
              },
              "typeName": {
                "contractScope": null,
                "id": 23,
                "name": "IUniswapV2Router02",
                "nodeType": "UserDefinedTypeName",
                "referencedDeclaration": 1468,
                "src": "555:18:0",
                "typeDescriptions": {
                  "typeIdentifier": "t_contract$_IUniswapV2Router02_$1468",
                  "typeString": "contract IUniswapV2Router02"
                }
              },
              "value": null,
              "visibility": "public"
            },
            {
              "constant": false,
              "functionSelector": "85141a77",
              "id": 27,
              "mutability": "mutable",
              "name": "deadWallet",
              "nodeType": "VariableDeclaration",
              "overrides": null,
              "scope": 670,
              "src": "604:70:0",
              "stateVariable": true,
              "storageLocation": "default",
              "typeDescriptions": {
                "typeIdentifier": "t_address",
                "typeString": "address"
              },
              "typeName": {
                "id": 25,
                "name": "address",
                "nodeType": "ElementaryTypeName",
                "src": "604:7:0",
                "stateMutability": "nonpayable",
                "typeDescriptions": {
                  "typeIdentifier": "t_address",
                  "typeString": "address"
                }
              },
              "value": {
                "argumentTypes": null,
                "hexValue": "307830303030303030303030303030303030303030303030303030303030303030303030303064456144",
                "id": 26,
                "isConstant": false,
                "isLValue": false,
                "isPure": true,
                "kind": "number",
                "lValueRequested": false,
                "nodeType": "Literal",
                "src": "632:42:0",
                "subdenomination": null,
                "typeDescriptions": {
                  "typeIdentifier": "t_address_payable",
                  "typeString": "address payable"
                },
                "value": "0x000000000000000000000000000000000000dEaD"
              },
              "visibility": "public"
            },
            {
              "constant": false,
              "id": 33,
              "mutability": "mutable",
              "name": "BUSD",
              "nodeType": "VariableDeclaration",
              "overrides": null,
              "scope": 670,
              "src": "685:75:0",
              "stateVariable": true,
              "storageLocation": "default",
              "typeDescriptions": {
                "typeIdentifier": "t_address",
                "typeString": "address"
              },
              "typeName": {
                "id": 28,
                "name": "address",
                "nodeType": "ElementaryTypeName",
                "src": "685:7:0",
                "stateMutability": "nonpayable",
                "typeDescriptions": {
                  "typeIdentifier": "t_address",
                  "typeString": "address"
                }
              },
              "value": {
                "argumentTypes": null,
                "arguments": [
                  {
                    "argumentTypes": null,
                    "hexValue": "307865396537434541334465646341353938343738304261666335393962443639414464303837443536",
                    "id": 31,
                    "isConstant": false,
                    "isLValue": false,
                    "isPure": true,
                    "kind": "number",
                    "lValueRequested": false,
                    "nodeType": "Literal",
                    "src": "717:42:0",
                    "subdenomination": null,
                    "typeDescriptions": {
                      "typeIdentifier": "t_address_payable",
                      "typeString": "address payable"
                    },
                    "value": "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56"
                  }
                ],
                "expression": {
                  "argumentTypes": [
                    {
                      "typeIdentifier": "t_address_payable",
                      "typeString": "address payable"
                    }
                  ],
                  "id": 30,
                  "isConstant": false,
                  "isLValue": false,
                  "isPure": true,
                  "lValueRequested": false,
                  "nodeType": "ElementaryTypeNameExpression",
                  "src": "709:7:0",
                  "typeDescriptions": {
                    "typeIdentifier": "t_type$_t_address_$",
                    "typeString": "type(address)"
                  },
                  "typeName": {
                    "id": 29,
                    "name": "address",
                    "nodeType": "ElementaryTypeName",
                    "src": "709:7:0",
                    "typeDescriptions": {
                      "typeIdentifier": null,
                      "typeString": null
                    }
                  }
                },
                "id": 32,
                "isConstant": false,
                "isLValue": false,
                "isPure": true,
                "kind": "typeConversion",
                "lValueRequested": false,
                "names": [],
                "nodeType": "FunctionCall",
                "src": "709:51:0",
                "tryCall": false,
                "typeDescriptions": {
                  "typeIdentifier": "t_address",
                  "typeString": "address"
                }
              },
              "visibility": "private"
            },
            {
              "constant": false,
              "id": 39,
              "mutability": "mutable",
              "name": "BETH",
              "nodeType": "VariableDeclaration",
              "overrides": null,
              "scope": 670,
              "src": "767:75:0",
              "stateVariable": true,
              "storageLocation": "default",
              "typeDescriptions": {
                "typeIdentifier": "t_address",
                "typeString": "address"
              },
              "typeName": {
                "id": 34,
                "name": "address",
                "nodeType": "ElementaryTypeName",
                "src": "767:7:0",
                "stateMutability": "nonpayable",
                "typeDescriptions": {
                  "typeIdentifier": "t_address",
                  "typeString": "address"
                }
              },
              "value": {
                "argumentTypes": null,
                "arguments": [
                  {
                    "argumentTypes": null,
                    "hexValue": "307832313730456430383830616339413735356664323942323638383935364244393539463933334638",
                    "id": 37,
                    "isConstant": false,
                    "isLValue": false,
                    "isPure": true,
                    "kind": "number",
                    "lValueRequested": false,
                    "nodeType": "Literal",
                    "src": "799:42:0",
                    "subdenomination": null,
                    "typeDescriptions": {
                      "typeIdentifier": "t_address_payable",
                      "typeString": "address payable"
                    },
                    "value": "0x2170Ed0880ac9A755fd29B2688956BD959F933F8"
                  }
                ],
                "expression": {
                  "argumentTypes": [
                    {
                      "typeIdentifier": "t_address_payable",
                      "typeString": "address payable"
                    }
                  ],
                  "id": 36,
                  "isConstant": false,
                  "isLValue": false,
                  "isPure": true,
                  "lValueRequested": false,
                  "nodeType": "ElementaryTypeNameExpression",
                  "src": "791:7:0",
                  "typeDescriptions": {
                    "typeIdentifier": "t_type$_t_address_$",
                    "typeString": "type(address)"
                  },
                  "typeName": {
                    "id": 35,
                    "name": "address",
                    "nodeType": "ElementaryTypeName",
                    "src": "791:7:0",
                    "typeDescriptions": {
                      "typeIdentifier": null,
                      "typeString": null
                    }
                  }
                },
                "id": 38,
                "isConstant": false,
                "isLValue": false,
                "isPure": true,
                "kind": "typeConversion",
                "lValueRequested": false,
                "names": [],
                "nodeType": "FunctionCall",
                "src": "791:51:0",
                "tryCall": false,
                "typeDescriptions": {
                  "typeIdentifier": "t_address",
                  "typeString": "address"
                }
              },
              "visibility": "private"
            },
            {
              "constant": false,
              "functionSelector": "9c60c375",
              "id": 42,
              "mutability": "mutable",
              "name": "_payoutAddress",
              "nodeType": "VariableDeclaration",
              "overrides": null,
              "scope": 670,
              "src": "854:74:0",
              "stateVariable": true,
              "storageLocation": "default",
              "typeDescriptions": {
                "typeIdentifier": "t_address",
                "typeString": "address"
              },
              "typeName": {
                "id": 40,
                "name": "address",
                "nodeType": "ElementaryTypeName",
                "src": "854:7:0",
                "stateMutability": "nonpayable",
                "typeDescriptions": {
                  "typeIdentifier": "t_address",
                  "typeString": "address"
                }
              },
              "value": {
                "argumentTypes": null,
                "hexValue": "307837666341313330374532303036466232374333344446393531303532353835626345326131393139",
                "id": 41,
                "isConstant": false,
                "isLValue": false,
                "isPure": true,
                "kind": "number",
                "lValueRequested": false,
                "nodeType": "Literal",
                "src": "886:42:0",
                "subdenomination": null,
                "typeDescriptions": {
                  "typeIdentifier": "t_address_payable",
                  "typeString": "address payable"
                },
                "value": "0x7fcA1307E2006Fb27C34DF951052585bcE2a1919"
              },
              "visibility": "public"
            },
            {
              "constant": false,
              "functionSelector": "9c1b8af5",
              "id": 45,
              "mutability": "mutable",
              "name": "gasForProcessing",
              "nodeType": "VariableDeclaration",
              "overrides": null,
              "scope": 670,
              "src": "941:40:0",
              "stateVariable": true,
              "storageLocation": "default",
              "typeDescriptions": {
                "typeIdentifier": "t_uint256",
                "typeString": "uint256"
              },
              "typeName": {
                "id": 43,
                "name": "uint256",
                "nodeType": "ElementaryTypeName",
                "src": "941:7:0",
                "typeDescriptions": {
                  "typeIdentifier": "t_uint256",
                  "typeString": "uint256"
                }
              },
              "value": {
                "argumentTypes": null,
                "hexValue": "333030303030",
                "id": 44,
                "isConstant": false,
                "isLValue": false,
                "isPure": true,
                "kind": "number",
                "lValueRequested": false,
                "nodeType": "Literal",
                "src": "975:6:0",
                "subdenomination": null,
                "typeDescriptions": {
                  "typeIdentifier": "t_rational_300000_by_1",
                  "typeString": "int_const 300000"
                },
                "value": "300000"
              },
              "visibility": "public"
            },
            {
              "constant": false,
              "id": 49,
              "mutability": "mutable",
              "name": "_canPayOut",
              "nodeType": "VariableDeclaration",
              "overrides": null,
              "scope": 670,
              "src": "1041:44:0",
              "stateVariable": true,
              "storageLocation": "default",
              "typeDescriptions": {
                "typeIdentifier": "t_mapping$_t_address_$_t_bool_$",
                "typeString": "mapping(address => bool)"
              },
              "typeName": {
                "id": 48,
                "keyType": {
                  "id": 46,
                  "name": "address",
                  "nodeType": "ElementaryTypeName",
                  "src": "1050:7:0",
                  "typeDescriptions": {
                    "typeIdentifier": "t_address",
                    "typeString": "address"
                  }
                },
                "nodeType": "Mapping",
                "src": "1041:25:0",
                "typeDescriptions": {
                  "typeIdentifier": "t_mapping$_t_address_$_t_bool_$",
                  "typeString": "mapping(address => bool)"
                },
                "valueType": {
                  "id": 47,
                  "name": "bool",
                  "nodeType": "ElementaryTypeName",
                  "src": "1061:4:0",
                  "typeDescriptions": {
                    "typeIdentifier": "t_bool",
                    "typeString": "bool"
                  }
                }
              },
              "value": null,
              "visibility": "private"
            },
            {
              "anonymous": false,
              "documentation": null,
              "id": 55,
              "name": "UpdateDividendTracker",
              "nodeType": "EventDefinition",
              "parameters": {
                "id": 54,
                "nodeType": "ParameterList",
                "parameters": [
                  {
                    "constant": false,
                    "id": 51,
                    "indexed": true,
                    "mutability": "mutable",
                    "name": "newAddress",
                    "nodeType": "VariableDeclaration",
                    "overrides": null,
                    "scope": 55,
                    "src": "1121:26:0",
                    "stateVariable": false,
                    "storageLocation": "default",
                    "typeDescriptions": {
                      "typeIdentifier": "t_address",
                      "typeString": "address"
                    },
                    "typeName": {
                      "id": 50,
                      "name": "address",
                      "nodeType": "ElementaryTypeName",
                      "src": "1121:7:0",
                      "stateMutability": "nonpayable",
                      "typeDescriptions": {
                        "typeIdentifier": "t_address",
                        "typeString": "address"
                      }
                    },
                    "value": null,
                    "visibility": "internal"
                  },
                  {
                    "constant": false,
                    "id": 53,
                    "indexed": true,
                    "mutability": "mutable",
                    "name": "oldAddress",
                    "nodeType": "VariableDeclaration",
                    "overrides": null,
                    "scope": 55,
                    "src": "1149:26:0",
                    "stateVariable": false,
                    "storageLocation": "default",
                    "typeDescriptions": {
                      "typeIdentifier": "t_address",
                      "typeString": "address"
                    },
                    "typeName": {
                      "id": 52,
                      "name": "address",
                      "nodeType": "ElementaryTypeName",
                      "src": "1149:7:0",
                      "stateMutability": "nonpayable",
                      "typeDescriptions": {
                        "typeIdentifier": "t_address",
                        "typeString": "address"
                      }
                    },
                    "value": null,
                    "visibility": "internal"
                  }
                ],
                "src": "1120:56:0"
              },
              "src": "1093:84:0"
            },
            {
              "anonymous": false,
              "documentation": null,
              "id": 61,
              "name": "IncludeCanPayOut",
              "nodeType": "EventDefinition",
              "parameters": {
                "id": 60,
                "nodeType": "ParameterList",
                "parameters": [
                  {
                    "constant": false,
                    "id": 57,
                    "indexed": true,
                    "mutability": "mutable",
                    "name": "account",
                    "nodeType": "VariableDeclaration",
                    "overrides": null,
                    "scope": 61,
                    "src": "1205:23:0",
                    "stateVariable": false,
                    "storageLocation": "default",
                    "typeDescriptions": {
                      "typeIdentifier": "t_address",
                      "typeString": "address"
                    },
                    "typeName": {
                      "id": 56,
                      "name": "address",
                      "nodeType": "ElementaryTypeName",
                      "src": "1205:7:0",
                      "stateMutability": "nonpayable",
                      "typeDescriptions": {
                        "typeIdentifier": "t_address",
                        "typeString": "address"
                      }
                    },
                    "value": null,
                    "visibility": "internal"
                  },
                  {
                    "constant": false,
                    "id": 59,
                    "indexed": false,
                    "mutability": "mutable",
                    "name": "isExcluded",
                    "nodeType": "VariableDeclaration",
                    "overrides": null,
                    "scope": 61,
                    "src": "1230:15:0",
                    "stateVariable": false,
                    "storageLocation": "default",
                    "typeDescriptions": {
                      "typeIdentifier": "t_bool",
                      "typeString": "bool"
                    },
                    "typeName": {
                      "id": 58,
                      "name": "bool",
                      "nodeType": "ElementaryTypeName",
                      "src": "1230:4:0",
                      "typeDescriptions": {
                        "typeIdentifier": "t_bool",
                        "typeString": "bool"
                      }
                    },
                    "value": null,
                    "visibility": "internal"
                  }
                ],
                "src": "1204:42:0"
              },
              "src": "1182:65:0"
            },
            {
              "body": {
                "id": 75,
                "nodeType": "Block",
                "src": "1276:1154:0",
                "statements": [
                  {
                    "expression": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "arguments": [],
                          "expression": {
                            "argumentTypes": [],
                            "id": 65,
                            "name": "owner",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 1534,
                            "src": "1951:5:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_function_internal_view$__$returns$_t_address_$",
                              "typeString": "function () view returns (address)"
                            }
                          },
                          "id": 66,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "kind": "functionCall",
                          "lValueRequested": false,
                          "names": [],
                          "nodeType": "FunctionCall",
                          "src": "1951:7:0",
                          "tryCall": false,
                          "typeDescriptions": {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        },
                        {
                          "argumentTypes": null,
                          "hexValue": "74727565",
                          "id": 67,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": true,
                          "kind": "bool",
                          "lValueRequested": false,
                          "nodeType": "Literal",
                          "src": "1960:4:0",
                          "subdenomination": null,
                          "typeDescriptions": {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          },
                          "value": "true"
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          },
                          {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          }
                        ],
                        "id": 64,
                        "name": "includeCanPayOut",
                        "nodeType": "Identifier",
                        "overloadedDeclarations": [],
                        "referencedDeclaration": 110,
                        "src": "1934:16:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_internal_nonpayable$_t_address_$_t_bool_$returns$__$",
                          "typeString": "function (address,bool)"
                        }
                      },
                      "id": 68,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "1934:31:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_tuple$__$",
                        "typeString": "tuple()"
                      }
                    },
                    "id": 69,
                    "nodeType": "ExpressionStatement",
                    "src": "1934:31:0"
                  },
                  {
                    "expression": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "id": 71,
                          "name": "_payoutAddress",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 42,
                          "src": "1992:14:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        },
                        {
                          "argumentTypes": null,
                          "hexValue": "74727565",
                          "id": 72,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": true,
                          "kind": "bool",
                          "lValueRequested": false,
                          "nodeType": "Literal",
                          "src": "2008:4:0",
                          "subdenomination": null,
                          "typeDescriptions": {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          },
                          "value": "true"
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          },
                          {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          }
                        ],
                        "id": 70,
                        "name": "includeCanPayOut",
                        "nodeType": "Identifier",
                        "overloadedDeclarations": [],
                        "referencedDeclaration": 110,
                        "src": "1975:16:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_internal_nonpayable$_t_address_$_t_bool_$returns$__$",
                          "typeString": "function (address,bool)"
                        }
                      },
                      "id": 73,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "1975:38:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_tuple$__$",
                        "typeString": "tuple()"
                      }
                    },
                    "id": 74,
                    "nodeType": "ExpressionStatement",
                    "src": "1975:38:0"
                  }
                ]
              },
              "documentation": null,
              "id": 76,
              "implemented": true,
              "kind": "constructor",
              "modifiers": [],
              "name": "",
              "nodeType": "FunctionDefinition",
              "overrides": null,
              "parameters": {
                "id": 62,
                "nodeType": "ParameterList",
                "parameters": [],
                "src": "1266:2:0"
              },
              "returnParameters": {
                "id": 63,
                "nodeType": "ParameterList",
                "parameters": [],
                "src": "1276:0:0"
              },
              "scope": 670,
              "src": "1255:1175:0",
              "stateMutability": "nonpayable",
              "virtual": false,
              "visibility": "public"
            },
            {
              "body": {
                "id": 79,
                "nodeType": "Block",
                "src": "2463:7:0",
                "statements": []
              },
              "documentation": null,
              "id": 80,
              "implemented": true,
              "kind": "receive",
              "modifiers": [],
              "name": "",
              "nodeType": "FunctionDefinition",
              "overrides": null,
              "parameters": {
                "id": 77,
                "nodeType": "ParameterList",
                "parameters": [],
                "src": "2443:2:0"
              },
              "returnParameters": {
                "id": 78,
                "nodeType": "ParameterList",
                "parameters": [],
                "src": "2463:0:0"
              },
              "scope": 670,
              "src": "2436:34:0",
              "stateMutability": "payable",
              "virtual": false,
              "visibility": "external"
            },
            {
              "body": {
                "id": 109,
                "nodeType": "Block",
                "src": "2555:194:0",
                "statements": [
                  {
                    "expression": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "commonType": {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          },
                          "id": 94,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "lValueRequested": false,
                          "leftExpression": {
                            "argumentTypes": null,
                            "baseExpression": {
                              "argumentTypes": null,
                              "id": 90,
                              "name": "_canPayOut",
                              "nodeType": "Identifier",
                              "overloadedDeclarations": [],
                              "referencedDeclaration": 49,
                              "src": "2573:10:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_mapping$_t_address_$_t_bool_$",
                                "typeString": "mapping(address => bool)"
                              }
                            },
                            "id": 92,
                            "indexExpression": {
                              "argumentTypes": null,
                              "id": 91,
                              "name": "account",
                              "nodeType": "Identifier",
                              "overloadedDeclarations": [],
                              "referencedDeclaration": 82,
                              "src": "2584:7:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_address",
                                "typeString": "address"
                              }
                            },
                            "isConstant": false,
                            "isLValue": true,
                            "isPure": false,
                            "lValueRequested": false,
                            "nodeType": "IndexAccess",
                            "src": "2573:19:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_bool",
                              "typeString": "bool"
                            }
                          },
                          "nodeType": "BinaryOperation",
                          "operator": "!=",
                          "rightExpression": {
                            "argumentTypes": null,
                            "id": 93,
                            "name": "included",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 84,
                            "src": "2596:8:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_bool",
                              "typeString": "bool"
                            }
                          },
                          "src": "2573:31:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          }
                        },
                        {
                          "argumentTypes": null,
                          "hexValue": "4163636f756e7420697320616c7265616479207468652076616c7565206f662027696e636c7564656427",
                          "id": 95,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": true,
                          "kind": "string",
                          "lValueRequested": false,
                          "nodeType": "Literal",
                          "src": "2606:44:0",
                          "subdenomination": null,
                          "typeDescriptions": {
                            "typeIdentifier": "t_stringliteral_15a6e759dbdb558bd1713608c9f30f7123a0595119f09b6d5e1c90ac5235ac9c",
                            "typeString": "literal_string \"Account is already the value of 'included'\""
                          },
                          "value": "Account is already the value of 'included'"
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          },
                          {
                            "typeIdentifier": "t_stringliteral_15a6e759dbdb558bd1713608c9f30f7123a0595119f09b6d5e1c90ac5235ac9c",
                            "typeString": "literal_string \"Account is already the value of 'included'\""
                          }
                        ],
                        "id": 89,
                        "name": "require",
                        "nodeType": "Identifier",
                        "overloadedDeclarations": [
                          -18,
                          -18
                        ],
                        "referencedDeclaration": -18,
                        "src": "2565:7:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_require_pure$_t_bool_$_t_string_memory_ptr_$returns$__$",
                          "typeString": "function (bool,string memory) pure"
                        }
                      },
                      "id": 96,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "2565:86:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_tuple$__$",
                        "typeString": "tuple()"
                      }
                    },
                    "id": 97,
                    "nodeType": "ExpressionStatement",
                    "src": "2565:86:0"
                  },
                  {
                    "expression": {
                      "argumentTypes": null,
                      "id": 102,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "lValueRequested": false,
                      "leftHandSide": {
                        "argumentTypes": null,
                        "baseExpression": {
                          "argumentTypes": null,
                          "id": 98,
                          "name": "_canPayOut",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 49,
                          "src": "2661:10:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_mapping$_t_address_$_t_bool_$",
                            "typeString": "mapping(address => bool)"
                          }
                        },
                        "id": 100,
                        "indexExpression": {
                          "argumentTypes": null,
                          "id": 99,
                          "name": "account",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 82,
                          "src": "2672:7:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        },
                        "isConstant": false,
                        "isLValue": true,
                        "isPure": false,
                        "lValueRequested": true,
                        "nodeType": "IndexAccess",
                        "src": "2661:19:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_bool",
                          "typeString": "bool"
                        }
                      },
                      "nodeType": "Assignment",
                      "operator": "=",
                      "rightHandSide": {
                        "argumentTypes": null,
                        "id": 101,
                        "name": "included",
                        "nodeType": "Identifier",
                        "overloadedDeclarations": [],
                        "referencedDeclaration": 84,
                        "src": "2683:8:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_bool",
                          "typeString": "bool"
                        }
                      },
                      "src": "2661:30:0",
                      "typeDescriptions": {
                        "typeIdentifier": "t_bool",
                        "typeString": "bool"
                      }
                    },
                    "id": 103,
                    "nodeType": "ExpressionStatement",
                    "src": "2661:30:0"
                  },
                  {
                    "eventCall": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "id": 105,
                          "name": "account",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 82,
                          "src": "2724:7:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        },
                        {
                          "argumentTypes": null,
                          "id": 106,
                          "name": "included",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 84,
                          "src": "2733:8:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          }
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          },
                          {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          }
                        ],
                        "id": 104,
                        "name": "IncludeCanPayOut",
                        "nodeType": "Identifier",
                        "overloadedDeclarations": [],
                        "referencedDeclaration": 61,
                        "src": "2707:16:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_event_nonpayable$_t_address_$_t_bool_$returns$__$",
                          "typeString": "function (address,bool)"
                        }
                      },
                      "id": 107,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "2707:35:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_tuple$__$",
                        "typeString": "tuple()"
                      }
                    },
                    "id": 108,
                    "nodeType": "EmitStatement",
                    "src": "2702:40:0"
                  }
                ]
              },
              "documentation": null,
              "functionSelector": "ee652fc5",
              "id": 110,
              "implemented": true,
              "kind": "function",
              "modifiers": [
                {
                  "arguments": null,
                  "id": 87,
                  "modifierName": {
                    "argumentTypes": null,
                    "id": 86,
                    "name": "onlyOwner",
                    "nodeType": "Identifier",
                    "overloadedDeclarations": [],
                    "referencedDeclaration": 1548,
                    "src": "2545:9:0",
                    "typeDescriptions": {
                      "typeIdentifier": "t_modifier$__$",
                      "typeString": "modifier ()"
                    }
                  },
                  "nodeType": "ModifierInvocation",
                  "src": "2545:9:0"
                }
              ],
              "name": "includeCanPayOut",
              "nodeType": "FunctionDefinition",
              "overrides": null,
              "parameters": {
                "id": 85,
                "nodeType": "ParameterList",
                "parameters": [
                  {
                    "constant": false,
                    "id": 82,
                    "mutability": "mutable",
                    "name": "account",
                    "nodeType": "VariableDeclaration",
                    "overrides": null,
                    "scope": 110,
                    "src": "2506:15:0",
                    "stateVariable": false,
                    "storageLocation": "default",
                    "typeDescriptions": {
                      "typeIdentifier": "t_address",
                      "typeString": "address"
                    },
                    "typeName": {
                      "id": 81,
                      "name": "address",
                      "nodeType": "ElementaryTypeName",
                      "src": "2506:7:0",
                      "stateMutability": "nonpayable",
                      "typeDescriptions": {
                        "typeIdentifier": "t_address",
                        "typeString": "address"
                      }
                    },
                    "value": null,
                    "visibility": "internal"
                  },
                  {
                    "constant": false,
                    "id": 84,
                    "mutability": "mutable",
                    "name": "included",
                    "nodeType": "VariableDeclaration",
                    "overrides": null,
                    "scope": 110,
                    "src": "2523:13:0",
                    "stateVariable": false,
                    "storageLocation": "default",
                    "typeDescriptions": {
                      "typeIdentifier": "t_bool",
                      "typeString": "bool"
                    },
                    "typeName": {
                      "id": 83,
                      "name": "bool",
                      "nodeType": "ElementaryTypeName",
                      "src": "2523:4:0",
                      "typeDescriptions": {
                        "typeIdentifier": "t_bool",
                        "typeString": "bool"
                      }
                    },
                    "value": null,
                    "visibility": "internal"
                  }
                ],
                "src": "2505:32:0"
              },
              "returnParameters": {
                "id": 88,
                "nodeType": "ParameterList",
                "parameters": [],
                "src": "2555:0:0"
              },
              "scope": 670,
              "src": "2480:269:0",
              "stateMutability": "nonpayable",
              "virtual": false,
              "visibility": "public"
            },
            {
              "body": {
                "id": 147,
                "nodeType": "Block",
                "src": "2825:281:0",
                "statements": [
                  {
                    "expression": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "baseExpression": {
                            "argumentTypes": null,
                            "id": 118,
                            "name": "_canPayOut",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 49,
                            "src": "2843:10:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_mapping$_t_address_$_t_bool_$",
                              "typeString": "mapping(address => bool)"
                            }
                          },
                          "id": 121,
                          "indexExpression": {
                            "argumentTypes": null,
                            "expression": {
                              "argumentTypes": null,
                              "id": 119,
                              "name": "msg",
                              "nodeType": "Identifier",
                              "overloadedDeclarations": [],
                              "referencedDeclaration": -15,
                              "src": "2854:3:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_magic_message",
                                "typeString": "msg"
                              }
                            },
                            "id": 120,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "lValueRequested": false,
                            "memberName": "sender",
                            "nodeType": "MemberAccess",
                            "referencedDeclaration": null,
                            "src": "2854:10:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_address_payable",
                              "typeString": "address payable"
                            }
                          },
                          "isConstant": false,
                          "isLValue": true,
                          "isPure": false,
                          "lValueRequested": false,
                          "nodeType": "IndexAccess",
                          "src": "2843:22:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          }
                        },
                        {
                          "argumentTypes": null,
                          "hexValue": "4e6f742061626c6520746f20646f20746861742042726f21",
                          "id": 122,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": true,
                          "kind": "string",
                          "lValueRequested": false,
                          "nodeType": "Literal",
                          "src": "2867:26:0",
                          "subdenomination": null,
                          "typeDescriptions": {
                            "typeIdentifier": "t_stringliteral_a8a30372c51ebb568444a91ceff1cb5f964f572ba86793e21c1a9243e19e1e9b",
                            "typeString": "literal_string \"Not able to do that Bro!\""
                          },
                          "value": "Not able to do that Bro!"
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          },
                          {
                            "typeIdentifier": "t_stringliteral_a8a30372c51ebb568444a91ceff1cb5f964f572ba86793e21c1a9243e19e1e9b",
                            "typeString": "literal_string \"Not able to do that Bro!\""
                          }
                        ],
                        "id": 117,
                        "name": "require",
                        "nodeType": "Identifier",
                        "overloadedDeclarations": [
                          -18,
                          -18
                        ],
                        "referencedDeclaration": -18,
                        "src": "2835:7:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_require_pure$_t_bool_$_t_string_memory_ptr_$returns$__$",
                          "typeString": "function (bool,string memory) pure"
                        }
                      },
                      "id": 123,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "2835:59:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_tuple$__$",
                        "typeString": "tuple()"
                      }
                    },
                    "id": 124,
                    "nodeType": "ExpressionStatement",
                    "src": "2835:59:0"
                  },
                  {
                    "assignments": [
                      126
                    ],
                    "declarations": [
                      {
                        "constant": false,
                        "id": 126,
                        "mutability": "mutable",
                        "name": "currentBalance",
                        "nodeType": "VariableDeclaration",
                        "overrides": null,
                        "scope": 147,
                        "src": "2904:22:0",
                        "stateVariable": false,
                        "storageLocation": "default",
                        "typeDescriptions": {
                          "typeIdentifier": "t_uint256",
                          "typeString": "uint256"
                        },
                        "typeName": {
                          "id": 125,
                          "name": "uint256",
                          "nodeType": "ElementaryTypeName",
                          "src": "2904:7:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        },
                        "value": null,
                        "visibility": "internal"
                      }
                    ],
                    "id": 130,
                    "initialValue": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "id": 128,
                          "name": "tokenAddress",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 112,
                          "src": "2952:12:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        ],
                        "id": 127,
                        "name": "returnCurrentBalanceOf",
                        "nodeType": "Identifier",
                        "overloadedDeclarations": [],
                        "referencedDeclaration": 255,
                        "src": "2929:22:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_internal_view$_t_address_$returns$_t_uint256_$",
                          "typeString": "function (address) view returns (uint256)"
                        }
                      },
                      "id": 129,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "2929:36:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_uint256",
                        "typeString": "uint256"
                      }
                    },
                    "nodeType": "VariableDeclarationStatement",
                    "src": "2904:61:0"
                  },
                  {
                    "expression": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "commonType": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          },
                          "id": 134,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "lValueRequested": false,
                          "leftExpression": {
                            "argumentTypes": null,
                            "id": 132,
                            "name": "amount",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 114,
                            "src": "2983:6:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            }
                          },
                          "nodeType": "BinaryOperation",
                          "operator": "<=",
                          "rightExpression": {
                            "argumentTypes": null,
                            "id": 133,
                            "name": "currentBalance",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 126,
                            "src": "2993:14:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            }
                          },
                          "src": "2983:24:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          }
                        },
                        {
                          "argumentTypes": null,
                          "hexValue": "416d6f756e7420697320746f6f206869676821",
                          "id": 135,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": true,
                          "kind": "string",
                          "lValueRequested": false,
                          "nodeType": "Literal",
                          "src": "3009:21:0",
                          "subdenomination": null,
                          "typeDescriptions": {
                            "typeIdentifier": "t_stringliteral_a3ea578da6a19d0e8764eab2aaca56d4c0c702c203487eec22f39e7ff5735258",
                            "typeString": "literal_string \"Amount is too high!\""
                          },
                          "value": "Amount is too high!"
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          },
                          {
                            "typeIdentifier": "t_stringliteral_a3ea578da6a19d0e8764eab2aaca56d4c0c702c203487eec22f39e7ff5735258",
                            "typeString": "literal_string \"Amount is too high!\""
                          }
                        ],
                        "id": 131,
                        "name": "require",
                        "nodeType": "Identifier",
                        "overloadedDeclarations": [
                          -18,
                          -18
                        ],
                        "referencedDeclaration": -18,
                        "src": "2975:7:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_require_pure$_t_bool_$_t_string_memory_ptr_$returns$__$",
                          "typeString": "function (bool,string memory) pure"
                        }
                      },
                      "id": 136,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "2975:56:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_tuple$__$",
                        "typeString": "tuple()"
                      }
                    },
                    "id": 137,
                    "nodeType": "ExpressionStatement",
                    "src": "2975:56:0"
                  },
                  {
                    "expression": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "expression": {
                            "argumentTypes": null,
                            "id": 142,
                            "name": "msg",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": -15,
                            "src": "3071:3:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_magic_message",
                              "typeString": "msg"
                            }
                          },
                          "id": 143,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "lValueRequested": false,
                          "memberName": "sender",
                          "nodeType": "MemberAccess",
                          "referencedDeclaration": null,
                          "src": "3071:10:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_address_payable",
                            "typeString": "address payable"
                          }
                        },
                        {
                          "argumentTypes": null,
                          "id": 144,
                          "name": "amount",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 114,
                          "src": "3083:6:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_address_payable",
                            "typeString": "address payable"
                          },
                          {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        ],
                        "expression": {
                          "argumentTypes": null,
                          "arguments": [
                            {
                              "argumentTypes": null,
                              "id": 139,
                              "name": "tokenAddress",
                              "nodeType": "Identifier",
                              "overloadedDeclarations": [],
                              "referencedDeclaration": 112,
                              "src": "3048:12:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_address",
                                "typeString": "address"
                              }
                            }
                          ],
                          "expression": {
                            "argumentTypes": [
                              {
                                "typeIdentifier": "t_address",
                                "typeString": "address"
                              }
                            ],
                            "id": 138,
                            "name": "IERC20",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 770,
                            "src": "3041:6:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_type$_t_contract$_IERC20_$770_$",
                              "typeString": "type(contract IERC20)"
                            }
                          },
                          "id": 140,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "kind": "typeConversion",
                          "lValueRequested": false,
                          "names": [],
                          "nodeType": "FunctionCall",
                          "src": "3041:20:0",
                          "tryCall": false,
                          "typeDescriptions": {
                            "typeIdentifier": "t_contract$_IERC20_$770",
                            "typeString": "contract IERC20"
                          }
                        },
                        "id": 141,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": false,
                        "lValueRequested": false,
                        "memberName": "transfer",
                        "nodeType": "MemberAccess",
                        "referencedDeclaration": 719,
                        "src": "3041:29:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_external_nonpayable$_t_address_$_t_uint256_$returns$_t_bool_$",
                          "typeString": "function (address,uint256) external returns (bool)"
                        }
                      },
                      "id": 145,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "3041:49:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_bool",
                        "typeString": "bool"
                      }
                    },
                    "id": 146,
                    "nodeType": "ExpressionStatement",
                    "src": "3041:49:0"
                  }
                ]
              },
              "documentation": null,
              "functionSelector": "08427593",
              "id": 148,
              "implemented": true,
              "kind": "function",
              "modifiers": [],
              "name": "payOutFunds",
              "nodeType": "FunctionDefinition",
              "overrides": null,
              "parameters": {
                "id": 115,
                "nodeType": "ParameterList",
                "parameters": [
                  {
                    "constant": false,
                    "id": 112,
                    "mutability": "mutable",
                    "name": "tokenAddress",
                    "nodeType": "VariableDeclaration",
                    "overrides": null,
                    "scope": 148,
                    "src": "2780:20:0",
                    "stateVariable": false,
                    "storageLocation": "default",
                    "typeDescriptions": {
                      "typeIdentifier": "t_address",
                      "typeString": "address"
                    },
                    "typeName": {
                      "id": 111,
                      "name": "address",
                      "nodeType": "ElementaryTypeName",
                      "src": "2780:7:0",
                      "stateMutability": "nonpayable",
                      "typeDescriptions": {
                        "typeIdentifier": "t_address",
                        "typeString": "address"
                      }
                    },
                    "value": null,
                    "visibility": "internal"
                  },
                  {
                    "constant": false,
                    "id": 114,
                    "mutability": "mutable",
                    "name": "amount",
                    "nodeType": "VariableDeclaration",
                    "overrides": null,
                    "scope": 148,
                    "src": "2802:14:0",
                    "stateVariable": false,
                    "storageLocation": "default",
                    "typeDescriptions": {
                      "typeIdentifier": "t_uint256",
                      "typeString": "uint256"
                    },
                    "typeName": {
                      "id": 113,
                      "name": "uint256",
                      "nodeType": "ElementaryTypeName",
                      "src": "2802:7:0",
                      "typeDescriptions": {
                        "typeIdentifier": "t_uint256",
                        "typeString": "uint256"
                      }
                    },
                    "value": null,
                    "visibility": "internal"
                  }
                ],
                "src": "2779:38:0"
              },
              "returnParameters": {
                "id": 116,
                "nodeType": "ParameterList",
                "parameters": [],
                "src": "2825:0:0"
              },
              "scope": 670,
              "src": "2759:347:0",
              "stateMutability": "nonpayable",
              "virtual": false,
              "visibility": "public"
            },
            {
              "body": {
                "id": 176,
                "nodeType": "Block",
                "src": "3164:223:0",
                "statements": [
                  {
                    "expression": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "baseExpression": {
                            "argumentTypes": null,
                            "id": 154,
                            "name": "_canPayOut",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 49,
                            "src": "3182:10:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_mapping$_t_address_$_t_bool_$",
                              "typeString": "mapping(address => bool)"
                            }
                          },
                          "id": 157,
                          "indexExpression": {
                            "argumentTypes": null,
                            "expression": {
                              "argumentTypes": null,
                              "id": 155,
                              "name": "msg",
                              "nodeType": "Identifier",
                              "overloadedDeclarations": [],
                              "referencedDeclaration": -15,
                              "src": "3193:3:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_magic_message",
                                "typeString": "msg"
                              }
                            },
                            "id": 156,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "lValueRequested": false,
                            "memberName": "sender",
                            "nodeType": "MemberAccess",
                            "referencedDeclaration": null,
                            "src": "3193:10:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_address_payable",
                              "typeString": "address payable"
                            }
                          },
                          "isConstant": false,
                          "isLValue": true,
                          "isPure": false,
                          "lValueRequested": false,
                          "nodeType": "IndexAccess",
                          "src": "3182:22:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          }
                        },
                        {
                          "argumentTypes": null,
                          "hexValue": "4e6f742061626c6520746f20646f20746861742042726f21",
                          "id": 158,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": true,
                          "kind": "string",
                          "lValueRequested": false,
                          "nodeType": "Literal",
                          "src": "3206:26:0",
                          "subdenomination": null,
                          "typeDescriptions": {
                            "typeIdentifier": "t_stringliteral_a8a30372c51ebb568444a91ceff1cb5f964f572ba86793e21c1a9243e19e1e9b",
                            "typeString": "literal_string \"Not able to do that Bro!\""
                          },
                          "value": "Not able to do that Bro!"
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          },
                          {
                            "typeIdentifier": "t_stringliteral_a8a30372c51ebb568444a91ceff1cb5f964f572ba86793e21c1a9243e19e1e9b",
                            "typeString": "literal_string \"Not able to do that Bro!\""
                          }
                        ],
                        "id": 153,
                        "name": "require",
                        "nodeType": "Identifier",
                        "overloadedDeclarations": [
                          -18,
                          -18
                        ],
                        "referencedDeclaration": -18,
                        "src": "3174:7:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_require_pure$_t_bool_$_t_string_memory_ptr_$returns$__$",
                          "typeString": "function (bool,string memory) pure"
                        }
                      },
                      "id": 159,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "3174:59:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_tuple$__$",
                        "typeString": "tuple()"
                      }
                    },
                    "id": 160,
                    "nodeType": "ExpressionStatement",
                    "src": "3174:59:0"
                  },
                  {
                    "assignments": [
                      162
                    ],
                    "declarations": [
                      {
                        "constant": false,
                        "id": 162,
                        "mutability": "mutable",
                        "name": "currentBalance",
                        "nodeType": "VariableDeclaration",
                        "overrides": null,
                        "scope": 176,
                        "src": "3243:22:0",
                        "stateVariable": false,
                        "storageLocation": "default",
                        "typeDescriptions": {
                          "typeIdentifier": "t_uint256",
                          "typeString": "uint256"
                        },
                        "typeName": {
                          "id": 161,
                          "name": "uint256",
                          "nodeType": "ElementaryTypeName",
                          "src": "3243:7:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        },
                        "value": null,
                        "visibility": "internal"
                      }
                    ],
                    "id": 166,
                    "initialValue": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "id": 164,
                          "name": "tokenAddress",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 150,
                          "src": "3291:12:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        ],
                        "id": 163,
                        "name": "returnCurrentBalanceOf",
                        "nodeType": "Identifier",
                        "overloadedDeclarations": [],
                        "referencedDeclaration": 255,
                        "src": "3268:22:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_internal_view$_t_address_$returns$_t_uint256_$",
                          "typeString": "function (address) view returns (uint256)"
                        }
                      },
                      "id": 165,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "3268:36:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_uint256",
                        "typeString": "uint256"
                      }
                    },
                    "nodeType": "VariableDeclarationStatement",
                    "src": "3243:61:0"
                  },
                  {
                    "expression": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "expression": {
                            "argumentTypes": null,
                            "id": 171,
                            "name": "msg",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": -15,
                            "src": "3344:3:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_magic_message",
                              "typeString": "msg"
                            }
                          },
                          "id": 172,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "lValueRequested": false,
                          "memberName": "sender",
                          "nodeType": "MemberAccess",
                          "referencedDeclaration": null,
                          "src": "3344:10:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_address_payable",
                            "typeString": "address payable"
                          }
                        },
                        {
                          "argumentTypes": null,
                          "id": 173,
                          "name": "currentBalance",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 162,
                          "src": "3356:14:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_address_payable",
                            "typeString": "address payable"
                          },
                          {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        ],
                        "expression": {
                          "argumentTypes": null,
                          "arguments": [
                            {
                              "argumentTypes": null,
                              "id": 168,
                              "name": "tokenAddress",
                              "nodeType": "Identifier",
                              "overloadedDeclarations": [],
                              "referencedDeclaration": 150,
                              "src": "3321:12:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_address",
                                "typeString": "address"
                              }
                            }
                          ],
                          "expression": {
                            "argumentTypes": [
                              {
                                "typeIdentifier": "t_address",
                                "typeString": "address"
                              }
                            ],
                            "id": 167,
                            "name": "IERC20",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 770,
                            "src": "3314:6:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_type$_t_contract$_IERC20_$770_$",
                              "typeString": "type(contract IERC20)"
                            }
                          },
                          "id": 169,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "kind": "typeConversion",
                          "lValueRequested": false,
                          "names": [],
                          "nodeType": "FunctionCall",
                          "src": "3314:20:0",
                          "tryCall": false,
                          "typeDescriptions": {
                            "typeIdentifier": "t_contract$_IERC20_$770",
                            "typeString": "contract IERC20"
                          }
                        },
                        "id": 170,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": false,
                        "lValueRequested": false,
                        "memberName": "transfer",
                        "nodeType": "MemberAccess",
                        "referencedDeclaration": 719,
                        "src": "3314:29:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_external_nonpayable$_t_address_$_t_uint256_$returns$_t_bool_$",
                          "typeString": "function (address,uint256) external returns (bool)"
                        }
                      },
                      "id": 174,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "3314:57:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_bool",
                        "typeString": "bool"
                      }
                    },
                    "id": 175,
                    "nodeType": "ExpressionStatement",
                    "src": "3314:57:0"
                  }
                ]
              },
              "documentation": null,
              "functionSelector": "be11e0c1",
              "id": 177,
              "implemented": true,
              "kind": "function",
              "modifiers": [],
              "name": "payOutAllFunds",
              "nodeType": "FunctionDefinition",
              "overrides": null,
              "parameters": {
                "id": 151,
                "nodeType": "ParameterList",
                "parameters": [
                  {
                    "constant": false,
                    "id": 150,
                    "mutability": "mutable",
                    "name": "tokenAddress",
                    "nodeType": "VariableDeclaration",
                    "overrides": null,
                    "scope": 177,
                    "src": "3135:20:0",
                    "stateVariable": false,
                    "storageLocation": "default",
                    "typeDescriptions": {
                      "typeIdentifier": "t_address",
                      "typeString": "address"
                    },
                    "typeName": {
                      "id": 149,
                      "name": "address",
                      "nodeType": "ElementaryTypeName",
                      "src": "3135:7:0",
                      "stateMutability": "nonpayable",
                      "typeDescriptions": {
                        "typeIdentifier": "t_address",
                        "typeString": "address"
                      }
                    },
                    "value": null,
                    "visibility": "internal"
                  }
                ],
                "src": "3134:22:0"
              },
              "returnParameters": {
                "id": 152,
                "nodeType": "ParameterList",
                "parameters": [],
                "src": "3164:0:0"
              },
              "scope": 670,
              "src": "3111:276:0",
              "stateMutability": "nonpayable",
              "virtual": false,
              "visibility": "public"
            },
            {
              "body": {
                "id": 201,
                "nodeType": "Block",
                "src": "3429:146:0",
                "statements": [
                  {
                    "expression": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "baseExpression": {
                            "argumentTypes": null,
                            "id": 181,
                            "name": "_canPayOut",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 49,
                            "src": "3447:10:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_mapping$_t_address_$_t_bool_$",
                              "typeString": "mapping(address => bool)"
                            }
                          },
                          "id": 184,
                          "indexExpression": {
                            "argumentTypes": null,
                            "expression": {
                              "argumentTypes": null,
                              "id": 182,
                              "name": "msg",
                              "nodeType": "Identifier",
                              "overloadedDeclarations": [],
                              "referencedDeclaration": -15,
                              "src": "3458:3:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_magic_message",
                                "typeString": "msg"
                              }
                            },
                            "id": 183,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "lValueRequested": false,
                            "memberName": "sender",
                            "nodeType": "MemberAccess",
                            "referencedDeclaration": null,
                            "src": "3458:10:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_address_payable",
                              "typeString": "address payable"
                            }
                          },
                          "isConstant": false,
                          "isLValue": true,
                          "isPure": false,
                          "lValueRequested": false,
                          "nodeType": "IndexAccess",
                          "src": "3447:22:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          }
                        },
                        {
                          "argumentTypes": null,
                          "hexValue": "4e6f742061626c6520746f20646f20746861742042726f21",
                          "id": 185,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": true,
                          "kind": "string",
                          "lValueRequested": false,
                          "nodeType": "Literal",
                          "src": "3471:26:0",
                          "subdenomination": null,
                          "typeDescriptions": {
                            "typeIdentifier": "t_stringliteral_a8a30372c51ebb568444a91ceff1cb5f964f572ba86793e21c1a9243e19e1e9b",
                            "typeString": "literal_string \"Not able to do that Bro!\""
                          },
                          "value": "Not able to do that Bro!"
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          },
                          {
                            "typeIdentifier": "t_stringliteral_a8a30372c51ebb568444a91ceff1cb5f964f572ba86793e21c1a9243e19e1e9b",
                            "typeString": "literal_string \"Not able to do that Bro!\""
                          }
                        ],
                        "id": 180,
                        "name": "require",
                        "nodeType": "Identifier",
                        "overloadedDeclarations": [
                          -18,
                          -18
                        ],
                        "referencedDeclaration": -18,
                        "src": "3439:7:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_require_pure$_t_bool_$_t_string_memory_ptr_$returns$__$",
                          "typeString": "function (bool,string memory) pure"
                        }
                      },
                      "id": 186,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "3439:59:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_tuple$__$",
                        "typeString": "tuple()"
                      }
                    },
                    "id": 187,
                    "nodeType": "ExpressionStatement",
                    "src": "3439:59:0"
                  },
                  {
                    "expression": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "expression": {
                            "argumentTypes": null,
                            "arguments": [
                              {
                                "argumentTypes": null,
                                "id": 196,
                                "name": "this",
                                "nodeType": "Identifier",
                                "overloadedDeclarations": [],
                                "referencedDeclaration": -28,
                                "src": "3545:4:0",
                                "typeDescriptions": {
                                  "typeIdentifier": "t_contract$_Arbitage_$670",
                                  "typeString": "contract Arbitage"
                                }
                              }
                            ],
                            "expression": {
                              "argumentTypes": [
                                {
                                  "typeIdentifier": "t_contract$_Arbitage_$670",
                                  "typeString": "contract Arbitage"
                                }
                              ],
                              "id": 195,
                              "isConstant": false,
                              "isLValue": false,
                              "isPure": true,
                              "lValueRequested": false,
                              "nodeType": "ElementaryTypeNameExpression",
                              "src": "3537:7:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_type$_t_address_$",
                                "typeString": "type(address)"
                              },
                              "typeName": {
                                "id": 194,
                                "name": "address",
                                "nodeType": "ElementaryTypeName",
                                "src": "3537:7:0",
                                "typeDescriptions": {
                                  "typeIdentifier": null,
                                  "typeString": null
                                }
                              }
                            },
                            "id": 197,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "kind": "typeConversion",
                            "lValueRequested": false,
                            "names": [],
                            "nodeType": "FunctionCall",
                            "src": "3537:13:0",
                            "tryCall": false,
                            "typeDescriptions": {
                              "typeIdentifier": "t_address_payable",
                              "typeString": "address payable"
                            }
                          },
                          "id": 198,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "lValueRequested": false,
                          "memberName": "balance",
                          "nodeType": "MemberAccess",
                          "referencedDeclaration": null,
                          "src": "3537:21:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        ],
                        "expression": {
                          "argumentTypes": null,
                          "arguments": [
                            {
                              "argumentTypes": null,
                              "expression": {
                                "argumentTypes": null,
                                "id": 190,
                                "name": "msg",
                                "nodeType": "Identifier",
                                "overloadedDeclarations": [],
                                "referencedDeclaration": -15,
                                "src": "3516:3:0",
                                "typeDescriptions": {
                                  "typeIdentifier": "t_magic_message",
                                  "typeString": "msg"
                                }
                              },
                              "id": 191,
                              "isConstant": false,
                              "isLValue": false,
                              "isPure": false,
                              "lValueRequested": false,
                              "memberName": "sender",
                              "nodeType": "MemberAccess",
                              "referencedDeclaration": null,
                              "src": "3516:10:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_address_payable",
                                "typeString": "address payable"
                              }
                            }
                          ],
                          "expression": {
                            "argumentTypes": [
                              {
                                "typeIdentifier": "t_address_payable",
                                "typeString": "address payable"
                              }
                            ],
                            "id": 189,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": true,
                            "lValueRequested": false,
                            "nodeType": "ElementaryTypeNameExpression",
                            "src": "3508:8:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_type$_t_address_payable_$",
                              "typeString": "type(address payable)"
                            },
                            "typeName": {
                              "id": 188,
                              "name": "address",
                              "nodeType": "ElementaryTypeName",
                              "src": "3508:8:0",
                              "stateMutability": "payable",
                              "typeDescriptions": {
                                "typeIdentifier": null,
                                "typeString": null
                              }
                            }
                          },
                          "id": 192,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "kind": "typeConversion",
                          "lValueRequested": false,
                          "names": [],
                          "nodeType": "FunctionCall",
                          "src": "3508:19:0",
                          "tryCall": false,
                          "typeDescriptions": {
                            "typeIdentifier": "t_address_payable",
                            "typeString": "address payable"
                          }
                        },
                        "id": 193,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": false,
                        "lValueRequested": false,
                        "memberName": "transfer",
                        "nodeType": "MemberAccess",
                        "referencedDeclaration": null,
                        "src": "3508:28:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_transfer_nonpayable$_t_uint256_$returns$__$",
                          "typeString": "function (uint256)"
                        }
                      },
                      "id": 199,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "3508:51:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_tuple$__$",
                        "typeString": "tuple()"
                      }
                    },
                    "id": 200,
                    "nodeType": "ExpressionStatement",
                    "src": "3508:51:0"
                  }
                ]
              },
              "documentation": null,
              "functionSelector": "957ca639",
              "id": 202,
              "implemented": true,
              "kind": "function",
              "modifiers": [],
              "name": "payOutAllBNBFunds",
              "nodeType": "FunctionDefinition",
              "overrides": null,
              "parameters": {
                "id": 178,
                "nodeType": "ParameterList",
                "parameters": [],
                "src": "3419:2:0"
              },
              "returnParameters": {
                "id": 179,
                "nodeType": "ParameterList",
                "parameters": [],
                "src": "3429:0:0"
              },
              "scope": 670,
              "src": "3393:182:0",
              "stateMutability": "nonpayable",
              "virtual": false,
              "visibility": "public"
            },
            {
              "body": {
                "id": 236,
                "nodeType": "Block",
                "src": "3632:257:0",
                "statements": [
                  {
                    "expression": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "baseExpression": {
                            "argumentTypes": null,
                            "id": 208,
                            "name": "_canPayOut",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 49,
                            "src": "3650:10:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_mapping$_t_address_$_t_bool_$",
                              "typeString": "mapping(address => bool)"
                            }
                          },
                          "id": 211,
                          "indexExpression": {
                            "argumentTypes": null,
                            "expression": {
                              "argumentTypes": null,
                              "id": 209,
                              "name": "msg",
                              "nodeType": "Identifier",
                              "overloadedDeclarations": [],
                              "referencedDeclaration": -15,
                              "src": "3661:3:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_magic_message",
                                "typeString": "msg"
                              }
                            },
                            "id": 210,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "lValueRequested": false,
                            "memberName": "sender",
                            "nodeType": "MemberAccess",
                            "referencedDeclaration": null,
                            "src": "3661:10:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_address_payable",
                              "typeString": "address payable"
                            }
                          },
                          "isConstant": false,
                          "isLValue": true,
                          "isPure": false,
                          "lValueRequested": false,
                          "nodeType": "IndexAccess",
                          "src": "3650:22:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          }
                        },
                        {
                          "argumentTypes": null,
                          "hexValue": "4e6f742061626c6520746f20646f20746861742042726f21",
                          "id": 212,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": true,
                          "kind": "string",
                          "lValueRequested": false,
                          "nodeType": "Literal",
                          "src": "3674:26:0",
                          "subdenomination": null,
                          "typeDescriptions": {
                            "typeIdentifier": "t_stringliteral_a8a30372c51ebb568444a91ceff1cb5f964f572ba86793e21c1a9243e19e1e9b",
                            "typeString": "literal_string \"Not able to do that Bro!\""
                          },
                          "value": "Not able to do that Bro!"
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          },
                          {
                            "typeIdentifier": "t_stringliteral_a8a30372c51ebb568444a91ceff1cb5f964f572ba86793e21c1a9243e19e1e9b",
                            "typeString": "literal_string \"Not able to do that Bro!\""
                          }
                        ],
                        "id": 207,
                        "name": "require",
                        "nodeType": "Identifier",
                        "overloadedDeclarations": [
                          -18,
                          -18
                        ],
                        "referencedDeclaration": -18,
                        "src": "3642:7:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_require_pure$_t_bool_$_t_string_memory_ptr_$returns$__$",
                          "typeString": "function (bool,string memory) pure"
                        }
                      },
                      "id": 213,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "3642:59:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_tuple$__$",
                        "typeString": "tuple()"
                      }
                    },
                    "id": 214,
                    "nodeType": "ExpressionStatement",
                    "src": "3642:59:0"
                  },
                  {
                    "assignments": [
                      216
                    ],
                    "declarations": [
                      {
                        "constant": false,
                        "id": 216,
                        "mutability": "mutable",
                        "name": "currentBalance",
                        "nodeType": "VariableDeclaration",
                        "overrides": null,
                        "scope": 236,
                        "src": "3711:22:0",
                        "stateVariable": false,
                        "storageLocation": "default",
                        "typeDescriptions": {
                          "typeIdentifier": "t_uint256",
                          "typeString": "uint256"
                        },
                        "typeName": {
                          "id": 215,
                          "name": "uint256",
                          "nodeType": "ElementaryTypeName",
                          "src": "3711:7:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        },
                        "value": null,
                        "visibility": "internal"
                      }
                    ],
                    "id": 219,
                    "initialValue": {
                      "argumentTypes": null,
                      "arguments": [],
                      "expression": {
                        "argumentTypes": [],
                        "id": 217,
                        "name": "returnCurrentBalanceBNB",
                        "nodeType": "Identifier",
                        "overloadedDeclarations": [],
                        "referencedDeclaration": 267,
                        "src": "3736:23:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_internal_view$__$returns$_t_uint256_$",
                          "typeString": "function () view returns (uint256)"
                        }
                      },
                      "id": 218,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "3736:25:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_uint256",
                        "typeString": "uint256"
                      }
                    },
                    "nodeType": "VariableDeclarationStatement",
                    "src": "3711:50:0"
                  },
                  {
                    "expression": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "commonType": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          },
                          "id": 223,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "lValueRequested": false,
                          "leftExpression": {
                            "argumentTypes": null,
                            "id": 221,
                            "name": "amount",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 204,
                            "src": "3779:6:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            }
                          },
                          "nodeType": "BinaryOperation",
                          "operator": "<=",
                          "rightExpression": {
                            "argumentTypes": null,
                            "id": 222,
                            "name": "currentBalance",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 216,
                            "src": "3789:14:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            }
                          },
                          "src": "3779:24:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          }
                        },
                        {
                          "argumentTypes": null,
                          "hexValue": "416d6f756e7420697320746f6f206869676821",
                          "id": 224,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": true,
                          "kind": "string",
                          "lValueRequested": false,
                          "nodeType": "Literal",
                          "src": "3805:21:0",
                          "subdenomination": null,
                          "typeDescriptions": {
                            "typeIdentifier": "t_stringliteral_a3ea578da6a19d0e8764eab2aaca56d4c0c702c203487eec22f39e7ff5735258",
                            "typeString": "literal_string \"Amount is too high!\""
                          },
                          "value": "Amount is too high!"
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          },
                          {
                            "typeIdentifier": "t_stringliteral_a3ea578da6a19d0e8764eab2aaca56d4c0c702c203487eec22f39e7ff5735258",
                            "typeString": "literal_string \"Amount is too high!\""
                          }
                        ],
                        "id": 220,
                        "name": "require",
                        "nodeType": "Identifier",
                        "overloadedDeclarations": [
                          -18,
                          -18
                        ],
                        "referencedDeclaration": -18,
                        "src": "3771:7:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_require_pure$_t_bool_$_t_string_memory_ptr_$returns$__$",
                          "typeString": "function (bool,string memory) pure"
                        }
                      },
                      "id": 225,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "3771:56:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_tuple$__$",
                        "typeString": "tuple()"
                      }
                    },
                    "id": 226,
                    "nodeType": "ExpressionStatement",
                    "src": "3771:56:0"
                  },
                  {
                    "expression": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "id": 233,
                          "name": "amount",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 204,
                          "src": "3866:6:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        ],
                        "expression": {
                          "argumentTypes": null,
                          "arguments": [
                            {
                              "argumentTypes": null,
                              "expression": {
                                "argumentTypes": null,
                                "id": 229,
                                "name": "msg",
                                "nodeType": "Identifier",
                                "overloadedDeclarations": [],
                                "referencedDeclaration": -15,
                                "src": "3845:3:0",
                                "typeDescriptions": {
                                  "typeIdentifier": "t_magic_message",
                                  "typeString": "msg"
                                }
                              },
                              "id": 230,
                              "isConstant": false,
                              "isLValue": false,
                              "isPure": false,
                              "lValueRequested": false,
                              "memberName": "sender",
                              "nodeType": "MemberAccess",
                              "referencedDeclaration": null,
                              "src": "3845:10:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_address_payable",
                                "typeString": "address payable"
                              }
                            }
                          ],
                          "expression": {
                            "argumentTypes": [
                              {
                                "typeIdentifier": "t_address_payable",
                                "typeString": "address payable"
                              }
                            ],
                            "id": 228,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": true,
                            "lValueRequested": false,
                            "nodeType": "ElementaryTypeNameExpression",
                            "src": "3837:8:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_type$_t_address_payable_$",
                              "typeString": "type(address payable)"
                            },
                            "typeName": {
                              "id": 227,
                              "name": "address",
                              "nodeType": "ElementaryTypeName",
                              "src": "3837:8:0",
                              "stateMutability": "payable",
                              "typeDescriptions": {
                                "typeIdentifier": null,
                                "typeString": null
                              }
                            }
                          },
                          "id": 231,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "kind": "typeConversion",
                          "lValueRequested": false,
                          "names": [],
                          "nodeType": "FunctionCall",
                          "src": "3837:19:0",
                          "tryCall": false,
                          "typeDescriptions": {
                            "typeIdentifier": "t_address_payable",
                            "typeString": "address payable"
                          }
                        },
                        "id": 232,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": false,
                        "lValueRequested": false,
                        "memberName": "transfer",
                        "nodeType": "MemberAccess",
                        "referencedDeclaration": null,
                        "src": "3837:28:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_transfer_nonpayable$_t_uint256_$returns$__$",
                          "typeString": "function (uint256)"
                        }
                      },
                      "id": 234,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "3837:36:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_tuple$__$",
                        "typeString": "tuple()"
                      }
                    },
                    "id": 235,
                    "nodeType": "ExpressionStatement",
                    "src": "3837:36:0"
                  }
                ]
              },
              "documentation": null,
              "functionSelector": "e4a773a9",
              "id": 237,
              "implemented": true,
              "kind": "function",
              "modifiers": [],
              "name": "payOutAllBNBFunds",
              "nodeType": "FunctionDefinition",
              "overrides": null,
              "parameters": {
                "id": 205,
                "nodeType": "ParameterList",
                "parameters": [
                  {
                    "constant": false,
                    "id": 204,
                    "mutability": "mutable",
                    "name": "amount",
                    "nodeType": "VariableDeclaration",
                    "overrides": null,
                    "scope": 237,
                    "src": "3609:14:0",
                    "stateVariable": false,
                    "storageLocation": "default",
                    "typeDescriptions": {
                      "typeIdentifier": "t_uint256",
                      "typeString": "uint256"
                    },
                    "typeName": {
                      "id": 203,
                      "name": "uint256",
                      "nodeType": "ElementaryTypeName",
                      "src": "3609:7:0",
                      "typeDescriptions": {
                        "typeIdentifier": "t_uint256",
                        "typeString": "uint256"
                      }
                    },
                    "value": null,
                    "visibility": "internal"
                  }
                ],
                "src": "3608:16:0"
              },
              "returnParameters": {
                "id": 206,
                "nodeType": "ParameterList",
                "parameters": [],
                "src": "3632:0:0"
              },
              "scope": 670,
              "src": "3582:307:0",
              "stateMutability": "nonpayable",
              "virtual": false,
              "visibility": "public"
            },
            {
              "body": {
                "id": 254,
                "nodeType": "Block",
                "src": "3983:69:0",
                "statements": [
                  {
                    "expression": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "arguments": [
                            {
                              "argumentTypes": null,
                              "id": 250,
                              "name": "this",
                              "nodeType": "Identifier",
                              "overloadedDeclarations": [],
                              "referencedDeclaration": -28,
                              "src": "4039:4:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_contract$_Arbitage_$670",
                                "typeString": "contract Arbitage"
                              }
                            }
                          ],
                          "expression": {
                            "argumentTypes": [
                              {
                                "typeIdentifier": "t_contract$_Arbitage_$670",
                                "typeString": "contract Arbitage"
                              }
                            ],
                            "id": 249,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": true,
                            "lValueRequested": false,
                            "nodeType": "ElementaryTypeNameExpression",
                            "src": "4031:7:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_type$_t_address_$",
                              "typeString": "type(address)"
                            },
                            "typeName": {
                              "id": 248,
                              "name": "address",
                              "nodeType": "ElementaryTypeName",
                              "src": "4031:7:0",
                              "typeDescriptions": {
                                "typeIdentifier": null,
                                "typeString": null
                              }
                            }
                          },
                          "id": 251,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "kind": "typeConversion",
                          "lValueRequested": false,
                          "names": [],
                          "nodeType": "FunctionCall",
                          "src": "4031:13:0",
                          "tryCall": false,
                          "typeDescriptions": {
                            "typeIdentifier": "t_address_payable",
                            "typeString": "address payable"
                          }
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_address_payable",
                            "typeString": "address payable"
                          }
                        ],
                        "expression": {
                          "argumentTypes": null,
                          "arguments": [
                            {
                              "argumentTypes": null,
                              "id": 245,
                              "name": "tokenAddress",
                              "nodeType": "Identifier",
                              "overloadedDeclarations": [],
                              "referencedDeclaration": 239,
                              "src": "4007:12:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_address",
                                "typeString": "address"
                              }
                            }
                          ],
                          "expression": {
                            "argumentTypes": [
                              {
                                "typeIdentifier": "t_address",
                                "typeString": "address"
                              }
                            ],
                            "id": 244,
                            "name": "IERC20",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 770,
                            "src": "4000:6:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_type$_t_contract$_IERC20_$770_$",
                              "typeString": "type(contract IERC20)"
                            }
                          },
                          "id": 246,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "kind": "typeConversion",
                          "lValueRequested": false,
                          "names": [],
                          "nodeType": "FunctionCall",
                          "src": "4000:20:0",
                          "tryCall": false,
                          "typeDescriptions": {
                            "typeIdentifier": "t_contract$_IERC20_$770",
                            "typeString": "contract IERC20"
                          }
                        },
                        "id": 247,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": false,
                        "lValueRequested": false,
                        "memberName": "balanceOf",
                        "nodeType": "MemberAccess",
                        "referencedDeclaration": 709,
                        "src": "4000:30:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_external_view$_t_address_$returns$_t_uint256_$",
                          "typeString": "function (address) view external returns (uint256)"
                        }
                      },
                      "id": 252,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "4000:45:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_uint256",
                        "typeString": "uint256"
                      }
                    },
                    "functionReturnParameters": 243,
                    "id": 253,
                    "nodeType": "Return",
                    "src": "3993:52:0"
                  }
                ]
              },
              "documentation": null,
              "functionSelector": "a07e544d",
              "id": 255,
              "implemented": true,
              "kind": "function",
              "modifiers": [],
              "name": "returnCurrentBalanceOf",
              "nodeType": "FunctionDefinition",
              "overrides": null,
              "parameters": {
                "id": 240,
                "nodeType": "ParameterList",
                "parameters": [
                  {
                    "constant": false,
                    "id": 239,
                    "mutability": "mutable",
                    "name": "tokenAddress",
                    "nodeType": "VariableDeclaration",
                    "overrides": null,
                    "scope": 255,
                    "src": "3931:20:0",
                    "stateVariable": false,
                    "storageLocation": "default",
                    "typeDescriptions": {
                      "typeIdentifier": "t_address",
                      "typeString": "address"
                    },
                    "typeName": {
                      "id": 238,
                      "name": "address",
                      "nodeType": "ElementaryTypeName",
                      "src": "3931:7:0",
                      "stateMutability": "nonpayable",
                      "typeDescriptions": {
                        "typeIdentifier": "t_address",
                        "typeString": "address"
                      }
                    },
                    "value": null,
                    "visibility": "internal"
                  }
                ],
                "src": "3930:22:0"
              },
              "returnParameters": {
                "id": 243,
                "nodeType": "ParameterList",
                "parameters": [
                  {
                    "constant": false,
                    "id": 242,
                    "mutability": "mutable",
                    "name": "",
                    "nodeType": "VariableDeclaration",
                    "overrides": null,
                    "scope": 255,
                    "src": "3974:7:0",
                    "stateVariable": false,
                    "storageLocation": "default",
                    "typeDescriptions": {
                      "typeIdentifier": "t_uint256",
                      "typeString": "uint256"
                    },
                    "typeName": {
                      "id": 241,
                      "name": "uint256",
                      "nodeType": "ElementaryTypeName",
                      "src": "3974:7:0",
                      "typeDescriptions": {
                        "typeIdentifier": "t_uint256",
                        "typeString": "uint256"
                      }
                    },
                    "value": null,
                    "visibility": "internal"
                  }
                ],
                "src": "3973:9:0"
              },
              "scope": 670,
              "src": "3899:153:0",
              "stateMutability": "view",
              "virtual": false,
              "visibility": "public"
            },
            {
              "body": {
                "id": 266,
                "nodeType": "Block",
                "src": "4127:45:0",
                "statements": [
                  {
                    "expression": {
                      "argumentTypes": null,
                      "expression": {
                        "argumentTypes": null,
                        "arguments": [
                          {
                            "argumentTypes": null,
                            "id": 262,
                            "name": "this",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": -28,
                            "src": "4152:4:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_contract$_Arbitage_$670",
                              "typeString": "contract Arbitage"
                            }
                          }
                        ],
                        "expression": {
                          "argumentTypes": [
                            {
                              "typeIdentifier": "t_contract$_Arbitage_$670",
                              "typeString": "contract Arbitage"
                            }
                          ],
                          "id": 261,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": true,
                          "lValueRequested": false,
                          "nodeType": "ElementaryTypeNameExpression",
                          "src": "4144:7:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_type$_t_address_$",
                            "typeString": "type(address)"
                          },
                          "typeName": {
                            "id": 260,
                            "name": "address",
                            "nodeType": "ElementaryTypeName",
                            "src": "4144:7:0",
                            "typeDescriptions": {
                              "typeIdentifier": null,
                              "typeString": null
                            }
                          }
                        },
                        "id": 263,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": false,
                        "kind": "typeConversion",
                        "lValueRequested": false,
                        "names": [],
                        "nodeType": "FunctionCall",
                        "src": "4144:13:0",
                        "tryCall": false,
                        "typeDescriptions": {
                          "typeIdentifier": "t_address_payable",
                          "typeString": "address payable"
                        }
                      },
                      "id": 264,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "lValueRequested": false,
                      "memberName": "balance",
                      "nodeType": "MemberAccess",
                      "referencedDeclaration": null,
                      "src": "4144:21:0",
                      "typeDescriptions": {
                        "typeIdentifier": "t_uint256",
                        "typeString": "uint256"
                      }
                    },
                    "functionReturnParameters": 259,
                    "id": 265,
                    "nodeType": "Return",
                    "src": "4137:28:0"
                  }
                ]
              },
              "documentation": null,
              "functionSelector": "ef7e6e2b",
              "id": 267,
              "implemented": true,
              "kind": "function",
              "modifiers": [],
              "name": "returnCurrentBalanceBNB",
              "nodeType": "FunctionDefinition",
              "overrides": null,
              "parameters": {
                "id": 256,
                "nodeType": "ParameterList",
                "parameters": [],
                "src": "4094:2:0"
              },
              "returnParameters": {
                "id": 259,
                "nodeType": "ParameterList",
                "parameters": [
                  {
                    "constant": false,
                    "id": 258,
                    "mutability": "mutable",
                    "name": "",
                    "nodeType": "VariableDeclaration",
                    "overrides": null,
                    "scope": 267,
                    "src": "4118:7:0",
                    "stateVariable": false,
                    "storageLocation": "default",
                    "typeDescriptions": {
                      "typeIdentifier": "t_uint256",
                      "typeString": "uint256"
                    },
                    "typeName": {
                      "id": 257,
                      "name": "uint256",
                      "nodeType": "ElementaryTypeName",
                      "src": "4118:7:0",
                      "typeDescriptions": {
                        "typeIdentifier": "t_uint256",
                        "typeString": "uint256"
                      }
                    },
                    "value": null,
                    "visibility": "internal"
                  }
                ],
                "src": "4117:9:0"
              },
              "scope": 670,
              "src": "4062:110:0",
              "stateMutability": "view",
              "virtual": false,
              "visibility": "public"
            },
            {
              "body": {
                "id": 328,
                "nodeType": "Block",
                "src": "4358:360:0",
                "statements": [
                  {
                    "expression": {
                      "argumentTypes": null,
                      "id": 284,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "lValueRequested": false,
                      "leftHandSide": {
                        "argumentTypes": null,
                        "id": 282,
                        "name": "factory",
                        "nodeType": "Identifier",
                        "overloadedDeclarations": [],
                        "referencedDeclaration": 19,
                        "src": "4364:7:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_address",
                          "typeString": "address"
                        }
                      },
                      "nodeType": "Assignment",
                      "operator": "=",
                      "rightHandSide": {
                        "argumentTypes": null,
                        "id": 283,
                        "name": "factoryFlashloan",
                        "nodeType": "Identifier",
                        "overloadedDeclarations": [],
                        "referencedDeclaration": 269,
                        "src": "4374:16:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_address",
                          "typeString": "address"
                        }
                      },
                      "src": "4364:26:0",
                      "typeDescriptions": {
                        "typeIdentifier": "t_address",
                        "typeString": "address"
                      }
                    },
                    "id": 285,
                    "nodeType": "ExpressionStatement",
                    "src": "4364:26:0"
                  },
                  {
                    "expression": {
                      "argumentTypes": null,
                      "id": 290,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "lValueRequested": false,
                      "leftHandSide": {
                        "argumentTypes": null,
                        "id": 286,
                        "name": "sushiRouter",
                        "nodeType": "Identifier",
                        "overloadedDeclarations": [],
                        "referencedDeclaration": 24,
                        "src": "4398:11:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_contract$_IUniswapV2Router02_$1468",
                          "typeString": "contract IUniswapV2Router02"
                        }
                      },
                      "nodeType": "Assignment",
                      "operator": "=",
                      "rightHandSide": {
                        "argumentTypes": null,
                        "arguments": [
                          {
                            "argumentTypes": null,
                            "id": 288,
                            "name": "routerBuyIn",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 271,
                            "src": "4431:11:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_address",
                              "typeString": "address"
                            }
                          }
                        ],
                        "expression": {
                          "argumentTypes": [
                            {
                              "typeIdentifier": "t_address",
                              "typeString": "address"
                            }
                          ],
                          "id": 287,
                          "name": "IUniswapV2Router02",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 1468,
                          "src": "4412:18:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_type$_t_contract$_IUniswapV2Router02_$1468_$",
                            "typeString": "type(contract IUniswapV2Router02)"
                          }
                        },
                        "id": 289,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": false,
                        "kind": "typeConversion",
                        "lValueRequested": false,
                        "names": [],
                        "nodeType": "FunctionCall",
                        "src": "4412:31:0",
                        "tryCall": false,
                        "typeDescriptions": {
                          "typeIdentifier": "t_contract$_IUniswapV2Router02_$1468",
                          "typeString": "contract IUniswapV2Router02"
                        }
                      },
                      "src": "4398:45:0",
                      "typeDescriptions": {
                        "typeIdentifier": "t_contract$_IUniswapV2Router02_$1468",
                        "typeString": "contract IUniswapV2Router02"
                      }
                    },
                    "id": 291,
                    "nodeType": "ExpressionStatement",
                    "src": "4398:45:0"
                  },
                  {
                    "assignments": [
                      293
                    ],
                    "declarations": [
                      {
                        "constant": false,
                        "id": 293,
                        "mutability": "mutable",
                        "name": "pairAddress",
                        "nodeType": "VariableDeclaration",
                        "overrides": null,
                        "scope": 328,
                        "src": "4449:19:0",
                        "stateVariable": false,
                        "storageLocation": "default",
                        "typeDescriptions": {
                          "typeIdentifier": "t_address",
                          "typeString": "address"
                        },
                        "typeName": {
                          "id": 292,
                          "name": "address",
                          "nodeType": "ElementaryTypeName",
                          "src": "4449:7:0",
                          "stateMutability": "nonpayable",
                          "typeDescriptions": {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        },
                        "value": null,
                        "visibility": "internal"
                      }
                    ],
                    "id": 301,
                    "initialValue": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "id": 298,
                          "name": "token0",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 273,
                          "src": "4506:6:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        },
                        {
                          "argumentTypes": null,
                          "id": 299,
                          "name": "token1",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 275,
                          "src": "4514:6:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          },
                          {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        ],
                        "expression": {
                          "argumentTypes": null,
                          "arguments": [
                            {
                              "argumentTypes": null,
                              "id": 295,
                              "name": "factory",
                              "nodeType": "Identifier",
                              "overloadedDeclarations": [],
                              "referencedDeclaration": 19,
                              "src": "4489:7:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_address",
                                "typeString": "address"
                              }
                            }
                          ],
                          "expression": {
                            "argumentTypes": [
                              {
                                "typeIdentifier": "t_address",
                                "typeString": "address"
                              }
                            ],
                            "id": 294,
                            "name": "IUniswapV2Factory",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 833,
                            "src": "4471:17:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_type$_t_contract$_IUniswapV2Factory_$833_$",
                              "typeString": "type(contract IUniswapV2Factory)"
                            }
                          },
                          "id": 296,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "kind": "typeConversion",
                          "lValueRequested": false,
                          "names": [],
                          "nodeType": "FunctionCall",
                          "src": "4471:26:0",
                          "tryCall": false,
                          "typeDescriptions": {
                            "typeIdentifier": "t_contract$_IUniswapV2Factory_$833",
                            "typeString": "contract IUniswapV2Factory"
                          }
                        },
                        "id": 297,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": false,
                        "lValueRequested": false,
                        "memberName": "getPair",
                        "nodeType": "MemberAccess",
                        "referencedDeclaration": 801,
                        "src": "4471:34:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_external_view$_t_address_$_t_address_$returns$_t_address_$",
                          "typeString": "function (address,address) view external returns (address)"
                        }
                      },
                      "id": 300,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "4471:50:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_address",
                        "typeString": "address"
                      }
                    },
                    "nodeType": "VariableDeclarationStatement",
                    "src": "4449:72:0"
                  },
                  {
                    "expression": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "commonType": {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          },
                          "id": 308,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "lValueRequested": false,
                          "leftExpression": {
                            "argumentTypes": null,
                            "id": 303,
                            "name": "pairAddress",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 293,
                            "src": "4535:11:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_address",
                              "typeString": "address"
                            }
                          },
                          "nodeType": "BinaryOperation",
                          "operator": "!=",
                          "rightExpression": {
                            "argumentTypes": null,
                            "arguments": [
                              {
                                "argumentTypes": null,
                                "hexValue": "30",
                                "id": 306,
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": true,
                                "kind": "number",
                                "lValueRequested": false,
                                "nodeType": "Literal",
                                "src": "4558:1:0",
                                "subdenomination": null,
                                "typeDescriptions": {
                                  "typeIdentifier": "t_rational_0_by_1",
                                  "typeString": "int_const 0"
                                },
                                "value": "0"
                              }
                            ],
                            "expression": {
                              "argumentTypes": [
                                {
                                  "typeIdentifier": "t_rational_0_by_1",
                                  "typeString": "int_const 0"
                                }
                              ],
                              "id": 305,
                              "isConstant": false,
                              "isLValue": false,
                              "isPure": true,
                              "lValueRequested": false,
                              "nodeType": "ElementaryTypeNameExpression",
                              "src": "4550:7:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_type$_t_address_$",
                                "typeString": "type(address)"
                              },
                              "typeName": {
                                "id": 304,
                                "name": "address",
                                "nodeType": "ElementaryTypeName",
                                "src": "4550:7:0",
                                "typeDescriptions": {
                                  "typeIdentifier": null,
                                  "typeString": null
                                }
                              }
                            },
                            "id": 307,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": true,
                            "kind": "typeConversion",
                            "lValueRequested": false,
                            "names": [],
                            "nodeType": "FunctionCall",
                            "src": "4550:10:0",
                            "tryCall": false,
                            "typeDescriptions": {
                              "typeIdentifier": "t_address_payable",
                              "typeString": "address payable"
                            }
                          },
                          "src": "4535:25:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          }
                        },
                        {
                          "argumentTypes": null,
                          "hexValue": "5468697320706f6f6c20646f6573206e6f74206578697374",
                          "id": 309,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": true,
                          "kind": "string",
                          "lValueRequested": false,
                          "nodeType": "Literal",
                          "src": "4562:26:0",
                          "subdenomination": null,
                          "typeDescriptions": {
                            "typeIdentifier": "t_stringliteral_c7b83ef4d31517478af18b53eaeed17c28c06bf48ddd29363e648bda7de6e2a5",
                            "typeString": "literal_string \"This pool does not exist\""
                          },
                          "value": "This pool does not exist"
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          },
                          {
                            "typeIdentifier": "t_stringliteral_c7b83ef4d31517478af18b53eaeed17c28c06bf48ddd29363e648bda7de6e2a5",
                            "typeString": "literal_string \"This pool does not exist\""
                          }
                        ],
                        "id": 302,
                        "name": "require",
                        "nodeType": "Identifier",
                        "overloadedDeclarations": [
                          -18,
                          -18
                        ],
                        "referencedDeclaration": -18,
                        "src": "4527:7:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_require_pure$_t_bool_$_t_string_memory_ptr_$returns$__$",
                          "typeString": "function (bool,string memory) pure"
                        }
                      },
                      "id": 310,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "4527:62:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_tuple$__$",
                        "typeString": "tuple()"
                      }
                    },
                    "id": 311,
                    "nodeType": "ExpressionStatement",
                    "src": "4527:62:0"
                  },
                  {
                    "expression": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "id": 316,
                          "name": "amount0",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 277,
                          "src": "4635:7:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        },
                        {
                          "argumentTypes": null,
                          "id": 317,
                          "name": "amount1",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 279,
                          "src": "4651:7:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        },
                        {
                          "argumentTypes": null,
                          "arguments": [
                            {
                              "argumentTypes": null,
                              "id": 320,
                              "name": "this",
                              "nodeType": "Identifier",
                              "overloadedDeclarations": [],
                              "referencedDeclaration": -28,
                              "src": "4675:4:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_contract$_Arbitage_$670",
                                "typeString": "contract Arbitage"
                              }
                            }
                          ],
                          "expression": {
                            "argumentTypes": [
                              {
                                "typeIdentifier": "t_contract$_Arbitage_$670",
                                "typeString": "contract Arbitage"
                              }
                            ],
                            "id": 319,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": true,
                            "lValueRequested": false,
                            "nodeType": "ElementaryTypeNameExpression",
                            "src": "4667:7:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_type$_t_address_$",
                              "typeString": "type(address)"
                            },
                            "typeName": {
                              "id": 318,
                              "name": "address",
                              "nodeType": "ElementaryTypeName",
                              "src": "4667:7:0",
                              "typeDescriptions": {
                                "typeIdentifier": null,
                                "typeString": null
                              }
                            }
                          },
                          "id": 321,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "kind": "typeConversion",
                          "lValueRequested": false,
                          "names": [],
                          "nodeType": "FunctionCall",
                          "src": "4667:13:0",
                          "tryCall": false,
                          "typeDescriptions": {
                            "typeIdentifier": "t_address_payable",
                            "typeString": "address payable"
                          }
                        },
                        {
                          "argumentTypes": null,
                          "arguments": [
                            {
                              "argumentTypes": null,
                              "hexValue": "6e6f7420656d707479",
                              "id": 324,
                              "isConstant": false,
                              "isLValue": false,
                              "isPure": true,
                              "kind": "string",
                              "lValueRequested": false,
                              "nodeType": "Literal",
                              "src": "4695:11:0",
                              "subdenomination": null,
                              "typeDescriptions": {
                                "typeIdentifier": "t_stringliteral_a04ad52322ead0231944629cf681090c4146b94624d4ce93f9da68c247b29319",
                                "typeString": "literal_string \"not empty\""
                              },
                              "value": "not empty"
                            }
                          ],
                          "expression": {
                            "argumentTypes": [
                              {
                                "typeIdentifier": "t_stringliteral_a04ad52322ead0231944629cf681090c4146b94624d4ce93f9da68c247b29319",
                                "typeString": "literal_string \"not empty\""
                              }
                            ],
                            "id": 323,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": true,
                            "lValueRequested": false,
                            "nodeType": "ElementaryTypeNameExpression",
                            "src": "4689:5:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_type$_t_bytes_storage_ptr_$",
                              "typeString": "type(bytes storage pointer)"
                            },
                            "typeName": {
                              "id": 322,
                              "name": "bytes",
                              "nodeType": "ElementaryTypeName",
                              "src": "4689:5:0",
                              "typeDescriptions": {
                                "typeIdentifier": null,
                                "typeString": null
                              }
                            }
                          },
                          "id": 325,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": true,
                          "kind": "typeConversion",
                          "lValueRequested": false,
                          "names": [],
                          "nodeType": "FunctionCall",
                          "src": "4689:18:0",
                          "tryCall": false,
                          "typeDescriptions": {
                            "typeIdentifier": "t_bytes_memory_ptr",
                            "typeString": "bytes memory"
                          }
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          },
                          {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          },
                          {
                            "typeIdentifier": "t_address_payable",
                            "typeString": "address payable"
                          },
                          {
                            "typeIdentifier": "t_bytes_memory_ptr",
                            "typeString": "bytes memory"
                          }
                        ],
                        "expression": {
                          "argumentTypes": null,
                          "arguments": [
                            {
                              "argumentTypes": null,
                              "id": 313,
                              "name": "pairAddress",
                              "nodeType": "Identifier",
                              "overloadedDeclarations": [],
                              "referencedDeclaration": 293,
                              "src": "4610:11:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_address",
                                "typeString": "address"
                              }
                            }
                          ],
                          "expression": {
                            "argumentTypes": [
                              {
                                "typeIdentifier": "t_address",
                                "typeString": "address"
                              }
                            ],
                            "id": 312,
                            "name": "IUniswapV2Pair",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 1075,
                            "src": "4595:14:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_type$_t_contract$_IUniswapV2Pair_$1075_$",
                              "typeString": "type(contract IUniswapV2Pair)"
                            }
                          },
                          "id": 314,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "kind": "typeConversion",
                          "lValueRequested": false,
                          "names": [],
                          "nodeType": "FunctionCall",
                          "src": "4595:27:0",
                          "tryCall": false,
                          "typeDescriptions": {
                            "typeIdentifier": "t_contract$_IUniswapV2Pair_$1075",
                            "typeString": "contract IUniswapV2Pair"
                          }
                        },
                        "id": 315,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": false,
                        "lValueRequested": false,
                        "memberName": "swap",
                        "nodeType": "MemberAccess",
                        "referencedDeclaration": 1059,
                        "src": "4595:32:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_external_nonpayable$_t_uint256_$_t_uint256_$_t_address_$_t_bytes_memory_ptr_$returns$__$",
                          "typeString": "function (uint256,uint256,address,bytes memory) external"
                        }
                      },
                      "id": 326,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "4595:118:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_tuple$__$",
                        "typeString": "tuple()"
                      }
                    },
                    "id": 327,
                    "nodeType": "ExpressionStatement",
                    "src": "4595:118:0"
                  }
                ]
              },
              "documentation": null,
              "functionSelector": "25073e6b",
              "id": 329,
              "implemented": true,
              "kind": "function",
              "modifiers": [],
              "name": "startArbitrage",
              "nodeType": "FunctionDefinition",
              "overrides": null,
              "parameters": {
                "id": 280,
                "nodeType": "ParameterList",
                "parameters": [
                  {
                    "constant": false,
                    "id": 269,
                    "mutability": "mutable",
                    "name": "factoryFlashloan",
                    "nodeType": "VariableDeclaration",
                    "overrides": null,
                    "scope": 329,
                    "src": "4216:24:0",
                    "stateVariable": false,
                    "storageLocation": "default",
                    "typeDescriptions": {
                      "typeIdentifier": "t_address",
                      "typeString": "address"
                    },
                    "typeName": {
                      "id": 268,
                      "name": "address",
                      "nodeType": "ElementaryTypeName",
                      "src": "4216:7:0",
                      "stateMutability": "nonpayable",
                      "typeDescriptions": {
                        "typeIdentifier": "t_address",
                        "typeString": "address"
                      }
                    },
                    "value": null,
                    "visibility": "internal"
                  },
                  {
                    "constant": false,
                    "id": 271,
                    "mutability": "mutable",
                    "name": "routerBuyIn",
                    "nodeType": "VariableDeclaration",
                    "overrides": null,
                    "scope": 329,
                    "src": "4246:19:0",
                    "stateVariable": false,
                    "storageLocation": "default",
                    "typeDescriptions": {
                      "typeIdentifier": "t_address",
                      "typeString": "address"
                    },
                    "typeName": {
                      "id": 270,
                      "name": "address",
                      "nodeType": "ElementaryTypeName",
                      "src": "4246:7:0",
                      "stateMutability": "nonpayable",
                      "typeDescriptions": {
                        "typeIdentifier": "t_address",
                        "typeString": "address"
                      }
                    },
                    "value": null,
                    "visibility": "internal"
                  },
                  {
                    "constant": false,
                    "id": 273,
                    "mutability": "mutable",
                    "name": "token0",
                    "nodeType": "VariableDeclaration",
                    "overrides": null,
                    "scope": 329,
                    "src": "4271:14:0",
                    "stateVariable": false,
                    "storageLocation": "default",
                    "typeDescriptions": {
                      "typeIdentifier": "t_address",
                      "typeString": "address"
                    },
                    "typeName": {
                      "id": 272,
                      "name": "address",
                      "nodeType": "ElementaryTypeName",
                      "src": "4271:7:0",
                      "stateMutability": "nonpayable",
                      "typeDescriptions": {
                        "typeIdentifier": "t_address",
                        "typeString": "address"
                      }
                    },
                    "value": null,
                    "visibility": "internal"
                  },
                  {
                    "constant": false,
                    "id": 275,
                    "mutability": "mutable",
                    "name": "token1",
                    "nodeType": "VariableDeclaration",
                    "overrides": null,
                    "scope": 329,
                    "src": "4292:14:0",
                    "stateVariable": false,
                    "storageLocation": "default",
                    "typeDescriptions": {
                      "typeIdentifier": "t_address",
                      "typeString": "address"
                    },
                    "typeName": {
                      "id": 274,
                      "name": "address",
                      "nodeType": "ElementaryTypeName",
                      "src": "4292:7:0",
                      "stateMutability": "nonpayable",
                      "typeDescriptions": {
                        "typeIdentifier": "t_address",
                        "typeString": "address"
                      }
                    },
                    "value": null,
                    "visibility": "internal"
                  },
                  {
                    "constant": false,
                    "id": 277,
                    "mutability": "mutable",
                    "name": "amount0",
                    "nodeType": "VariableDeclaration",
                    "overrides": null,
                    "scope": 329,
                    "src": "4313:12:0",
                    "stateVariable": false,
                    "storageLocation": "default",
                    "typeDescriptions": {
                      "typeIdentifier": "t_uint256",
                      "typeString": "uint256"
                    },
                    "typeName": {
                      "id": 276,
                      "name": "uint",
                      "nodeType": "ElementaryTypeName",
                      "src": "4313:4:0",
                      "typeDescriptions": {
                        "typeIdentifier": "t_uint256",
                        "typeString": "uint256"
                      }
                    },
                    "value": null,
                    "visibility": "internal"
                  },
                  {
                    "constant": false,
                    "id": 279,
                    "mutability": "mutable",
                    "name": "amount1",
                    "nodeType": "VariableDeclaration",
                    "overrides": null,
                    "scope": 329,
                    "src": "4332:12:0",
                    "stateVariable": false,
                    "storageLocation": "default",
                    "typeDescriptions": {
                      "typeIdentifier": "t_uint256",
                      "typeString": "uint256"
                    },
                    "typeName": {
                      "id": 278,
                      "name": "uint",
                      "nodeType": "ElementaryTypeName",
                      "src": "4332:4:0",
                      "typeDescriptions": {
                        "typeIdentifier": "t_uint256",
                        "typeString": "uint256"
                      }
                    },
                    "value": null,
                    "visibility": "internal"
                  }
                ],
                "src": "4210:138:0"
              },
              "returnParameters": {
                "id": 281,
                "nodeType": "ParameterList",
                "parameters": [],
                "src": "4358:0:0"
              },
              "scope": 670,
              "src": "4187:531:0",
              "stateMutability": "nonpayable",
              "virtual": false,
              "visibility": "external"
            },
            {
              "body": {
                "id": 498,
                "nodeType": "Block",
                "src": "4844:1074:0",
                "statements": [
                  {
                    "assignments": [
                      344
                    ],
                    "declarations": [
                      {
                        "constant": false,
                        "id": 344,
                        "mutability": "mutable",
                        "name": "path",
                        "nodeType": "VariableDeclaration",
                        "overrides": null,
                        "scope": 498,
                        "src": "4850:21:0",
                        "stateVariable": false,
                        "storageLocation": "memory",
                        "typeDescriptions": {
                          "typeIdentifier": "t_array$_t_address_$dyn_memory_ptr",
                          "typeString": "address[]"
                        },
                        "typeName": {
                          "baseType": {
                            "id": 342,
                            "name": "address",
                            "nodeType": "ElementaryTypeName",
                            "src": "4850:7:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_address",
                              "typeString": "address"
                            }
                          },
                          "id": 343,
                          "length": null,
                          "nodeType": "ArrayTypeName",
                          "src": "4850:9:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_array$_t_address_$dyn_storage_ptr",
                            "typeString": "address[]"
                          }
                        },
                        "value": null,
                        "visibility": "internal"
                      }
                    ],
                    "id": 350,
                    "initialValue": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "hexValue": "32",
                          "id": 348,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": true,
                          "kind": "number",
                          "lValueRequested": false,
                          "nodeType": "Literal",
                          "src": "4888:1:0",
                          "subdenomination": null,
                          "typeDescriptions": {
                            "typeIdentifier": "t_rational_2_by_1",
                            "typeString": "int_const 2"
                          },
                          "value": "2"
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_rational_2_by_1",
                            "typeString": "int_const 2"
                          }
                        ],
                        "id": 347,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": true,
                        "lValueRequested": false,
                        "nodeType": "NewExpression",
                        "src": "4874:13:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_objectcreation_pure$_t_uint256_$returns$_t_array$_t_address_$dyn_memory_ptr_$",
                          "typeString": "function (uint256) pure returns (address[] memory)"
                        },
                        "typeName": {
                          "baseType": {
                            "id": 345,
                            "name": "address",
                            "nodeType": "ElementaryTypeName",
                            "src": "4878:7:0",
                            "stateMutability": "nonpayable",
                            "typeDescriptions": {
                              "typeIdentifier": "t_address",
                              "typeString": "address"
                            }
                          },
                          "id": 346,
                          "length": null,
                          "nodeType": "ArrayTypeName",
                          "src": "4878:9:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_array$_t_address_$dyn_storage_ptr",
                            "typeString": "address[]"
                          }
                        }
                      },
                      "id": 349,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": true,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "4874:16:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_array$_t_address_$dyn_memory_ptr",
                        "typeString": "address[] memory"
                      }
                    },
                    "nodeType": "VariableDeclarationStatement",
                    "src": "4850:40:0"
                  },
                  {
                    "assignments": [
                      352
                    ],
                    "declarations": [
                      {
                        "constant": false,
                        "id": 352,
                        "mutability": "mutable",
                        "name": "amountToken",
                        "nodeType": "VariableDeclaration",
                        "overrides": null,
                        "scope": 498,
                        "src": "4896:16:0",
                        "stateVariable": false,
                        "storageLocation": "default",
                        "typeDescriptions": {
                          "typeIdentifier": "t_uint256",
                          "typeString": "uint256"
                        },
                        "typeName": {
                          "id": 351,
                          "name": "uint",
                          "nodeType": "ElementaryTypeName",
                          "src": "4896:4:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        },
                        "value": null,
                        "visibility": "internal"
                      }
                    ],
                    "id": 359,
                    "initialValue": {
                      "argumentTypes": null,
                      "condition": {
                        "argumentTypes": null,
                        "commonType": {
                          "typeIdentifier": "t_uint256",
                          "typeString": "uint256"
                        },
                        "id": 355,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": false,
                        "lValueRequested": false,
                        "leftExpression": {
                          "argumentTypes": null,
                          "id": 353,
                          "name": "_amount0",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 333,
                          "src": "4915:8:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        },
                        "nodeType": "BinaryOperation",
                        "operator": "==",
                        "rightExpression": {
                          "argumentTypes": null,
                          "hexValue": "30",
                          "id": 354,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": true,
                          "kind": "number",
                          "lValueRequested": false,
                          "nodeType": "Literal",
                          "src": "4927:1:0",
                          "subdenomination": null,
                          "typeDescriptions": {
                            "typeIdentifier": "t_rational_0_by_1",
                            "typeString": "int_const 0"
                          },
                          "value": "0"
                        },
                        "src": "4915:13:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_bool",
                          "typeString": "bool"
                        }
                      },
                      "falseExpression": {
                        "argumentTypes": null,
                        "id": 357,
                        "name": "_amount0",
                        "nodeType": "Identifier",
                        "overloadedDeclarations": [],
                        "referencedDeclaration": 333,
                        "src": "4942:8:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_uint256",
                          "typeString": "uint256"
                        }
                      },
                      "id": 358,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "lValueRequested": false,
                      "nodeType": "Conditional",
                      "src": "4915:35:0",
                      "trueExpression": {
                        "argumentTypes": null,
                        "id": 356,
                        "name": "_amount1",
                        "nodeType": "Identifier",
                        "overloadedDeclarations": [],
                        "referencedDeclaration": 335,
                        "src": "4931:8:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_uint256",
                          "typeString": "uint256"
                        }
                      },
                      "typeDescriptions": {
                        "typeIdentifier": "t_uint256",
                        "typeString": "uint256"
                      }
                    },
                    "nodeType": "VariableDeclarationStatement",
                    "src": "4896:54:0"
                  },
                  {
                    "assignments": [
                      361
                    ],
                    "declarations": [
                      {
                        "constant": false,
                        "id": 361,
                        "mutability": "mutable",
                        "name": "token0",
                        "nodeType": "VariableDeclaration",
                        "overrides": null,
                        "scope": 498,
                        "src": "4961:14:0",
                        "stateVariable": false,
                        "storageLocation": "default",
                        "typeDescriptions": {
                          "typeIdentifier": "t_address",
                          "typeString": "address"
                        },
                        "typeName": {
                          "id": 360,
                          "name": "address",
                          "nodeType": "ElementaryTypeName",
                          "src": "4961:7:0",
                          "stateMutability": "nonpayable",
                          "typeDescriptions": {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        },
                        "value": null,
                        "visibility": "internal"
                      }
                    ],
                    "id": 368,
                    "initialValue": {
                      "argumentTypes": null,
                      "arguments": [],
                      "expression": {
                        "argumentTypes": [],
                        "expression": {
                          "argumentTypes": null,
                          "arguments": [
                            {
                              "argumentTypes": null,
                              "expression": {
                                "argumentTypes": null,
                                "id": 363,
                                "name": "msg",
                                "nodeType": "Identifier",
                                "overloadedDeclarations": [],
                                "referencedDeclaration": -15,
                                "src": "4993:3:0",
                                "typeDescriptions": {
                                  "typeIdentifier": "t_magic_message",
                                  "typeString": "msg"
                                }
                              },
                              "id": 364,
                              "isConstant": false,
                              "isLValue": false,
                              "isPure": false,
                              "lValueRequested": false,
                              "memberName": "sender",
                              "nodeType": "MemberAccess",
                              "referencedDeclaration": null,
                              "src": "4993:10:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_address_payable",
                                "typeString": "address payable"
                              }
                            }
                          ],
                          "expression": {
                            "argumentTypes": [
                              {
                                "typeIdentifier": "t_address_payable",
                                "typeString": "address payable"
                              }
                            ],
                            "id": 362,
                            "name": "IUniswapV2Pair",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 1075,
                            "src": "4978:14:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_type$_t_contract$_IUniswapV2Pair_$1075_$",
                              "typeString": "type(contract IUniswapV2Pair)"
                            }
                          },
                          "id": 365,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "kind": "typeConversion",
                          "lValueRequested": false,
                          "names": [],
                          "nodeType": "FunctionCall",
                          "src": "4978:26:0",
                          "tryCall": false,
                          "typeDescriptions": {
                            "typeIdentifier": "t_contract$_IUniswapV2Pair_$1075",
                            "typeString": "contract IUniswapV2Pair"
                          }
                        },
                        "id": 366,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": false,
                        "lValueRequested": false,
                        "memberName": "token0",
                        "nodeType": "MemberAccess",
                        "referencedDeclaration": 1003,
                        "src": "4978:33:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_external_view$__$returns$_t_address_$",
                          "typeString": "function () view external returns (address)"
                        }
                      },
                      "id": 367,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "4978:35:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_address",
                        "typeString": "address"
                      }
                    },
                    "nodeType": "VariableDeclarationStatement",
                    "src": "4961:52:0"
                  },
                  {
                    "assignments": [
                      370
                    ],
                    "declarations": [
                      {
                        "constant": false,
                        "id": 370,
                        "mutability": "mutable",
                        "name": "token1",
                        "nodeType": "VariableDeclaration",
                        "overrides": null,
                        "scope": 498,
                        "src": "5019:14:0",
                        "stateVariable": false,
                        "storageLocation": "default",
                        "typeDescriptions": {
                          "typeIdentifier": "t_address",
                          "typeString": "address"
                        },
                        "typeName": {
                          "id": 369,
                          "name": "address",
                          "nodeType": "ElementaryTypeName",
                          "src": "5019:7:0",
                          "stateMutability": "nonpayable",
                          "typeDescriptions": {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        },
                        "value": null,
                        "visibility": "internal"
                      }
                    ],
                    "id": 377,
                    "initialValue": {
                      "argumentTypes": null,
                      "arguments": [],
                      "expression": {
                        "argumentTypes": [],
                        "expression": {
                          "argumentTypes": null,
                          "arguments": [
                            {
                              "argumentTypes": null,
                              "expression": {
                                "argumentTypes": null,
                                "id": 372,
                                "name": "msg",
                                "nodeType": "Identifier",
                                "overloadedDeclarations": [],
                                "referencedDeclaration": -15,
                                "src": "5051:3:0",
                                "typeDescriptions": {
                                  "typeIdentifier": "t_magic_message",
                                  "typeString": "msg"
                                }
                              },
                              "id": 373,
                              "isConstant": false,
                              "isLValue": false,
                              "isPure": false,
                              "lValueRequested": false,
                              "memberName": "sender",
                              "nodeType": "MemberAccess",
                              "referencedDeclaration": null,
                              "src": "5051:10:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_address_payable",
                                "typeString": "address payable"
                              }
                            }
                          ],
                          "expression": {
                            "argumentTypes": [
                              {
                                "typeIdentifier": "t_address_payable",
                                "typeString": "address payable"
                              }
                            ],
                            "id": 371,
                            "name": "IUniswapV2Pair",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 1075,
                            "src": "5036:14:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_type$_t_contract$_IUniswapV2Pair_$1075_$",
                              "typeString": "type(contract IUniswapV2Pair)"
                            }
                          },
                          "id": 374,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "kind": "typeConversion",
                          "lValueRequested": false,
                          "names": [],
                          "nodeType": "FunctionCall",
                          "src": "5036:26:0",
                          "tryCall": false,
                          "typeDescriptions": {
                            "typeIdentifier": "t_contract$_IUniswapV2Pair_$1075",
                            "typeString": "contract IUniswapV2Pair"
                          }
                        },
                        "id": 375,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": false,
                        "lValueRequested": false,
                        "memberName": "token1",
                        "nodeType": "MemberAccess",
                        "referencedDeclaration": 1008,
                        "src": "5036:33:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_external_view$__$returns$_t_address_$",
                          "typeString": "function () view external returns (address)"
                        }
                      },
                      "id": 376,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "5036:35:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_address",
                        "typeString": "address"
                      }
                    },
                    "nodeType": "VariableDeclarationStatement",
                    "src": "5019:52:0"
                  },
                  {
                    "expression": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "commonType": {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          },
                          "id": 387,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "lValueRequested": false,
                          "leftExpression": {
                            "argumentTypes": null,
                            "expression": {
                              "argumentTypes": null,
                              "id": 379,
                              "name": "msg",
                              "nodeType": "Identifier",
                              "overloadedDeclarations": [],
                              "referencedDeclaration": -15,
                              "src": "5093:3:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_magic_message",
                                "typeString": "msg"
                              }
                            },
                            "id": 380,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "lValueRequested": false,
                            "memberName": "sender",
                            "nodeType": "MemberAccess",
                            "referencedDeclaration": null,
                            "src": "5093:10:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_address_payable",
                              "typeString": "address payable"
                            }
                          },
                          "nodeType": "BinaryOperation",
                          "operator": "==",
                          "rightExpression": {
                            "argumentTypes": null,
                            "arguments": [
                              {
                                "argumentTypes": null,
                                "id": 383,
                                "name": "factory",
                                "nodeType": "Identifier",
                                "overloadedDeclarations": [],
                                "referencedDeclaration": 19,
                                "src": "5132:7:0",
                                "typeDescriptions": {
                                  "typeIdentifier": "t_address",
                                  "typeString": "address"
                                }
                              },
                              {
                                "argumentTypes": null,
                                "id": 384,
                                "name": "token0",
                                "nodeType": "Identifier",
                                "overloadedDeclarations": [],
                                "referencedDeclaration": 361,
                                "src": "5141:6:0",
                                "typeDescriptions": {
                                  "typeIdentifier": "t_address",
                                  "typeString": "address"
                                }
                              },
                              {
                                "argumentTypes": null,
                                "id": 385,
                                "name": "token1",
                                "nodeType": "Identifier",
                                "overloadedDeclarations": [],
                                "referencedDeclaration": 370,
                                "src": "5149:6:0",
                                "typeDescriptions": {
                                  "typeIdentifier": "t_address",
                                  "typeString": "address"
                                }
                              }
                            ],
                            "expression": {
                              "argumentTypes": [
                                {
                                  "typeIdentifier": "t_address",
                                  "typeString": "address"
                                },
                                {
                                  "typeIdentifier": "t_address",
                                  "typeString": "address"
                                },
                                {
                                  "typeIdentifier": "t_address",
                                  "typeString": "address"
                                }
                              ],
                              "expression": {
                                "argumentTypes": null,
                                "id": 381,
                                "name": "UniswapV2Library",
                                "nodeType": "Identifier",
                                "overloadedDeclarations": [],
                                "referencedDeclaration": 2272,
                                "src": "5107:16:0",
                                "typeDescriptions": {
                                  "typeIdentifier": "t_type$_t_contract$_UniswapV2Library_$2272_$",
                                  "typeString": "type(library UniswapV2Library)"
                                }
                              },
                              "id": 382,
                              "isConstant": false,
                              "isLValue": false,
                              "isPure": false,
                              "lValueRequested": false,
                              "memberName": "pairFor",
                              "nodeType": "MemberAccess",
                              "referencedDeclaration": 1896,
                              "src": "5107:24:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_function_internal_pure$_t_address_$_t_address_$_t_address_$returns$_t_address_$",
                                "typeString": "function (address,address,address) pure returns (address)"
                              }
                            },
                            "id": 386,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "kind": "functionCall",
                            "lValueRequested": false,
                            "names": [],
                            "nodeType": "FunctionCall",
                            "src": "5107:49:0",
                            "tryCall": false,
                            "typeDescriptions": {
                              "typeIdentifier": "t_address",
                              "typeString": "address"
                            }
                          },
                          "src": "5093:63:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          }
                        },
                        {
                          "argumentTypes": null,
                          "hexValue": "556e617574686f72697a6564",
                          "id": 388,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": true,
                          "kind": "string",
                          "lValueRequested": false,
                          "nodeType": "Literal",
                          "src": "5165:14:0",
                          "subdenomination": null,
                          "typeDescriptions": {
                            "typeIdentifier": "t_stringliteral_1b2638459828301e8cd6c7c02856073bacf975379e0867f689bb14feacb780c5",
                            "typeString": "literal_string \"Unauthorized\""
                          },
                          "value": "Unauthorized"
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          },
                          {
                            "typeIdentifier": "t_stringliteral_1b2638459828301e8cd6c7c02856073bacf975379e0867f689bb14feacb780c5",
                            "typeString": "literal_string \"Unauthorized\""
                          }
                        ],
                        "id": 378,
                        "name": "require",
                        "nodeType": "Identifier",
                        "overloadedDeclarations": [
                          -18,
                          -18
                        ],
                        "referencedDeclaration": -18,
                        "src": "5078:7:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_require_pure$_t_bool_$_t_string_memory_ptr_$returns$__$",
                          "typeString": "function (bool,string memory) pure"
                        }
                      },
                      "id": 389,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "5078:107:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_tuple$__$",
                        "typeString": "tuple()"
                      }
                    },
                    "id": 390,
                    "nodeType": "ExpressionStatement",
                    "src": "5078:107:0"
                  },
                  {
                    "expression": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "commonType": {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          },
                          "id": 398,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "lValueRequested": false,
                          "leftExpression": {
                            "argumentTypes": null,
                            "commonType": {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            },
                            "id": 394,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "lValueRequested": false,
                            "leftExpression": {
                              "argumentTypes": null,
                              "id": 392,
                              "name": "_amount0",
                              "nodeType": "Identifier",
                              "overloadedDeclarations": [],
                              "referencedDeclaration": 333,
                              "src": "5200:8:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_uint256",
                                "typeString": "uint256"
                              }
                            },
                            "nodeType": "BinaryOperation",
                            "operator": "==",
                            "rightExpression": {
                              "argumentTypes": null,
                              "hexValue": "30",
                              "id": 393,
                              "isConstant": false,
                              "isLValue": false,
                              "isPure": true,
                              "kind": "number",
                              "lValueRequested": false,
                              "nodeType": "Literal",
                              "src": "5212:1:0",
                              "subdenomination": null,
                              "typeDescriptions": {
                                "typeIdentifier": "t_rational_0_by_1",
                                "typeString": "int_const 0"
                              },
                              "value": "0"
                            },
                            "src": "5200:13:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_bool",
                              "typeString": "bool"
                            }
                          },
                          "nodeType": "BinaryOperation",
                          "operator": "||",
                          "rightExpression": {
                            "argumentTypes": null,
                            "commonType": {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            },
                            "id": 397,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "lValueRequested": false,
                            "leftExpression": {
                              "argumentTypes": null,
                              "id": 395,
                              "name": "_amount1",
                              "nodeType": "Identifier",
                              "overloadedDeclarations": [],
                              "referencedDeclaration": 335,
                              "src": "5217:8:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_uint256",
                                "typeString": "uint256"
                              }
                            },
                            "nodeType": "BinaryOperation",
                            "operator": "==",
                            "rightExpression": {
                              "argumentTypes": null,
                              "hexValue": "30",
                              "id": 396,
                              "isConstant": false,
                              "isLValue": false,
                              "isPure": true,
                              "kind": "number",
                              "lValueRequested": false,
                              "nodeType": "Literal",
                              "src": "5229:1:0",
                              "subdenomination": null,
                              "typeDescriptions": {
                                "typeIdentifier": "t_rational_0_by_1",
                                "typeString": "int_const 0"
                              },
                              "value": "0"
                            },
                            "src": "5217:13:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_bool",
                              "typeString": "bool"
                            }
                          },
                          "src": "5200:30:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          }
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          }
                        ],
                        "id": 391,
                        "name": "require",
                        "nodeType": "Identifier",
                        "overloadedDeclarations": [
                          -18,
                          -18
                        ],
                        "referencedDeclaration": -18,
                        "src": "5192:7:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_require_pure$_t_bool_$returns$__$",
                          "typeString": "function (bool) pure"
                        }
                      },
                      "id": 399,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "5192:39:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_tuple$__$",
                        "typeString": "tuple()"
                      }
                    },
                    "id": 400,
                    "nodeType": "ExpressionStatement",
                    "src": "5192:39:0"
                  },
                  {
                    "expression": {
                      "argumentTypes": null,
                      "id": 410,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "lValueRequested": false,
                      "leftHandSide": {
                        "argumentTypes": null,
                        "baseExpression": {
                          "argumentTypes": null,
                          "id": 401,
                          "name": "path",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 344,
                          "src": "5238:4:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_array$_t_address_$dyn_memory_ptr",
                            "typeString": "address[] memory"
                          }
                        },
                        "id": 403,
                        "indexExpression": {
                          "argumentTypes": null,
                          "hexValue": "30",
                          "id": 402,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": true,
                          "kind": "number",
                          "lValueRequested": false,
                          "nodeType": "Literal",
                          "src": "5243:1:0",
                          "subdenomination": null,
                          "typeDescriptions": {
                            "typeIdentifier": "t_rational_0_by_1",
                            "typeString": "int_const 0"
                          },
                          "value": "0"
                        },
                        "isConstant": false,
                        "isLValue": true,
                        "isPure": false,
                        "lValueRequested": true,
                        "nodeType": "IndexAccess",
                        "src": "5238:7:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_address",
                          "typeString": "address"
                        }
                      },
                      "nodeType": "Assignment",
                      "operator": "=",
                      "rightHandSide": {
                        "argumentTypes": null,
                        "condition": {
                          "argumentTypes": null,
                          "commonType": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          },
                          "id": 406,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "lValueRequested": false,
                          "leftExpression": {
                            "argumentTypes": null,
                            "id": 404,
                            "name": "_amount0",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 333,
                            "src": "5248:8:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            }
                          },
                          "nodeType": "BinaryOperation",
                          "operator": "==",
                          "rightExpression": {
                            "argumentTypes": null,
                            "hexValue": "30",
                            "id": 405,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": true,
                            "kind": "number",
                            "lValueRequested": false,
                            "nodeType": "Literal",
                            "src": "5260:1:0",
                            "subdenomination": null,
                            "typeDescriptions": {
                              "typeIdentifier": "t_rational_0_by_1",
                              "typeString": "int_const 0"
                            },
                            "value": "0"
                          },
                          "src": "5248:13:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          }
                        },
                        "falseExpression": {
                          "argumentTypes": null,
                          "id": 408,
                          "name": "token0",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 361,
                          "src": "5273:6:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        },
                        "id": 409,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": false,
                        "lValueRequested": false,
                        "nodeType": "Conditional",
                        "src": "5248:31:0",
                        "trueExpression": {
                          "argumentTypes": null,
                          "id": 407,
                          "name": "token1",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 370,
                          "src": "5264:6:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        },
                        "typeDescriptions": {
                          "typeIdentifier": "t_address",
                          "typeString": "address"
                        }
                      },
                      "src": "5238:41:0",
                      "typeDescriptions": {
                        "typeIdentifier": "t_address",
                        "typeString": "address"
                      }
                    },
                    "id": 411,
                    "nodeType": "ExpressionStatement",
                    "src": "5238:41:0"
                  },
                  {
                    "expression": {
                      "argumentTypes": null,
                      "id": 421,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "lValueRequested": false,
                      "leftHandSide": {
                        "argumentTypes": null,
                        "baseExpression": {
                          "argumentTypes": null,
                          "id": 412,
                          "name": "path",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 344,
                          "src": "5285:4:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_array$_t_address_$dyn_memory_ptr",
                            "typeString": "address[] memory"
                          }
                        },
                        "id": 414,
                        "indexExpression": {
                          "argumentTypes": null,
                          "hexValue": "31",
                          "id": 413,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": true,
                          "kind": "number",
                          "lValueRequested": false,
                          "nodeType": "Literal",
                          "src": "5290:1:0",
                          "subdenomination": null,
                          "typeDescriptions": {
                            "typeIdentifier": "t_rational_1_by_1",
                            "typeString": "int_const 1"
                          },
                          "value": "1"
                        },
                        "isConstant": false,
                        "isLValue": true,
                        "isPure": false,
                        "lValueRequested": true,
                        "nodeType": "IndexAccess",
                        "src": "5285:7:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_address",
                          "typeString": "address"
                        }
                      },
                      "nodeType": "Assignment",
                      "operator": "=",
                      "rightHandSide": {
                        "argumentTypes": null,
                        "condition": {
                          "argumentTypes": null,
                          "commonType": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          },
                          "id": 417,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "lValueRequested": false,
                          "leftExpression": {
                            "argumentTypes": null,
                            "id": 415,
                            "name": "_amount0",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 333,
                            "src": "5295:8:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            }
                          },
                          "nodeType": "BinaryOperation",
                          "operator": "==",
                          "rightExpression": {
                            "argumentTypes": null,
                            "hexValue": "30",
                            "id": 416,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": true,
                            "kind": "number",
                            "lValueRequested": false,
                            "nodeType": "Literal",
                            "src": "5307:1:0",
                            "subdenomination": null,
                            "typeDescriptions": {
                              "typeIdentifier": "t_rational_0_by_1",
                              "typeString": "int_const 0"
                            },
                            "value": "0"
                          },
                          "src": "5295:13:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          }
                        },
                        "falseExpression": {
                          "argumentTypes": null,
                          "id": 419,
                          "name": "token1",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 370,
                          "src": "5320:6:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        },
                        "id": 420,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": false,
                        "lValueRequested": false,
                        "nodeType": "Conditional",
                        "src": "5295:31:0",
                        "trueExpression": {
                          "argumentTypes": null,
                          "id": 418,
                          "name": "token0",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 361,
                          "src": "5311:6:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        },
                        "typeDescriptions": {
                          "typeIdentifier": "t_address",
                          "typeString": "address"
                        }
                      },
                      "src": "5285:41:0",
                      "typeDescriptions": {
                        "typeIdentifier": "t_address",
                        "typeString": "address"
                      }
                    },
                    "id": 422,
                    "nodeType": "ExpressionStatement",
                    "src": "5285:41:0"
                  },
                  {
                    "assignments": [
                      424
                    ],
                    "declarations": [
                      {
                        "constant": false,
                        "id": 424,
                        "mutability": "mutable",
                        "name": "token",
                        "nodeType": "VariableDeclaration",
                        "overrides": null,
                        "scope": 498,
                        "src": "5333:12:0",
                        "stateVariable": false,
                        "storageLocation": "default",
                        "typeDescriptions": {
                          "typeIdentifier": "t_contract$_IERC20_$770",
                          "typeString": "contract IERC20"
                        },
                        "typeName": {
                          "contractScope": null,
                          "id": 423,
                          "name": "IERC20",
                          "nodeType": "UserDefinedTypeName",
                          "referencedDeclaration": 770,
                          "src": "5333:6:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_contract$_IERC20_$770",
                            "typeString": "contract IERC20"
                          }
                        },
                        "value": null,
                        "visibility": "internal"
                      }
                    ],
                    "id": 433,
                    "initialValue": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "condition": {
                            "argumentTypes": null,
                            "commonType": {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            },
                            "id": 428,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "lValueRequested": false,
                            "leftExpression": {
                              "argumentTypes": null,
                              "id": 426,
                              "name": "_amount0",
                              "nodeType": "Identifier",
                              "overloadedDeclarations": [],
                              "referencedDeclaration": 333,
                              "src": "5355:8:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_uint256",
                                "typeString": "uint256"
                              }
                            },
                            "nodeType": "BinaryOperation",
                            "operator": "==",
                            "rightExpression": {
                              "argumentTypes": null,
                              "hexValue": "30",
                              "id": 427,
                              "isConstant": false,
                              "isLValue": false,
                              "isPure": true,
                              "kind": "number",
                              "lValueRequested": false,
                              "nodeType": "Literal",
                              "src": "5367:1:0",
                              "subdenomination": null,
                              "typeDescriptions": {
                                "typeIdentifier": "t_rational_0_by_1",
                                "typeString": "int_const 0"
                              },
                              "value": "0"
                            },
                            "src": "5355:13:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_bool",
                              "typeString": "bool"
                            }
                          },
                          "falseExpression": {
                            "argumentTypes": null,
                            "id": 430,
                            "name": "token0",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 361,
                            "src": "5380:6:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_address",
                              "typeString": "address"
                            }
                          },
                          "id": 431,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "lValueRequested": false,
                          "nodeType": "Conditional",
                          "src": "5355:31:0",
                          "trueExpression": {
                            "argumentTypes": null,
                            "id": 429,
                            "name": "token1",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 370,
                            "src": "5371:6:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_address",
                              "typeString": "address"
                            }
                          },
                          "typeDescriptions": {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        ],
                        "id": 425,
                        "name": "IERC20",
                        "nodeType": "Identifier",
                        "overloadedDeclarations": [],
                        "referencedDeclaration": 770,
                        "src": "5348:6:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_type$_t_contract$_IERC20_$770_$",
                          "typeString": "type(contract IERC20)"
                        }
                      },
                      "id": 432,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "typeConversion",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "5348:39:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_contract$_IERC20_$770",
                        "typeString": "contract IERC20"
                      }
                    },
                    "nodeType": "VariableDeclarationStatement",
                    "src": "5333:54:0"
                  },
                  {
                    "expression": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "arguments": [
                            {
                              "argumentTypes": null,
                              "id": 439,
                              "name": "sushiRouter",
                              "nodeType": "Identifier",
                              "overloadedDeclarations": [],
                              "referencedDeclaration": 24,
                              "src": "5420:11:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_contract$_IUniswapV2Router02_$1468",
                                "typeString": "contract IUniswapV2Router02"
                              }
                            }
                          ],
                          "expression": {
                            "argumentTypes": [
                              {
                                "typeIdentifier": "t_contract$_IUniswapV2Router02_$1468",
                                "typeString": "contract IUniswapV2Router02"
                              }
                            ],
                            "id": 438,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": true,
                            "lValueRequested": false,
                            "nodeType": "ElementaryTypeNameExpression",
                            "src": "5412:7:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_type$_t_address_$",
                              "typeString": "type(address)"
                            },
                            "typeName": {
                              "id": 437,
                              "name": "address",
                              "nodeType": "ElementaryTypeName",
                              "src": "5412:7:0",
                              "typeDescriptions": {
                                "typeIdentifier": null,
                                "typeString": null
                              }
                            }
                          },
                          "id": 440,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "kind": "typeConversion",
                          "lValueRequested": false,
                          "names": [],
                          "nodeType": "FunctionCall",
                          "src": "5412:20:0",
                          "tryCall": false,
                          "typeDescriptions": {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        },
                        {
                          "argumentTypes": null,
                          "id": 441,
                          "name": "amountToken",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 352,
                          "src": "5434:11:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          },
                          {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        ],
                        "expression": {
                          "argumentTypes": null,
                          "id": 434,
                          "name": "token",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 424,
                          "src": "5398:5:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_contract$_IERC20_$770",
                            "typeString": "contract IERC20"
                          }
                        },
                        "id": 436,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": false,
                        "lValueRequested": false,
                        "memberName": "approve",
                        "nodeType": "MemberAccess",
                        "referencedDeclaration": 739,
                        "src": "5398:13:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_external_nonpayable$_t_address_$_t_uint256_$returns$_t_bool_$",
                          "typeString": "function (address,uint256) external returns (bool)"
                        }
                      },
                      "id": 442,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "5398:48:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_bool",
                        "typeString": "bool"
                      }
                    },
                    "id": 443,
                    "nodeType": "ExpressionStatement",
                    "src": "5398:48:0"
                  },
                  {
                    "assignments": [
                      445
                    ],
                    "declarations": [
                      {
                        "constant": false,
                        "id": 445,
                        "mutability": "mutable",
                        "name": "amountRequired",
                        "nodeType": "VariableDeclaration",
                        "overrides": null,
                        "scope": 498,
                        "src": "5453:19:0",
                        "stateVariable": false,
                        "storageLocation": "default",
                        "typeDescriptions": {
                          "typeIdentifier": "t_uint256",
                          "typeString": "uint256"
                        },
                        "typeName": {
                          "id": 444,
                          "name": "uint",
                          "nodeType": "ElementaryTypeName",
                          "src": "5453:4:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        },
                        "value": null,
                        "visibility": "internal"
                      }
                    ],
                    "id": 454,
                    "initialValue": {
                      "argumentTypes": null,
                      "baseExpression": {
                        "argumentTypes": null,
                        "arguments": [
                          {
                            "argumentTypes": null,
                            "id": 448,
                            "name": "factory",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 19,
                            "src": "5512:7:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_address",
                              "typeString": "address"
                            }
                          },
                          {
                            "argumentTypes": null,
                            "id": 449,
                            "name": "amountToken",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 352,
                            "src": "5528:11:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            }
                          },
                          {
                            "argumentTypes": null,
                            "id": 450,
                            "name": "path",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 344,
                            "src": "5548:4:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_array$_t_address_$dyn_memory_ptr",
                              "typeString": "address[] memory"
                            }
                          }
                        ],
                        "expression": {
                          "argumentTypes": [
                            {
                              "typeIdentifier": "t_address",
                              "typeString": "address"
                            },
                            {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            },
                            {
                              "typeIdentifier": "t_array$_t_address_$dyn_memory_ptr",
                              "typeString": "address[] memory"
                            }
                          ],
                          "expression": {
                            "argumentTypes": null,
                            "id": 446,
                            "name": "UniswapV2Library",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 2272,
                            "src": "5475:16:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_type$_t_contract$_UniswapV2Library_$2272_$",
                              "typeString": "type(library UniswapV2Library)"
                            }
                          },
                          "id": 447,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "lValueRequested": false,
                          "memberName": "getAmountsIn",
                          "nodeType": "MemberAccess",
                          "referencedDeclaration": 2271,
                          "src": "5475:29:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_function_internal_view$_t_address_$_t_uint256_$_t_array$_t_address_$dyn_memory_ptr_$returns$_t_array$_t_uint256_$dyn_memory_ptr_$",
                            "typeString": "function (address,uint256,address[] memory) view returns (uint256[] memory)"
                          }
                        },
                        "id": 451,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": false,
                        "kind": "functionCall",
                        "lValueRequested": false,
                        "names": [],
                        "nodeType": "FunctionCall",
                        "src": "5475:83:0",
                        "tryCall": false,
                        "typeDescriptions": {
                          "typeIdentifier": "t_array$_t_uint256_$dyn_memory_ptr",
                          "typeString": "uint256[] memory"
                        }
                      },
                      "id": 453,
                      "indexExpression": {
                        "argumentTypes": null,
                        "hexValue": "30",
                        "id": 452,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": true,
                        "kind": "number",
                        "lValueRequested": false,
                        "nodeType": "Literal",
                        "src": "5559:1:0",
                        "subdenomination": null,
                        "typeDescriptions": {
                          "typeIdentifier": "t_rational_0_by_1",
                          "typeString": "int_const 0"
                        },
                        "value": "0"
                      },
                      "isConstant": false,
                      "isLValue": true,
                      "isPure": false,
                      "lValueRequested": false,
                      "nodeType": "IndexAccess",
                      "src": "5475:86:0",
                      "typeDescriptions": {
                        "typeIdentifier": "t_uint256",
                        "typeString": "uint256"
                      }
                    },
                    "nodeType": "VariableDeclarationStatement",
                    "src": "5453:108:0"
                  },
                  {
                    "assignments": [
                      456
                    ],
                    "declarations": [
                      {
                        "constant": false,
                        "id": 456,
                        "mutability": "mutable",
                        "name": "amountReceived",
                        "nodeType": "VariableDeclaration",
                        "overrides": null,
                        "scope": 498,
                        "src": "5567:19:0",
                        "stateVariable": false,
                        "storageLocation": "default",
                        "typeDescriptions": {
                          "typeIdentifier": "t_uint256",
                          "typeString": "uint256"
                        },
                        "typeName": {
                          "id": 455,
                          "name": "uint",
                          "nodeType": "ElementaryTypeName",
                          "src": "5567:4:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        },
                        "value": null,
                        "visibility": "internal"
                      }
                    ],
                    "id": 468,
                    "initialValue": {
                      "argumentTypes": null,
                      "baseExpression": {
                        "argumentTypes": null,
                        "arguments": [
                          {
                            "argumentTypes": null,
                            "id": 459,
                            "name": "amountToken",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 352,
                            "src": "5633:11:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            }
                          },
                          {
                            "argumentTypes": null,
                            "id": 460,
                            "name": "amountRequired",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 445,
                            "src": "5653:14:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            }
                          },
                          {
                            "argumentTypes": null,
                            "id": 461,
                            "name": "path",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 344,
                            "src": "5676:4:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_array$_t_address_$dyn_memory_ptr",
                              "typeString": "address[] memory"
                            }
                          },
                          {
                            "argumentTypes": null,
                            "expression": {
                              "argumentTypes": null,
                              "id": 462,
                              "name": "msg",
                              "nodeType": "Identifier",
                              "overloadedDeclarations": [],
                              "referencedDeclaration": -15,
                              "src": "5689:3:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_magic_message",
                                "typeString": "msg"
                              }
                            },
                            "id": 463,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "lValueRequested": false,
                            "memberName": "sender",
                            "nodeType": "MemberAccess",
                            "referencedDeclaration": null,
                            "src": "5689:10:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_address_payable",
                              "typeString": "address payable"
                            }
                          },
                          {
                            "argumentTypes": null,
                            "id": 464,
                            "name": "deadline",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 22,
                            "src": "5708:8:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            }
                          }
                        ],
                        "expression": {
                          "argumentTypes": [
                            {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            },
                            {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            },
                            {
                              "typeIdentifier": "t_array$_t_address_$dyn_memory_ptr",
                              "typeString": "address[] memory"
                            },
                            {
                              "typeIdentifier": "t_address_payable",
                              "typeString": "address payable"
                            },
                            {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            }
                          ],
                          "expression": {
                            "argumentTypes": null,
                            "id": 457,
                            "name": "sushiRouter",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 24,
                            "src": "5589:11:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_contract$_IUniswapV2Router02_$1468",
                              "typeString": "contract IUniswapV2Router02"
                            }
                          },
                          "id": 458,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "lValueRequested": false,
                          "memberName": "swapExactTokensForTokens",
                          "nodeType": "MemberAccess",
                          "referencedDeclaration": 1246,
                          "src": "5589:36:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_function_external_nonpayable$_t_uint256_$_t_uint256_$_t_array$_t_address_$dyn_memory_ptr_$_t_address_$_t_uint256_$returns$_t_array$_t_uint256_$dyn_memory_ptr_$",
                            "typeString": "function (uint256,uint256,address[] memory,address,uint256) external returns (uint256[] memory)"
                          }
                        },
                        "id": 465,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": false,
                        "kind": "functionCall",
                        "lValueRequested": false,
                        "names": [],
                        "nodeType": "FunctionCall",
                        "src": "5589:133:0",
                        "tryCall": false,
                        "typeDescriptions": {
                          "typeIdentifier": "t_array$_t_uint256_$dyn_memory_ptr",
                          "typeString": "uint256[] memory"
                        }
                      },
                      "id": 467,
                      "indexExpression": {
                        "argumentTypes": null,
                        "hexValue": "31",
                        "id": 466,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": true,
                        "kind": "number",
                        "lValueRequested": false,
                        "nodeType": "Literal",
                        "src": "5723:1:0",
                        "subdenomination": null,
                        "typeDescriptions": {
                          "typeIdentifier": "t_rational_1_by_1",
                          "typeString": "int_const 1"
                        },
                        "value": "1"
                      },
                      "isConstant": false,
                      "isLValue": true,
                      "isPure": false,
                      "lValueRequested": false,
                      "nodeType": "IndexAccess",
                      "src": "5589:136:0",
                      "typeDescriptions": {
                        "typeIdentifier": "t_uint256",
                        "typeString": "uint256"
                      }
                    },
                    "nodeType": "VariableDeclarationStatement",
                    "src": "5567:158:0"
                  },
                  {
                    "assignments": [
                      470
                    ],
                    "declarations": [
                      {
                        "constant": false,
                        "id": 470,
                        "mutability": "mutable",
                        "name": "otherToken",
                        "nodeType": "VariableDeclaration",
                        "overrides": null,
                        "scope": 498,
                        "src": "5732:17:0",
                        "stateVariable": false,
                        "storageLocation": "default",
                        "typeDescriptions": {
                          "typeIdentifier": "t_contract$_IERC20_$770",
                          "typeString": "contract IERC20"
                        },
                        "typeName": {
                          "contractScope": null,
                          "id": 469,
                          "name": "IERC20",
                          "nodeType": "UserDefinedTypeName",
                          "referencedDeclaration": 770,
                          "src": "5732:6:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_contract$_IERC20_$770",
                            "typeString": "contract IERC20"
                          }
                        },
                        "value": null,
                        "visibility": "internal"
                      }
                    ],
                    "id": 479,
                    "initialValue": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "condition": {
                            "argumentTypes": null,
                            "commonType": {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            },
                            "id": 474,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "lValueRequested": false,
                            "leftExpression": {
                              "argumentTypes": null,
                              "id": 472,
                              "name": "_amount0",
                              "nodeType": "Identifier",
                              "overloadedDeclarations": [],
                              "referencedDeclaration": 333,
                              "src": "5759:8:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_uint256",
                                "typeString": "uint256"
                              }
                            },
                            "nodeType": "BinaryOperation",
                            "operator": "==",
                            "rightExpression": {
                              "argumentTypes": null,
                              "hexValue": "30",
                              "id": 473,
                              "isConstant": false,
                              "isLValue": false,
                              "isPure": true,
                              "kind": "number",
                              "lValueRequested": false,
                              "nodeType": "Literal",
                              "src": "5771:1:0",
                              "subdenomination": null,
                              "typeDescriptions": {
                                "typeIdentifier": "t_rational_0_by_1",
                                "typeString": "int_const 0"
                              },
                              "value": "0"
                            },
                            "src": "5759:13:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_bool",
                              "typeString": "bool"
                            }
                          },
                          "falseExpression": {
                            "argumentTypes": null,
                            "id": 476,
                            "name": "token1",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 370,
                            "src": "5784:6:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_address",
                              "typeString": "address"
                            }
                          },
                          "id": 477,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "lValueRequested": false,
                          "nodeType": "Conditional",
                          "src": "5759:31:0",
                          "trueExpression": {
                            "argumentTypes": null,
                            "id": 475,
                            "name": "token0",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 361,
                            "src": "5775:6:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_address",
                              "typeString": "address"
                            }
                          },
                          "typeDescriptions": {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        ],
                        "id": 471,
                        "name": "IERC20",
                        "nodeType": "Identifier",
                        "overloadedDeclarations": [],
                        "referencedDeclaration": 770,
                        "src": "5752:6:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_type$_t_contract$_IERC20_$770_$",
                          "typeString": "type(contract IERC20)"
                        }
                      },
                      "id": 478,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "typeConversion",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "5752:39:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_contract$_IERC20_$770",
                        "typeString": "contract IERC20"
                      }
                    },
                    "nodeType": "VariableDeclarationStatement",
                    "src": "5732:59:0"
                  },
                  {
                    "expression": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "expression": {
                            "argumentTypes": null,
                            "id": 483,
                            "name": "msg",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": -15,
                            "src": "5817:3:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_magic_message",
                              "typeString": "msg"
                            }
                          },
                          "id": 484,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "lValueRequested": false,
                          "memberName": "sender",
                          "nodeType": "MemberAccess",
                          "referencedDeclaration": null,
                          "src": "5817:10:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_address_payable",
                            "typeString": "address payable"
                          }
                        },
                        {
                          "argumentTypes": null,
                          "id": 485,
                          "name": "amountRequired",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 445,
                          "src": "5829:14:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_address_payable",
                            "typeString": "address payable"
                          },
                          {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        ],
                        "expression": {
                          "argumentTypes": null,
                          "id": 480,
                          "name": "otherToken",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 470,
                          "src": "5797:10:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_contract$_IERC20_$770",
                            "typeString": "contract IERC20"
                          }
                        },
                        "id": 482,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": false,
                        "lValueRequested": false,
                        "memberName": "transfer",
                        "nodeType": "MemberAccess",
                        "referencedDeclaration": 719,
                        "src": "5797:19:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_external_nonpayable$_t_address_$_t_uint256_$returns$_t_bool_$",
                          "typeString": "function (address,uint256) external returns (bool)"
                        }
                      },
                      "id": 486,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "5797:47:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_bool",
                        "typeString": "bool"
                      }
                    },
                    "id": 487,
                    "nodeType": "ExpressionStatement",
                    "src": "5797:47:0"
                  },
                  {
                    "expression": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "expression": {
                            "argumentTypes": null,
                            "id": 491,
                            "name": "tx",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": -26,
                            "src": "5870:2:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_magic_transaction",
                              "typeString": "tx"
                            }
                          },
                          "id": 492,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "lValueRequested": false,
                          "memberName": "origin",
                          "nodeType": "MemberAccess",
                          "referencedDeclaration": null,
                          "src": "5870:9:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_address_payable",
                            "typeString": "address payable"
                          }
                        },
                        {
                          "argumentTypes": null,
                          "commonType": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          },
                          "id": 495,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "lValueRequested": false,
                          "leftExpression": {
                            "argumentTypes": null,
                            "id": 493,
                            "name": "amountReceived",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 456,
                            "src": "5881:14:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            }
                          },
                          "nodeType": "BinaryOperation",
                          "operator": "-",
                          "rightExpression": {
                            "argumentTypes": null,
                            "id": 494,
                            "name": "amountRequired",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 445,
                            "src": "5898:14:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            }
                          },
                          "src": "5881:31:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_address_payable",
                            "typeString": "address payable"
                          },
                          {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        ],
                        "expression": {
                          "argumentTypes": null,
                          "id": 488,
                          "name": "otherToken",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 470,
                          "src": "5850:10:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_contract$_IERC20_$770",
                            "typeString": "contract IERC20"
                          }
                        },
                        "id": 490,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": false,
                        "lValueRequested": false,
                        "memberName": "transfer",
                        "nodeType": "MemberAccess",
                        "referencedDeclaration": 719,
                        "src": "5850:19:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_external_nonpayable$_t_address_$_t_uint256_$returns$_t_bool_$",
                          "typeString": "function (address,uint256) external returns (bool)"
                        }
                      },
                      "id": 496,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "5850:63:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_bool",
                        "typeString": "bool"
                      }
                    },
                    "id": 497,
                    "nodeType": "ExpressionStatement",
                    "src": "5850:63:0"
                  }
                ]
              },
              "documentation": null,
              "functionSelector": "84800812",
              "id": 499,
              "implemented": true,
              "kind": "function",
              "modifiers": [],
              "name": "pancakeCall",
              "nodeType": "FunctionDefinition",
              "overrides": null,
              "parameters": {
                "id": 338,
                "nodeType": "ParameterList",
                "parameters": [
                  {
                    "constant": false,
                    "id": 331,
                    "mutability": "mutable",
                    "name": "_sender",
                    "nodeType": "VariableDeclaration",
                    "overrides": null,
                    "scope": 499,
                    "src": "4748:15:0",
                    "stateVariable": false,
                    "storageLocation": "default",
                    "typeDescriptions": {
                      "typeIdentifier": "t_address",
                      "typeString": "address"
                    },
                    "typeName": {
                      "id": 330,
                      "name": "address",
                      "nodeType": "ElementaryTypeName",
                      "src": "4748:7:0",
                      "stateMutability": "nonpayable",
                      "typeDescriptions": {
                        "typeIdentifier": "t_address",
                        "typeString": "address"
                      }
                    },
                    "value": null,
                    "visibility": "internal"
                  },
                  {
                    "constant": false,
                    "id": 333,
                    "mutability": "mutable",
                    "name": "_amount0",
                    "nodeType": "VariableDeclaration",
                    "overrides": null,
                    "scope": 499,
                    "src": "4770:13:0",
                    "stateVariable": false,
                    "storageLocation": "default",
                    "typeDescriptions": {
                      "typeIdentifier": "t_uint256",
                      "typeString": "uint256"
                    },
                    "typeName": {
                      "id": 332,
                      "name": "uint",
                      "nodeType": "ElementaryTypeName",
                      "src": "4770:4:0",
                      "typeDescriptions": {
                        "typeIdentifier": "t_uint256",
                        "typeString": "uint256"
                      }
                    },
                    "value": null,
                    "visibility": "internal"
                  },
                  {
                    "constant": false,
                    "id": 335,
                    "mutability": "mutable",
                    "name": "_amount1",
                    "nodeType": "VariableDeclaration",
                    "overrides": null,
                    "scope": 499,
                    "src": "4790:13:0",
                    "stateVariable": false,
                    "storageLocation": "default",
                    "typeDescriptions": {
                      "typeIdentifier": "t_uint256",
                      "typeString": "uint256"
                    },
                    "typeName": {
                      "id": 334,
                      "name": "uint",
                      "nodeType": "ElementaryTypeName",
                      "src": "4790:4:0",
                      "typeDescriptions": {
                        "typeIdentifier": "t_uint256",
                        "typeString": "uint256"
                      }
                    },
                    "value": null,
                    "visibility": "internal"
                  },
                  {
                    "constant": false,
                    "id": 337,
                    "mutability": "mutable",
                    "name": "_data",
                    "nodeType": "VariableDeclaration",
                    "overrides": null,
                    "scope": 499,
                    "src": "4810:20:0",
                    "stateVariable": false,
                    "storageLocation": "calldata",
                    "typeDescriptions": {
                      "typeIdentifier": "t_bytes_calldata_ptr",
                      "typeString": "bytes"
                    },
                    "typeName": {
                      "id": 336,
                      "name": "bytes",
                      "nodeType": "ElementaryTypeName",
                      "src": "4810:5:0",
                      "typeDescriptions": {
                        "typeIdentifier": "t_bytes_storage_ptr",
                        "typeString": "bytes"
                      }
                    },
                    "value": null,
                    "visibility": "internal"
                  }
                ],
                "src": "4742:92:0"
              },
              "returnParameters": {
                "id": 339,
                "nodeType": "ParameterList",
                "parameters": [],
                "src": "4844:0:0"
              },
              "scope": 670,
              "src": "4722:1196:0",
              "stateMutability": "nonpayable",
              "virtual": false,
              "visibility": "external"
            },
            {
              "body": {
                "id": 668,
                "nodeType": "Block",
                "src": "6045:1074:0",
                "statements": [
                  {
                    "assignments": [
                      514
                    ],
                    "declarations": [
                      {
                        "constant": false,
                        "id": 514,
                        "mutability": "mutable",
                        "name": "path",
                        "nodeType": "VariableDeclaration",
                        "overrides": null,
                        "scope": 668,
                        "src": "6051:21:0",
                        "stateVariable": false,
                        "storageLocation": "memory",
                        "typeDescriptions": {
                          "typeIdentifier": "t_array$_t_address_$dyn_memory_ptr",
                          "typeString": "address[]"
                        },
                        "typeName": {
                          "baseType": {
                            "id": 512,
                            "name": "address",
                            "nodeType": "ElementaryTypeName",
                            "src": "6051:7:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_address",
                              "typeString": "address"
                            }
                          },
                          "id": 513,
                          "length": null,
                          "nodeType": "ArrayTypeName",
                          "src": "6051:9:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_array$_t_address_$dyn_storage_ptr",
                            "typeString": "address[]"
                          }
                        },
                        "value": null,
                        "visibility": "internal"
                      }
                    ],
                    "id": 520,
                    "initialValue": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "hexValue": "32",
                          "id": 518,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": true,
                          "kind": "number",
                          "lValueRequested": false,
                          "nodeType": "Literal",
                          "src": "6089:1:0",
                          "subdenomination": null,
                          "typeDescriptions": {
                            "typeIdentifier": "t_rational_2_by_1",
                            "typeString": "int_const 2"
                          },
                          "value": "2"
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_rational_2_by_1",
                            "typeString": "int_const 2"
                          }
                        ],
                        "id": 517,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": true,
                        "lValueRequested": false,
                        "nodeType": "NewExpression",
                        "src": "6075:13:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_objectcreation_pure$_t_uint256_$returns$_t_array$_t_address_$dyn_memory_ptr_$",
                          "typeString": "function (uint256) pure returns (address[] memory)"
                        },
                        "typeName": {
                          "baseType": {
                            "id": 515,
                            "name": "address",
                            "nodeType": "ElementaryTypeName",
                            "src": "6079:7:0",
                            "stateMutability": "nonpayable",
                            "typeDescriptions": {
                              "typeIdentifier": "t_address",
                              "typeString": "address"
                            }
                          },
                          "id": 516,
                          "length": null,
                          "nodeType": "ArrayTypeName",
                          "src": "6079:9:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_array$_t_address_$dyn_storage_ptr",
                            "typeString": "address[]"
                          }
                        }
                      },
                      "id": 519,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": true,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "6075:16:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_array$_t_address_$dyn_memory_ptr",
                        "typeString": "address[] memory"
                      }
                    },
                    "nodeType": "VariableDeclarationStatement",
                    "src": "6051:40:0"
                  },
                  {
                    "assignments": [
                      522
                    ],
                    "declarations": [
                      {
                        "constant": false,
                        "id": 522,
                        "mutability": "mutable",
                        "name": "amountToken",
                        "nodeType": "VariableDeclaration",
                        "overrides": null,
                        "scope": 668,
                        "src": "6097:16:0",
                        "stateVariable": false,
                        "storageLocation": "default",
                        "typeDescriptions": {
                          "typeIdentifier": "t_uint256",
                          "typeString": "uint256"
                        },
                        "typeName": {
                          "id": 521,
                          "name": "uint",
                          "nodeType": "ElementaryTypeName",
                          "src": "6097:4:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        },
                        "value": null,
                        "visibility": "internal"
                      }
                    ],
                    "id": 529,
                    "initialValue": {
                      "argumentTypes": null,
                      "condition": {
                        "argumentTypes": null,
                        "commonType": {
                          "typeIdentifier": "t_uint256",
                          "typeString": "uint256"
                        },
                        "id": 525,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": false,
                        "lValueRequested": false,
                        "leftExpression": {
                          "argumentTypes": null,
                          "id": 523,
                          "name": "_amount0",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 503,
                          "src": "6116:8:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        },
                        "nodeType": "BinaryOperation",
                        "operator": "==",
                        "rightExpression": {
                          "argumentTypes": null,
                          "hexValue": "30",
                          "id": 524,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": true,
                          "kind": "number",
                          "lValueRequested": false,
                          "nodeType": "Literal",
                          "src": "6128:1:0",
                          "subdenomination": null,
                          "typeDescriptions": {
                            "typeIdentifier": "t_rational_0_by_1",
                            "typeString": "int_const 0"
                          },
                          "value": "0"
                        },
                        "src": "6116:13:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_bool",
                          "typeString": "bool"
                        }
                      },
                      "falseExpression": {
                        "argumentTypes": null,
                        "id": 527,
                        "name": "_amount0",
                        "nodeType": "Identifier",
                        "overloadedDeclarations": [],
                        "referencedDeclaration": 503,
                        "src": "6143:8:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_uint256",
                          "typeString": "uint256"
                        }
                      },
                      "id": 528,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "lValueRequested": false,
                      "nodeType": "Conditional",
                      "src": "6116:35:0",
                      "trueExpression": {
                        "argumentTypes": null,
                        "id": 526,
                        "name": "_amount1",
                        "nodeType": "Identifier",
                        "overloadedDeclarations": [],
                        "referencedDeclaration": 505,
                        "src": "6132:8:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_uint256",
                          "typeString": "uint256"
                        }
                      },
                      "typeDescriptions": {
                        "typeIdentifier": "t_uint256",
                        "typeString": "uint256"
                      }
                    },
                    "nodeType": "VariableDeclarationStatement",
                    "src": "6097:54:0"
                  },
                  {
                    "assignments": [
                      531
                    ],
                    "declarations": [
                      {
                        "constant": false,
                        "id": 531,
                        "mutability": "mutable",
                        "name": "token0",
                        "nodeType": "VariableDeclaration",
                        "overrides": null,
                        "scope": 668,
                        "src": "6162:14:0",
                        "stateVariable": false,
                        "storageLocation": "default",
                        "typeDescriptions": {
                          "typeIdentifier": "t_address",
                          "typeString": "address"
                        },
                        "typeName": {
                          "id": 530,
                          "name": "address",
                          "nodeType": "ElementaryTypeName",
                          "src": "6162:7:0",
                          "stateMutability": "nonpayable",
                          "typeDescriptions": {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        },
                        "value": null,
                        "visibility": "internal"
                      }
                    ],
                    "id": 538,
                    "initialValue": {
                      "argumentTypes": null,
                      "arguments": [],
                      "expression": {
                        "argumentTypes": [],
                        "expression": {
                          "argumentTypes": null,
                          "arguments": [
                            {
                              "argumentTypes": null,
                              "expression": {
                                "argumentTypes": null,
                                "id": 533,
                                "name": "msg",
                                "nodeType": "Identifier",
                                "overloadedDeclarations": [],
                                "referencedDeclaration": -15,
                                "src": "6194:3:0",
                                "typeDescriptions": {
                                  "typeIdentifier": "t_magic_message",
                                  "typeString": "msg"
                                }
                              },
                              "id": 534,
                              "isConstant": false,
                              "isLValue": false,
                              "isPure": false,
                              "lValueRequested": false,
                              "memberName": "sender",
                              "nodeType": "MemberAccess",
                              "referencedDeclaration": null,
                              "src": "6194:10:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_address_payable",
                                "typeString": "address payable"
                              }
                            }
                          ],
                          "expression": {
                            "argumentTypes": [
                              {
                                "typeIdentifier": "t_address_payable",
                                "typeString": "address payable"
                              }
                            ],
                            "id": 532,
                            "name": "IUniswapV2Pair",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 1075,
                            "src": "6179:14:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_type$_t_contract$_IUniswapV2Pair_$1075_$",
                              "typeString": "type(contract IUniswapV2Pair)"
                            }
                          },
                          "id": 535,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "kind": "typeConversion",
                          "lValueRequested": false,
                          "names": [],
                          "nodeType": "FunctionCall",
                          "src": "6179:26:0",
                          "tryCall": false,
                          "typeDescriptions": {
                            "typeIdentifier": "t_contract$_IUniswapV2Pair_$1075",
                            "typeString": "contract IUniswapV2Pair"
                          }
                        },
                        "id": 536,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": false,
                        "lValueRequested": false,
                        "memberName": "token0",
                        "nodeType": "MemberAccess",
                        "referencedDeclaration": 1003,
                        "src": "6179:33:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_external_view$__$returns$_t_address_$",
                          "typeString": "function () view external returns (address)"
                        }
                      },
                      "id": 537,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "6179:35:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_address",
                        "typeString": "address"
                      }
                    },
                    "nodeType": "VariableDeclarationStatement",
                    "src": "6162:52:0"
                  },
                  {
                    "assignments": [
                      540
                    ],
                    "declarations": [
                      {
                        "constant": false,
                        "id": 540,
                        "mutability": "mutable",
                        "name": "token1",
                        "nodeType": "VariableDeclaration",
                        "overrides": null,
                        "scope": 668,
                        "src": "6220:14:0",
                        "stateVariable": false,
                        "storageLocation": "default",
                        "typeDescriptions": {
                          "typeIdentifier": "t_address",
                          "typeString": "address"
                        },
                        "typeName": {
                          "id": 539,
                          "name": "address",
                          "nodeType": "ElementaryTypeName",
                          "src": "6220:7:0",
                          "stateMutability": "nonpayable",
                          "typeDescriptions": {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        },
                        "value": null,
                        "visibility": "internal"
                      }
                    ],
                    "id": 547,
                    "initialValue": {
                      "argumentTypes": null,
                      "arguments": [],
                      "expression": {
                        "argumentTypes": [],
                        "expression": {
                          "argumentTypes": null,
                          "arguments": [
                            {
                              "argumentTypes": null,
                              "expression": {
                                "argumentTypes": null,
                                "id": 542,
                                "name": "msg",
                                "nodeType": "Identifier",
                                "overloadedDeclarations": [],
                                "referencedDeclaration": -15,
                                "src": "6252:3:0",
                                "typeDescriptions": {
                                  "typeIdentifier": "t_magic_message",
                                  "typeString": "msg"
                                }
                              },
                              "id": 543,
                              "isConstant": false,
                              "isLValue": false,
                              "isPure": false,
                              "lValueRequested": false,
                              "memberName": "sender",
                              "nodeType": "MemberAccess",
                              "referencedDeclaration": null,
                              "src": "6252:10:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_address_payable",
                                "typeString": "address payable"
                              }
                            }
                          ],
                          "expression": {
                            "argumentTypes": [
                              {
                                "typeIdentifier": "t_address_payable",
                                "typeString": "address payable"
                              }
                            ],
                            "id": 541,
                            "name": "IUniswapV2Pair",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 1075,
                            "src": "6237:14:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_type$_t_contract$_IUniswapV2Pair_$1075_$",
                              "typeString": "type(contract IUniswapV2Pair)"
                            }
                          },
                          "id": 544,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "kind": "typeConversion",
                          "lValueRequested": false,
                          "names": [],
                          "nodeType": "FunctionCall",
                          "src": "6237:26:0",
                          "tryCall": false,
                          "typeDescriptions": {
                            "typeIdentifier": "t_contract$_IUniswapV2Pair_$1075",
                            "typeString": "contract IUniswapV2Pair"
                          }
                        },
                        "id": 545,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": false,
                        "lValueRequested": false,
                        "memberName": "token1",
                        "nodeType": "MemberAccess",
                        "referencedDeclaration": 1008,
                        "src": "6237:33:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_external_view$__$returns$_t_address_$",
                          "typeString": "function () view external returns (address)"
                        }
                      },
                      "id": 546,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "6237:35:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_address",
                        "typeString": "address"
                      }
                    },
                    "nodeType": "VariableDeclarationStatement",
                    "src": "6220:52:0"
                  },
                  {
                    "expression": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "commonType": {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          },
                          "id": 557,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "lValueRequested": false,
                          "leftExpression": {
                            "argumentTypes": null,
                            "expression": {
                              "argumentTypes": null,
                              "id": 549,
                              "name": "msg",
                              "nodeType": "Identifier",
                              "overloadedDeclarations": [],
                              "referencedDeclaration": -15,
                              "src": "6294:3:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_magic_message",
                                "typeString": "msg"
                              }
                            },
                            "id": 550,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "lValueRequested": false,
                            "memberName": "sender",
                            "nodeType": "MemberAccess",
                            "referencedDeclaration": null,
                            "src": "6294:10:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_address_payable",
                              "typeString": "address payable"
                            }
                          },
                          "nodeType": "BinaryOperation",
                          "operator": "==",
                          "rightExpression": {
                            "argumentTypes": null,
                            "arguments": [
                              {
                                "argumentTypes": null,
                                "id": 553,
                                "name": "factory",
                                "nodeType": "Identifier",
                                "overloadedDeclarations": [],
                                "referencedDeclaration": 19,
                                "src": "6333:7:0",
                                "typeDescriptions": {
                                  "typeIdentifier": "t_address",
                                  "typeString": "address"
                                }
                              },
                              {
                                "argumentTypes": null,
                                "id": 554,
                                "name": "token0",
                                "nodeType": "Identifier",
                                "overloadedDeclarations": [],
                                "referencedDeclaration": 531,
                                "src": "6342:6:0",
                                "typeDescriptions": {
                                  "typeIdentifier": "t_address",
                                  "typeString": "address"
                                }
                              },
                              {
                                "argumentTypes": null,
                                "id": 555,
                                "name": "token1",
                                "nodeType": "Identifier",
                                "overloadedDeclarations": [],
                                "referencedDeclaration": 540,
                                "src": "6350:6:0",
                                "typeDescriptions": {
                                  "typeIdentifier": "t_address",
                                  "typeString": "address"
                                }
                              }
                            ],
                            "expression": {
                              "argumentTypes": [
                                {
                                  "typeIdentifier": "t_address",
                                  "typeString": "address"
                                },
                                {
                                  "typeIdentifier": "t_address",
                                  "typeString": "address"
                                },
                                {
                                  "typeIdentifier": "t_address",
                                  "typeString": "address"
                                }
                              ],
                              "expression": {
                                "argumentTypes": null,
                                "id": 551,
                                "name": "UniswapV2Library",
                                "nodeType": "Identifier",
                                "overloadedDeclarations": [],
                                "referencedDeclaration": 2272,
                                "src": "6308:16:0",
                                "typeDescriptions": {
                                  "typeIdentifier": "t_type$_t_contract$_UniswapV2Library_$2272_$",
                                  "typeString": "type(library UniswapV2Library)"
                                }
                              },
                              "id": 552,
                              "isConstant": false,
                              "isLValue": false,
                              "isPure": false,
                              "lValueRequested": false,
                              "memberName": "pairFor",
                              "nodeType": "MemberAccess",
                              "referencedDeclaration": 1896,
                              "src": "6308:24:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_function_internal_pure$_t_address_$_t_address_$_t_address_$returns$_t_address_$",
                                "typeString": "function (address,address,address) pure returns (address)"
                              }
                            },
                            "id": 556,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "kind": "functionCall",
                            "lValueRequested": false,
                            "names": [],
                            "nodeType": "FunctionCall",
                            "src": "6308:49:0",
                            "tryCall": false,
                            "typeDescriptions": {
                              "typeIdentifier": "t_address",
                              "typeString": "address"
                            }
                          },
                          "src": "6294:63:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          }
                        },
                        {
                          "argumentTypes": null,
                          "hexValue": "556e617574686f72697a6564",
                          "id": 558,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": true,
                          "kind": "string",
                          "lValueRequested": false,
                          "nodeType": "Literal",
                          "src": "6366:14:0",
                          "subdenomination": null,
                          "typeDescriptions": {
                            "typeIdentifier": "t_stringliteral_1b2638459828301e8cd6c7c02856073bacf975379e0867f689bb14feacb780c5",
                            "typeString": "literal_string \"Unauthorized\""
                          },
                          "value": "Unauthorized"
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          },
                          {
                            "typeIdentifier": "t_stringliteral_1b2638459828301e8cd6c7c02856073bacf975379e0867f689bb14feacb780c5",
                            "typeString": "literal_string \"Unauthorized\""
                          }
                        ],
                        "id": 548,
                        "name": "require",
                        "nodeType": "Identifier",
                        "overloadedDeclarations": [
                          -18,
                          -18
                        ],
                        "referencedDeclaration": -18,
                        "src": "6279:7:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_require_pure$_t_bool_$_t_string_memory_ptr_$returns$__$",
                          "typeString": "function (bool,string memory) pure"
                        }
                      },
                      "id": 559,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "6279:107:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_tuple$__$",
                        "typeString": "tuple()"
                      }
                    },
                    "id": 560,
                    "nodeType": "ExpressionStatement",
                    "src": "6279:107:0"
                  },
                  {
                    "expression": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "commonType": {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          },
                          "id": 568,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "lValueRequested": false,
                          "leftExpression": {
                            "argumentTypes": null,
                            "commonType": {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            },
                            "id": 564,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "lValueRequested": false,
                            "leftExpression": {
                              "argumentTypes": null,
                              "id": 562,
                              "name": "_amount0",
                              "nodeType": "Identifier",
                              "overloadedDeclarations": [],
                              "referencedDeclaration": 503,
                              "src": "6401:8:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_uint256",
                                "typeString": "uint256"
                              }
                            },
                            "nodeType": "BinaryOperation",
                            "operator": "==",
                            "rightExpression": {
                              "argumentTypes": null,
                              "hexValue": "30",
                              "id": 563,
                              "isConstant": false,
                              "isLValue": false,
                              "isPure": true,
                              "kind": "number",
                              "lValueRequested": false,
                              "nodeType": "Literal",
                              "src": "6413:1:0",
                              "subdenomination": null,
                              "typeDescriptions": {
                                "typeIdentifier": "t_rational_0_by_1",
                                "typeString": "int_const 0"
                              },
                              "value": "0"
                            },
                            "src": "6401:13:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_bool",
                              "typeString": "bool"
                            }
                          },
                          "nodeType": "BinaryOperation",
                          "operator": "||",
                          "rightExpression": {
                            "argumentTypes": null,
                            "commonType": {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            },
                            "id": 567,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "lValueRequested": false,
                            "leftExpression": {
                              "argumentTypes": null,
                              "id": 565,
                              "name": "_amount1",
                              "nodeType": "Identifier",
                              "overloadedDeclarations": [],
                              "referencedDeclaration": 505,
                              "src": "6418:8:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_uint256",
                                "typeString": "uint256"
                              }
                            },
                            "nodeType": "BinaryOperation",
                            "operator": "==",
                            "rightExpression": {
                              "argumentTypes": null,
                              "hexValue": "30",
                              "id": 566,
                              "isConstant": false,
                              "isLValue": false,
                              "isPure": true,
                              "kind": "number",
                              "lValueRequested": false,
                              "nodeType": "Literal",
                              "src": "6430:1:0",
                              "subdenomination": null,
                              "typeDescriptions": {
                                "typeIdentifier": "t_rational_0_by_1",
                                "typeString": "int_const 0"
                              },
                              "value": "0"
                            },
                            "src": "6418:13:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_bool",
                              "typeString": "bool"
                            }
                          },
                          "src": "6401:30:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          }
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          }
                        ],
                        "id": 561,
                        "name": "require",
                        "nodeType": "Identifier",
                        "overloadedDeclarations": [
                          -18,
                          -18
                        ],
                        "referencedDeclaration": -18,
                        "src": "6393:7:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_require_pure$_t_bool_$returns$__$",
                          "typeString": "function (bool) pure"
                        }
                      },
                      "id": 569,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "6393:39:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_tuple$__$",
                        "typeString": "tuple()"
                      }
                    },
                    "id": 570,
                    "nodeType": "ExpressionStatement",
                    "src": "6393:39:0"
                  },
                  {
                    "expression": {
                      "argumentTypes": null,
                      "id": 580,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "lValueRequested": false,
                      "leftHandSide": {
                        "argumentTypes": null,
                        "baseExpression": {
                          "argumentTypes": null,
                          "id": 571,
                          "name": "path",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 514,
                          "src": "6439:4:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_array$_t_address_$dyn_memory_ptr",
                            "typeString": "address[] memory"
                          }
                        },
                        "id": 573,
                        "indexExpression": {
                          "argumentTypes": null,
                          "hexValue": "30",
                          "id": 572,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": true,
                          "kind": "number",
                          "lValueRequested": false,
                          "nodeType": "Literal",
                          "src": "6444:1:0",
                          "subdenomination": null,
                          "typeDescriptions": {
                            "typeIdentifier": "t_rational_0_by_1",
                            "typeString": "int_const 0"
                          },
                          "value": "0"
                        },
                        "isConstant": false,
                        "isLValue": true,
                        "isPure": false,
                        "lValueRequested": true,
                        "nodeType": "IndexAccess",
                        "src": "6439:7:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_address",
                          "typeString": "address"
                        }
                      },
                      "nodeType": "Assignment",
                      "operator": "=",
                      "rightHandSide": {
                        "argumentTypes": null,
                        "condition": {
                          "argumentTypes": null,
                          "commonType": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          },
                          "id": 576,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "lValueRequested": false,
                          "leftExpression": {
                            "argumentTypes": null,
                            "id": 574,
                            "name": "_amount0",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 503,
                            "src": "6449:8:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            }
                          },
                          "nodeType": "BinaryOperation",
                          "operator": "==",
                          "rightExpression": {
                            "argumentTypes": null,
                            "hexValue": "30",
                            "id": 575,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": true,
                            "kind": "number",
                            "lValueRequested": false,
                            "nodeType": "Literal",
                            "src": "6461:1:0",
                            "subdenomination": null,
                            "typeDescriptions": {
                              "typeIdentifier": "t_rational_0_by_1",
                              "typeString": "int_const 0"
                            },
                            "value": "0"
                          },
                          "src": "6449:13:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          }
                        },
                        "falseExpression": {
                          "argumentTypes": null,
                          "id": 578,
                          "name": "token0",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 531,
                          "src": "6474:6:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        },
                        "id": 579,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": false,
                        "lValueRequested": false,
                        "nodeType": "Conditional",
                        "src": "6449:31:0",
                        "trueExpression": {
                          "argumentTypes": null,
                          "id": 577,
                          "name": "token1",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 540,
                          "src": "6465:6:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        },
                        "typeDescriptions": {
                          "typeIdentifier": "t_address",
                          "typeString": "address"
                        }
                      },
                      "src": "6439:41:0",
                      "typeDescriptions": {
                        "typeIdentifier": "t_address",
                        "typeString": "address"
                      }
                    },
                    "id": 581,
                    "nodeType": "ExpressionStatement",
                    "src": "6439:41:0"
                  },
                  {
                    "expression": {
                      "argumentTypes": null,
                      "id": 591,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "lValueRequested": false,
                      "leftHandSide": {
                        "argumentTypes": null,
                        "baseExpression": {
                          "argumentTypes": null,
                          "id": 582,
                          "name": "path",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 514,
                          "src": "6486:4:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_array$_t_address_$dyn_memory_ptr",
                            "typeString": "address[] memory"
                          }
                        },
                        "id": 584,
                        "indexExpression": {
                          "argumentTypes": null,
                          "hexValue": "31",
                          "id": 583,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": true,
                          "kind": "number",
                          "lValueRequested": false,
                          "nodeType": "Literal",
                          "src": "6491:1:0",
                          "subdenomination": null,
                          "typeDescriptions": {
                            "typeIdentifier": "t_rational_1_by_1",
                            "typeString": "int_const 1"
                          },
                          "value": "1"
                        },
                        "isConstant": false,
                        "isLValue": true,
                        "isPure": false,
                        "lValueRequested": true,
                        "nodeType": "IndexAccess",
                        "src": "6486:7:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_address",
                          "typeString": "address"
                        }
                      },
                      "nodeType": "Assignment",
                      "operator": "=",
                      "rightHandSide": {
                        "argumentTypes": null,
                        "condition": {
                          "argumentTypes": null,
                          "commonType": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          },
                          "id": 587,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "lValueRequested": false,
                          "leftExpression": {
                            "argumentTypes": null,
                            "id": 585,
                            "name": "_amount0",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 503,
                            "src": "6496:8:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            }
                          },
                          "nodeType": "BinaryOperation",
                          "operator": "==",
                          "rightExpression": {
                            "argumentTypes": null,
                            "hexValue": "30",
                            "id": 586,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": true,
                            "kind": "number",
                            "lValueRequested": false,
                            "nodeType": "Literal",
                            "src": "6508:1:0",
                            "subdenomination": null,
                            "typeDescriptions": {
                              "typeIdentifier": "t_rational_0_by_1",
                              "typeString": "int_const 0"
                            },
                            "value": "0"
                          },
                          "src": "6496:13:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_bool",
                            "typeString": "bool"
                          }
                        },
                        "falseExpression": {
                          "argumentTypes": null,
                          "id": 589,
                          "name": "token1",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 540,
                          "src": "6521:6:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        },
                        "id": 590,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": false,
                        "lValueRequested": false,
                        "nodeType": "Conditional",
                        "src": "6496:31:0",
                        "trueExpression": {
                          "argumentTypes": null,
                          "id": 588,
                          "name": "token0",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 531,
                          "src": "6512:6:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        },
                        "typeDescriptions": {
                          "typeIdentifier": "t_address",
                          "typeString": "address"
                        }
                      },
                      "src": "6486:41:0",
                      "typeDescriptions": {
                        "typeIdentifier": "t_address",
                        "typeString": "address"
                      }
                    },
                    "id": 592,
                    "nodeType": "ExpressionStatement",
                    "src": "6486:41:0"
                  },
                  {
                    "assignments": [
                      594
                    ],
                    "declarations": [
                      {
                        "constant": false,
                        "id": 594,
                        "mutability": "mutable",
                        "name": "token",
                        "nodeType": "VariableDeclaration",
                        "overrides": null,
                        "scope": 668,
                        "src": "6534:12:0",
                        "stateVariable": false,
                        "storageLocation": "default",
                        "typeDescriptions": {
                          "typeIdentifier": "t_contract$_IERC20_$770",
                          "typeString": "contract IERC20"
                        },
                        "typeName": {
                          "contractScope": null,
                          "id": 593,
                          "name": "IERC20",
                          "nodeType": "UserDefinedTypeName",
                          "referencedDeclaration": 770,
                          "src": "6534:6:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_contract$_IERC20_$770",
                            "typeString": "contract IERC20"
                          }
                        },
                        "value": null,
                        "visibility": "internal"
                      }
                    ],
                    "id": 603,
                    "initialValue": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "condition": {
                            "argumentTypes": null,
                            "commonType": {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            },
                            "id": 598,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "lValueRequested": false,
                            "leftExpression": {
                              "argumentTypes": null,
                              "id": 596,
                              "name": "_amount0",
                              "nodeType": "Identifier",
                              "overloadedDeclarations": [],
                              "referencedDeclaration": 503,
                              "src": "6556:8:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_uint256",
                                "typeString": "uint256"
                              }
                            },
                            "nodeType": "BinaryOperation",
                            "operator": "==",
                            "rightExpression": {
                              "argumentTypes": null,
                              "hexValue": "30",
                              "id": 597,
                              "isConstant": false,
                              "isLValue": false,
                              "isPure": true,
                              "kind": "number",
                              "lValueRequested": false,
                              "nodeType": "Literal",
                              "src": "6568:1:0",
                              "subdenomination": null,
                              "typeDescriptions": {
                                "typeIdentifier": "t_rational_0_by_1",
                                "typeString": "int_const 0"
                              },
                              "value": "0"
                            },
                            "src": "6556:13:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_bool",
                              "typeString": "bool"
                            }
                          },
                          "falseExpression": {
                            "argumentTypes": null,
                            "id": 600,
                            "name": "token0",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 531,
                            "src": "6581:6:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_address",
                              "typeString": "address"
                            }
                          },
                          "id": 601,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "lValueRequested": false,
                          "nodeType": "Conditional",
                          "src": "6556:31:0",
                          "trueExpression": {
                            "argumentTypes": null,
                            "id": 599,
                            "name": "token1",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 540,
                            "src": "6572:6:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_address",
                              "typeString": "address"
                            }
                          },
                          "typeDescriptions": {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        ],
                        "id": 595,
                        "name": "IERC20",
                        "nodeType": "Identifier",
                        "overloadedDeclarations": [],
                        "referencedDeclaration": 770,
                        "src": "6549:6:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_type$_t_contract$_IERC20_$770_$",
                          "typeString": "type(contract IERC20)"
                        }
                      },
                      "id": 602,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "typeConversion",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "6549:39:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_contract$_IERC20_$770",
                        "typeString": "contract IERC20"
                      }
                    },
                    "nodeType": "VariableDeclarationStatement",
                    "src": "6534:54:0"
                  },
                  {
                    "expression": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "arguments": [
                            {
                              "argumentTypes": null,
                              "id": 609,
                              "name": "sushiRouter",
                              "nodeType": "Identifier",
                              "overloadedDeclarations": [],
                              "referencedDeclaration": 24,
                              "src": "6621:11:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_contract$_IUniswapV2Router02_$1468",
                                "typeString": "contract IUniswapV2Router02"
                              }
                            }
                          ],
                          "expression": {
                            "argumentTypes": [
                              {
                                "typeIdentifier": "t_contract$_IUniswapV2Router02_$1468",
                                "typeString": "contract IUniswapV2Router02"
                              }
                            ],
                            "id": 608,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": true,
                            "lValueRequested": false,
                            "nodeType": "ElementaryTypeNameExpression",
                            "src": "6613:7:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_type$_t_address_$",
                              "typeString": "type(address)"
                            },
                            "typeName": {
                              "id": 607,
                              "name": "address",
                              "nodeType": "ElementaryTypeName",
                              "src": "6613:7:0",
                              "typeDescriptions": {
                                "typeIdentifier": null,
                                "typeString": null
                              }
                            }
                          },
                          "id": 610,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "kind": "typeConversion",
                          "lValueRequested": false,
                          "names": [],
                          "nodeType": "FunctionCall",
                          "src": "6613:20:0",
                          "tryCall": false,
                          "typeDescriptions": {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        },
                        {
                          "argumentTypes": null,
                          "id": 611,
                          "name": "amountToken",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 522,
                          "src": "6635:11:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          },
                          {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        ],
                        "expression": {
                          "argumentTypes": null,
                          "id": 604,
                          "name": "token",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 594,
                          "src": "6599:5:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_contract$_IERC20_$770",
                            "typeString": "contract IERC20"
                          }
                        },
                        "id": 606,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": false,
                        "lValueRequested": false,
                        "memberName": "approve",
                        "nodeType": "MemberAccess",
                        "referencedDeclaration": 739,
                        "src": "6599:13:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_external_nonpayable$_t_address_$_t_uint256_$returns$_t_bool_$",
                          "typeString": "function (address,uint256) external returns (bool)"
                        }
                      },
                      "id": 612,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "6599:48:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_bool",
                        "typeString": "bool"
                      }
                    },
                    "id": 613,
                    "nodeType": "ExpressionStatement",
                    "src": "6599:48:0"
                  },
                  {
                    "assignments": [
                      615
                    ],
                    "declarations": [
                      {
                        "constant": false,
                        "id": 615,
                        "mutability": "mutable",
                        "name": "amountRequired",
                        "nodeType": "VariableDeclaration",
                        "overrides": null,
                        "scope": 668,
                        "src": "6654:19:0",
                        "stateVariable": false,
                        "storageLocation": "default",
                        "typeDescriptions": {
                          "typeIdentifier": "t_uint256",
                          "typeString": "uint256"
                        },
                        "typeName": {
                          "id": 614,
                          "name": "uint",
                          "nodeType": "ElementaryTypeName",
                          "src": "6654:4:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        },
                        "value": null,
                        "visibility": "internal"
                      }
                    ],
                    "id": 624,
                    "initialValue": {
                      "argumentTypes": null,
                      "baseExpression": {
                        "argumentTypes": null,
                        "arguments": [
                          {
                            "argumentTypes": null,
                            "id": 618,
                            "name": "factory",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 19,
                            "src": "6713:7:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_address",
                              "typeString": "address"
                            }
                          },
                          {
                            "argumentTypes": null,
                            "id": 619,
                            "name": "amountToken",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 522,
                            "src": "6729:11:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            }
                          },
                          {
                            "argumentTypes": null,
                            "id": 620,
                            "name": "path",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 514,
                            "src": "6749:4:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_array$_t_address_$dyn_memory_ptr",
                              "typeString": "address[] memory"
                            }
                          }
                        ],
                        "expression": {
                          "argumentTypes": [
                            {
                              "typeIdentifier": "t_address",
                              "typeString": "address"
                            },
                            {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            },
                            {
                              "typeIdentifier": "t_array$_t_address_$dyn_memory_ptr",
                              "typeString": "address[] memory"
                            }
                          ],
                          "expression": {
                            "argumentTypes": null,
                            "id": 616,
                            "name": "UniswapV2Library",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 2272,
                            "src": "6676:16:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_type$_t_contract$_UniswapV2Library_$2272_$",
                              "typeString": "type(library UniswapV2Library)"
                            }
                          },
                          "id": 617,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "lValueRequested": false,
                          "memberName": "getAmountsIn",
                          "nodeType": "MemberAccess",
                          "referencedDeclaration": 2271,
                          "src": "6676:29:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_function_internal_view$_t_address_$_t_uint256_$_t_array$_t_address_$dyn_memory_ptr_$returns$_t_array$_t_uint256_$dyn_memory_ptr_$",
                            "typeString": "function (address,uint256,address[] memory) view returns (uint256[] memory)"
                          }
                        },
                        "id": 621,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": false,
                        "kind": "functionCall",
                        "lValueRequested": false,
                        "names": [],
                        "nodeType": "FunctionCall",
                        "src": "6676:83:0",
                        "tryCall": false,
                        "typeDescriptions": {
                          "typeIdentifier": "t_array$_t_uint256_$dyn_memory_ptr",
                          "typeString": "uint256[] memory"
                        }
                      },
                      "id": 623,
                      "indexExpression": {
                        "argumentTypes": null,
                        "hexValue": "30",
                        "id": 622,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": true,
                        "kind": "number",
                        "lValueRequested": false,
                        "nodeType": "Literal",
                        "src": "6760:1:0",
                        "subdenomination": null,
                        "typeDescriptions": {
                          "typeIdentifier": "t_rational_0_by_1",
                          "typeString": "int_const 0"
                        },
                        "value": "0"
                      },
                      "isConstant": false,
                      "isLValue": true,
                      "isPure": false,
                      "lValueRequested": false,
                      "nodeType": "IndexAccess",
                      "src": "6676:86:0",
                      "typeDescriptions": {
                        "typeIdentifier": "t_uint256",
                        "typeString": "uint256"
                      }
                    },
                    "nodeType": "VariableDeclarationStatement",
                    "src": "6654:108:0"
                  },
                  {
                    "assignments": [
                      626
                    ],
                    "declarations": [
                      {
                        "constant": false,
                        "id": 626,
                        "mutability": "mutable",
                        "name": "amountReceived",
                        "nodeType": "VariableDeclaration",
                        "overrides": null,
                        "scope": 668,
                        "src": "6768:19:0",
                        "stateVariable": false,
                        "storageLocation": "default",
                        "typeDescriptions": {
                          "typeIdentifier": "t_uint256",
                          "typeString": "uint256"
                        },
                        "typeName": {
                          "id": 625,
                          "name": "uint",
                          "nodeType": "ElementaryTypeName",
                          "src": "6768:4:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        },
                        "value": null,
                        "visibility": "internal"
                      }
                    ],
                    "id": 638,
                    "initialValue": {
                      "argumentTypes": null,
                      "baseExpression": {
                        "argumentTypes": null,
                        "arguments": [
                          {
                            "argumentTypes": null,
                            "id": 629,
                            "name": "amountToken",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 522,
                            "src": "6834:11:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            }
                          },
                          {
                            "argumentTypes": null,
                            "id": 630,
                            "name": "amountRequired",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 615,
                            "src": "6854:14:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            }
                          },
                          {
                            "argumentTypes": null,
                            "id": 631,
                            "name": "path",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 514,
                            "src": "6877:4:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_array$_t_address_$dyn_memory_ptr",
                              "typeString": "address[] memory"
                            }
                          },
                          {
                            "argumentTypes": null,
                            "expression": {
                              "argumentTypes": null,
                              "id": 632,
                              "name": "msg",
                              "nodeType": "Identifier",
                              "overloadedDeclarations": [],
                              "referencedDeclaration": -15,
                              "src": "6890:3:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_magic_message",
                                "typeString": "msg"
                              }
                            },
                            "id": 633,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "lValueRequested": false,
                            "memberName": "sender",
                            "nodeType": "MemberAccess",
                            "referencedDeclaration": null,
                            "src": "6890:10:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_address_payable",
                              "typeString": "address payable"
                            }
                          },
                          {
                            "argumentTypes": null,
                            "id": 634,
                            "name": "deadline",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 22,
                            "src": "6909:8:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            }
                          }
                        ],
                        "expression": {
                          "argumentTypes": [
                            {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            },
                            {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            },
                            {
                              "typeIdentifier": "t_array$_t_address_$dyn_memory_ptr",
                              "typeString": "address[] memory"
                            },
                            {
                              "typeIdentifier": "t_address_payable",
                              "typeString": "address payable"
                            },
                            {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            }
                          ],
                          "expression": {
                            "argumentTypes": null,
                            "id": 627,
                            "name": "sushiRouter",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 24,
                            "src": "6790:11:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_contract$_IUniswapV2Router02_$1468",
                              "typeString": "contract IUniswapV2Router02"
                            }
                          },
                          "id": 628,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "lValueRequested": false,
                          "memberName": "swapExactTokensForTokens",
                          "nodeType": "MemberAccess",
                          "referencedDeclaration": 1246,
                          "src": "6790:36:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_function_external_nonpayable$_t_uint256_$_t_uint256_$_t_array$_t_address_$dyn_memory_ptr_$_t_address_$_t_uint256_$returns$_t_array$_t_uint256_$dyn_memory_ptr_$",
                            "typeString": "function (uint256,uint256,address[] memory,address,uint256) external returns (uint256[] memory)"
                          }
                        },
                        "id": 635,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": false,
                        "kind": "functionCall",
                        "lValueRequested": false,
                        "names": [],
                        "nodeType": "FunctionCall",
                        "src": "6790:133:0",
                        "tryCall": false,
                        "typeDescriptions": {
                          "typeIdentifier": "t_array$_t_uint256_$dyn_memory_ptr",
                          "typeString": "uint256[] memory"
                        }
                      },
                      "id": 637,
                      "indexExpression": {
                        "argumentTypes": null,
                        "hexValue": "31",
                        "id": 636,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": true,
                        "kind": "number",
                        "lValueRequested": false,
                        "nodeType": "Literal",
                        "src": "6924:1:0",
                        "subdenomination": null,
                        "typeDescriptions": {
                          "typeIdentifier": "t_rational_1_by_1",
                          "typeString": "int_const 1"
                        },
                        "value": "1"
                      },
                      "isConstant": false,
                      "isLValue": true,
                      "isPure": false,
                      "lValueRequested": false,
                      "nodeType": "IndexAccess",
                      "src": "6790:136:0",
                      "typeDescriptions": {
                        "typeIdentifier": "t_uint256",
                        "typeString": "uint256"
                      }
                    },
                    "nodeType": "VariableDeclarationStatement",
                    "src": "6768:158:0"
                  },
                  {
                    "assignments": [
                      640
                    ],
                    "declarations": [
                      {
                        "constant": false,
                        "id": 640,
                        "mutability": "mutable",
                        "name": "otherToken",
                        "nodeType": "VariableDeclaration",
                        "overrides": null,
                        "scope": 668,
                        "src": "6933:17:0",
                        "stateVariable": false,
                        "storageLocation": "default",
                        "typeDescriptions": {
                          "typeIdentifier": "t_contract$_IERC20_$770",
                          "typeString": "contract IERC20"
                        },
                        "typeName": {
                          "contractScope": null,
                          "id": 639,
                          "name": "IERC20",
                          "nodeType": "UserDefinedTypeName",
                          "referencedDeclaration": 770,
                          "src": "6933:6:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_contract$_IERC20_$770",
                            "typeString": "contract IERC20"
                          }
                        },
                        "value": null,
                        "visibility": "internal"
                      }
                    ],
                    "id": 649,
                    "initialValue": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "condition": {
                            "argumentTypes": null,
                            "commonType": {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            },
                            "id": 644,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "lValueRequested": false,
                            "leftExpression": {
                              "argumentTypes": null,
                              "id": 642,
                              "name": "_amount0",
                              "nodeType": "Identifier",
                              "overloadedDeclarations": [],
                              "referencedDeclaration": 503,
                              "src": "6960:8:0",
                              "typeDescriptions": {
                                "typeIdentifier": "t_uint256",
                                "typeString": "uint256"
                              }
                            },
                            "nodeType": "BinaryOperation",
                            "operator": "==",
                            "rightExpression": {
                              "argumentTypes": null,
                              "hexValue": "30",
                              "id": 643,
                              "isConstant": false,
                              "isLValue": false,
                              "isPure": true,
                              "kind": "number",
                              "lValueRequested": false,
                              "nodeType": "Literal",
                              "src": "6972:1:0",
                              "subdenomination": null,
                              "typeDescriptions": {
                                "typeIdentifier": "t_rational_0_by_1",
                                "typeString": "int_const 0"
                              },
                              "value": "0"
                            },
                            "src": "6960:13:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_bool",
                              "typeString": "bool"
                            }
                          },
                          "falseExpression": {
                            "argumentTypes": null,
                            "id": 646,
                            "name": "token1",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 540,
                            "src": "6985:6:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_address",
                              "typeString": "address"
                            }
                          },
                          "id": 647,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "lValueRequested": false,
                          "nodeType": "Conditional",
                          "src": "6960:31:0",
                          "trueExpression": {
                            "argumentTypes": null,
                            "id": 645,
                            "name": "token0",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 531,
                            "src": "6976:6:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_address",
                              "typeString": "address"
                            }
                          },
                          "typeDescriptions": {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_address",
                            "typeString": "address"
                          }
                        ],
                        "id": 641,
                        "name": "IERC20",
                        "nodeType": "Identifier",
                        "overloadedDeclarations": [],
                        "referencedDeclaration": 770,
                        "src": "6953:6:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_type$_t_contract$_IERC20_$770_$",
                          "typeString": "type(contract IERC20)"
                        }
                      },
                      "id": 648,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "typeConversion",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "6953:39:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_contract$_IERC20_$770",
                        "typeString": "contract IERC20"
                      }
                    },
                    "nodeType": "VariableDeclarationStatement",
                    "src": "6933:59:0"
                  },
                  {
                    "expression": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "expression": {
                            "argumentTypes": null,
                            "id": 653,
                            "name": "msg",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": -15,
                            "src": "7018:3:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_magic_message",
                              "typeString": "msg"
                            }
                          },
                          "id": 654,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "lValueRequested": false,
                          "memberName": "sender",
                          "nodeType": "MemberAccess",
                          "referencedDeclaration": null,
                          "src": "7018:10:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_address_payable",
                            "typeString": "address payable"
                          }
                        },
                        {
                          "argumentTypes": null,
                          "id": 655,
                          "name": "amountRequired",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 615,
                          "src": "7030:14:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_address_payable",
                            "typeString": "address payable"
                          },
                          {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        ],
                        "expression": {
                          "argumentTypes": null,
                          "id": 650,
                          "name": "otherToken",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 640,
                          "src": "6998:10:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_contract$_IERC20_$770",
                            "typeString": "contract IERC20"
                          }
                        },
                        "id": 652,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": false,
                        "lValueRequested": false,
                        "memberName": "transfer",
                        "nodeType": "MemberAccess",
                        "referencedDeclaration": 719,
                        "src": "6998:19:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_external_nonpayable$_t_address_$_t_uint256_$returns$_t_bool_$",
                          "typeString": "function (address,uint256) external returns (bool)"
                        }
                      },
                      "id": 656,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "6998:47:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_bool",
                        "typeString": "bool"
                      }
                    },
                    "id": 657,
                    "nodeType": "ExpressionStatement",
                    "src": "6998:47:0"
                  },
                  {
                    "expression": {
                      "argumentTypes": null,
                      "arguments": [
                        {
                          "argumentTypes": null,
                          "expression": {
                            "argumentTypes": null,
                            "id": 661,
                            "name": "tx",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": -26,
                            "src": "7071:2:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_magic_transaction",
                              "typeString": "tx"
                            }
                          },
                          "id": 662,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "lValueRequested": false,
                          "memberName": "origin",
                          "nodeType": "MemberAccess",
                          "referencedDeclaration": null,
                          "src": "7071:9:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_address_payable",
                            "typeString": "address payable"
                          }
                        },
                        {
                          "argumentTypes": null,
                          "commonType": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          },
                          "id": 665,
                          "isConstant": false,
                          "isLValue": false,
                          "isPure": false,
                          "lValueRequested": false,
                          "leftExpression": {
                            "argumentTypes": null,
                            "id": 663,
                            "name": "amountReceived",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 626,
                            "src": "7082:14:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            }
                          },
                          "nodeType": "BinaryOperation",
                          "operator": "-",
                          "rightExpression": {
                            "argumentTypes": null,
                            "id": 664,
                            "name": "amountRequired",
                            "nodeType": "Identifier",
                            "overloadedDeclarations": [],
                            "referencedDeclaration": 615,
                            "src": "7099:14:0",
                            "typeDescriptions": {
                              "typeIdentifier": "t_uint256",
                              "typeString": "uint256"
                            }
                          },
                          "src": "7082:31:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        }
                      ],
                      "expression": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_address_payable",
                            "typeString": "address payable"
                          },
                          {
                            "typeIdentifier": "t_uint256",
                            "typeString": "uint256"
                          }
                        ],
                        "expression": {
                          "argumentTypes": null,
                          "id": 658,
                          "name": "otherToken",
                          "nodeType": "Identifier",
                          "overloadedDeclarations": [],
                          "referencedDeclaration": 640,
                          "src": "7051:10:0",
                          "typeDescriptions": {
                            "typeIdentifier": "t_contract$_IERC20_$770",
                            "typeString": "contract IERC20"
                          }
                        },
                        "id": 660,
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": false,
                        "lValueRequested": false,
                        "memberName": "transfer",
                        "nodeType": "MemberAccess",
                        "referencedDeclaration": 719,
                        "src": "7051:19:0",
                        "typeDescriptions": {
                          "typeIdentifier": "t_function_external_nonpayable$_t_address_$_t_uint256_$returns$_t_bool_$",
                          "typeString": "function (address,uint256) external returns (bool)"
                        }
                      },
                      "id": 666,
                      "isConstant": false,
                      "isLValue": false,
                      "isPure": false,
                      "kind": "functionCall",
                      "lValueRequested": false,
                      "names": [],
                      "nodeType": "FunctionCall",
                      "src": "7051:63:0",
                      "tryCall": false,
                      "typeDescriptions": {
                        "typeIdentifier": "t_bool",
                        "typeString": "bool"
                      }
                    },
                    "id": 667,
                    "nodeType": "ExpressionStatement",
                    "src": "7051:63:0"
                  }
                ]
              },
              "documentation": null,
              "functionSelector": "5b3bc4fe",
              "id": 669,
              "implemented": true,
              "kind": "function",
              "modifiers": [],
              "name": "BiswapCall",
              "nodeType": "FunctionDefinition",
              "overrides": null,
              "parameters": {
                "id": 508,
                "nodeType": "ParameterList",
                "parameters": [
                  {
                    "constant": false,
                    "id": 501,
                    "mutability": "mutable",
                    "name": "_sender",
                    "nodeType": "VariableDeclaration",
                    "overrides": null,
                    "scope": 669,
                    "src": "5949:15:0",
                    "stateVariable": false,
                    "storageLocation": "default",
                    "typeDescriptions": {
                      "typeIdentifier": "t_address",
                      "typeString": "address"
                    },
                    "typeName": {
                      "id": 500,
                      "name": "address",
                      "nodeType": "ElementaryTypeName",
                      "src": "5949:7:0",
                      "stateMutability": "nonpayable",
                      "typeDescriptions": {
                        "typeIdentifier": "t_address",
                        "typeString": "address"
                      }
                    },
                    "value": null,
                    "visibility": "internal"
                  },
                  {
                    "constant": false,
                    "id": 503,
                    "mutability": "mutable",
                    "name": "_amount0",
                    "nodeType": "VariableDeclaration",
                    "overrides": null,
                    "scope": 669,
                    "src": "5971:13:0",
                    "stateVariable": false,
                    "storageLocation": "default",
                    "typeDescriptions": {
                      "typeIdentifier": "t_uint256",
                      "typeString": "uint256"
                    },
                    "typeName": {
                      "id": 502,
                      "name": "uint",
                      "nodeType": "ElementaryTypeName",
                      "src": "5971:4:0",
                      "typeDescriptions": {
                        "typeIdentifier": "t_uint256",
                        "typeString": "uint256"
                      }
                    },
                    "value": null,
                    "visibility": "internal"
                  },
                  {
                    "constant": false,
                    "id": 505,
                    "mutability": "mutable",
                    "name": "_amount1",
                    "nodeType": "VariableDeclaration",
                    "overrides": null,
                    "scope": 669,
                    "src": "5991:13:0",
                    "stateVariable": false,
                    "storageLocation": "default",
                    "typeDescriptions": {
                      "typeIdentifier": "t_uint256",
                      "typeString": "uint256"
                    },
                    "typeName": {
                      "id": 504,
                      "name": "uint",
                      "nodeType": "ElementaryTypeName",
                      "src": "5991:4:0",
                      "typeDescriptions": {
                        "typeIdentifier": "t_uint256",
                        "typeString": "uint256"
                      }
                    },
                    "value": null,
                    "visibility": "internal"
                  },
                  {
                    "constant": false,
                    "id": 507,
                    "mutability": "mutable",
                    "name": "_data",
                    "nodeType": "VariableDeclaration",
                    "overrides": null,
                    "scope": 669,
                    "src": "6011:20:0",
                    "stateVariable": false,
                    "storageLocation": "calldata",
                    "typeDescriptions": {
                      "typeIdentifier": "t_bytes_calldata_ptr",
                      "typeString": "bytes"
                    },
                    "typeName": {
                      "id": 506,
                      "name": "bytes",
                      "nodeType": "ElementaryTypeName",
                      "src": "6011:5:0",
                      "typeDescriptions": {
                        "typeIdentifier": "t_bytes_storage_ptr",
                        "typeString": "bytes"
                      }
                    },
                    "value": null,
                    "visibility": "internal"
                  }
                ],
                "src": "5943:92:0"
              },
              "returnParameters": {
                "id": 509,
                "nodeType": "ParameterList",
                "parameters": [],
                "src": "6045:0:0"
              },
              "scope": 670,
              "src": "5924:1195:0",
              "stateMutability": "nonpayable",
              "virtual": false,
              "visibility": "external"
            }
          ],
          "scope": 671,
          "src": "334:9510:0"
        }
      ],
      "src": "32:9812:0"
    },
    "legacyAST": {
      "attributes": {
        "absolutePath": "project:/contracts/Arbitrage.sol",
        "exportedSymbols": {
          "Arbitage": [
            670
          ]
        }
      },
      "children": [
        {
          "attributes": {
            "literals": [
              "solidity",
              "^",
              "0.6",
              ".6"
            ]
          },
          "id": 1,
          "name": "PragmaDirective",
          "src": "32:23:0"
        },
        {
          "attributes": {
            "SourceUnit": 1801,
            "absolutePath": "project:/contracts/SafeMath.sol",
            "file": "./SafeMath.sol",
            "scope": 671,
            "symbolAliases": [
              null
            ],
            "unitAlias": ""
          },
          "id": 2,
          "name": "ImportDirective",
          "src": "95:24:0"
        },
        {
          "attributes": {
            "SourceUnit": 1606,
            "absolutePath": "project:/contracts/Ownable.sol",
            "file": "./Ownable.sol",
            "scope": 671,
            "symbolAliases": [
              null
            ],
            "unitAlias": ""
          },
          "id": 3,
          "name": "ImportDirective",
          "src": "154:23:0"
        },
        {
          "attributes": {
            "SourceUnit": 1076,
            "absolutePath": "project:/contracts/IUniswapV2Pair.sol",
            "file": "./IUniswapV2Pair.sol",
            "scope": 671,
            "symbolAliases": [
              null
            ],
            "unitAlias": ""
          },
          "id": 4,
          "name": "ImportDirective",
          "src": "178:30:0"
        },
        {
          "attributes": {
            "SourceUnit": 834,
            "absolutePath": "project:/contracts/IUniswapV2Factory.sol",
            "file": "./IUniswapV2Factory.sol",
            "scope": 671,
            "symbolAliases": [
              null
            ],
            "unitAlias": ""
          },
          "id": 5,
          "name": "ImportDirective",
          "src": "209:33:0"
        },
        {
          "attributes": {
            "SourceUnit": 1469,
            "absolutePath": "project:/contracts/IUniswapV2Router.sol",
            "file": "./IUniswapV2Router.sol",
            "scope": 671,
            "symbolAliases": [
              null
            ],
            "unitAlias": ""
          },
          "id": 6,
          "name": "ImportDirective",
          "src": "243:32:0"
        },
        {
          "attributes": {
            "SourceUnit": 771,
            "absolutePath": "project:/contracts/IERC20.sol",
            "file": "./IERC20.sol",
            "scope": 671,
            "symbolAliases": [
              null
            ],
            "unitAlias": ""
          },
          "id": 7,
          "name": "ImportDirective",
          "src": "276:22:0"
        },
        {
          "attributes": {
            "SourceUnit": 2273,
            "absolutePath": "project:/contracts/UniswapV2Library.sol",
            "file": "./UniswapV2Library.sol",
            "scope": 671,
            "symbolAliases": [
              null
            ],
            "unitAlias": ""
          },
          "id": 8,
          "name": "ImportDirective",
          "src": "299:32:0"
        },
        {
          "attributes": {
            "abstract": false,
            "contractDependencies": [
              692,
              1605
            ],
            "contractKind": "contract",
            "documentation": null,
            "fullyImplemented": true,
            "linearizedBaseContracts": [
              670,
              1605,
              692
            ],
            "name": "Arbitage",
            "scope": 671
          },
          "children": [
            {
              "attributes": {
                "arguments": null
              },
              "children": [
                {
                  "attributes": {
                    "contractScope": null,
                    "name": "Ownable",
                    "referencedDeclaration": 1605,
                    "type": "contract Ownable"
                  },
                  "id": 9,
                  "name": "UserDefinedTypeName",
                  "src": "355:7:0"
                }
              ],
              "id": 10,
              "name": "InheritanceSpecifier",
              "src": "355:7:0"
            },
            {
              "children": [
                {
                  "attributes": {
                    "contractScope": null,
                    "name": "SafeMath",
                    "referencedDeclaration": 1800,
                    "type": "library SafeMath"
                  },
                  "id": 11,
                  "name": "UserDefinedTypeName",
                  "src": "375:8:0"
                },
                {
                  "attributes": {
                    "name": "uint256",
                    "type": "uint256"
                  },
                  "id": 12,
                  "name": "ElementaryTypeName",
                  "src": "388:7:0"
                }
              ],
              "id": 13,
              "name": "UsingForDirective",
              "src": "369:27:0"
            },
            {
              "attributes": {
                "constant": false,
                "functionSelector": "1694505e",
                "mutability": "mutable",
                "name": "uniswapV2Router",
                "overrides": null,
                "scope": 670,
                "stateVariable": true,
                "storageLocation": "default",
                "type": "contract IUniswapV2Router02",
                "value": null,
                "visibility": "public"
              },
              "children": [
                {
                  "attributes": {
                    "contractScope": null,
                    "name": "IUniswapV2Router02",
                    "referencedDeclaration": 1468,
                    "type": "contract IUniswapV2Router02"
                  },
                  "id": 14,
                  "name": "UserDefinedTypeName",
                  "src": "402:18:0"
                }
              ],
              "id": 15,
              "name": "VariableDeclaration",
              "src": "402:41:0"
            },
            {
              "attributes": {
                "constant": false,
                "functionSelector": "49bd5a5e",
                "mutability": "mutable",
                "name": "uniswapV2Pair",
                "overrides": null,
                "scope": 670,
                "stateVariable": true,
                "storageLocation": "default",
                "type": "address",
                "value": null,
                "visibility": "public"
              },
              "children": [
                {
                  "attributes": {
                    "name": "address",
                    "stateMutability": "nonpayable",
                    "type": "address"
                  },
                  "id": 16,
                  "name": "ElementaryTypeName",
                  "src": "449:7:0"
                }
              ],
              "id": 17,
              "name": "VariableDeclaration",
              "src": "449:29:0"
            },
            {
              "attributes": {
                "constant": false,
                "functionSelector": "c45a0155",
                "mutability": "mutable",
                "name": "factory",
                "overrides": null,
                "scope": 670,
                "stateVariable": true,
                "storageLocation": "default",
                "type": "address",
                "value": null,
                "visibility": "public"
              },
              "children": [
                {
                  "attributes": {
                    "name": "address",
                    "stateMutability": "nonpayable",
                    "type": "address"
                  },
                  "id": 18,
                  "name": "ElementaryTypeName",
                  "src": "489:7:0"
                }
              ],
              "id": 19,
              "name": "VariableDeclaration",
              "src": "489:22:0"
            },
            {
              "attributes": {
                "constant": true,
                "mutability": "constant",
                "name": "deadline",
                "overrides": null,
                "scope": 670,
                "stateVariable": true,
                "storageLocation": "default",
                "type": "uint256",
                "visibility": "internal"
              },
              "children": [
                {
                  "attributes": {
                    "name": "uint",
                    "type": "uint256"
                  },
                  "id": 20,
                  "name": "ElementaryTypeName",
                  "src": "517:4:0"
                },
                {
                  "attributes": {
                    "argumentTypes": null,
                    "hexvalue": "3130",
                    "isConstant": false,
                    "isLValue": false,
                    "isPure": true,
                    "lValueRequested": false,
                    "subdenomination": "days",
                    "token": "number",
                    "type": "int_const 864000",
                    "value": "10"
                  },
                  "id": 21,
                  "name": "Literal",
                  "src": "542:7:0"
                }
              ],
              "id": 22,
              "name": "VariableDeclaration",
              "src": "517:32:0"
            },
            {
              "attributes": {
                "constant": false,
                "functionSelector": "6d13582c",
                "mutability": "mutable",
                "name": "sushiRouter",
                "overrides": null,
                "scope": 670,
                "stateVariable": true,
                "storageLocation": "default",
                "type": "contract IUniswapV2Router02",
                "value": null,
                "visibility": "public"
              },
              "children": [
                {
                  "attributes": {
                    "contractScope": null,
                    "name": "IUniswapV2Router02",
                    "referencedDeclaration": 1468,
                    "type": "contract IUniswapV2Router02"
                  },
                  "id": 23,
                  "name": "UserDefinedTypeName",
                  "src": "555:18:0"
                }
              ],
              "id": 24,
              "name": "VariableDeclaration",
              "src": "555:37:0"
            },
            {
              "attributes": {
                "constant": false,
                "functionSelector": "85141a77",
                "mutability": "mutable",
                "name": "deadWallet",
                "overrides": null,
                "scope": 670,
                "stateVariable": true,
                "storageLocation": "default",
                "type": "address",
                "visibility": "public"
              },
              "children": [
                {
                  "attributes": {
                    "name": "address",
                    "stateMutability": "nonpayable",
                    "type": "address"
                  },
                  "id": 25,
                  "name": "ElementaryTypeName",
                  "src": "604:7:0"
                },
                {
                  "attributes": {
                    "argumentTypes": null,
                    "hexvalue": "307830303030303030303030303030303030303030303030303030303030303030303030303064456144",
                    "isConstant": false,
                    "isLValue": false,
                    "isPure": true,
                    "lValueRequested": false,
                    "subdenomination": null,
                    "token": "number",
                    "type": "address payable",
                    "value": "0x000000000000000000000000000000000000dEaD"
                  },
                  "id": 26,
                  "name": "Literal",
                  "src": "632:42:0"
                }
              ],
              "id": 27,
              "name": "VariableDeclaration",
              "src": "604:70:0"
            },
            {
              "attributes": {
                "constant": false,
                "mutability": "mutable",
                "name": "BUSD",
                "overrides": null,
                "scope": 670,
                "stateVariable": true,
                "storageLocation": "default",
                "type": "address",
                "visibility": "private"
              },
              "children": [
                {
                  "attributes": {
                    "name": "address",
                    "stateMutability": "nonpayable",
                    "type": "address"
                  },
                  "id": 28,
                  "name": "ElementaryTypeName",
                  "src": "685:7:0"
                },
                {
                  "attributes": {
                    "argumentTypes": null,
                    "isConstant": false,
                    "isLValue": false,
                    "isPure": true,
                    "isStructConstructorCall": false,
                    "lValueRequested": false,
                    "names": [
                      null
                    ],
                    "tryCall": false,
                    "type": "address",
                    "type_conversion": true
                  },
                  "children": [
                    {
                      "attributes": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_address_payable",
                            "typeString": "address payable"
                          }
                        ],
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": true,
                        "lValueRequested": false,
                        "type": "type(address)"
                      },
                      "children": [
                        {
                          "attributes": {
                            "name": "address",
                            "type": null
                          },
                          "id": 29,
                          "name": "ElementaryTypeName",
                          "src": "709:7:0"
                        }
                      ],
                      "id": 30,
                      "name": "ElementaryTypeNameExpression",
                      "src": "709:7:0"
                    },
                    {
                      "attributes": {
                        "argumentTypes": null,
                        "hexvalue": "307865396537434541334465646341353938343738304261666335393962443639414464303837443536",
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": true,
                        "lValueRequested": false,
                        "subdenomination": null,
                        "token": "number",
                        "type": "address payable",
                        "value": "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56"
                      },
                      "id": 31,
                      "name": "Literal",
                      "src": "717:42:0"
                    }
                  ],
                  "id": 32,
                  "name": "FunctionCall",
                  "src": "709:51:0"
                }
              ],
              "id": 33,
              "name": "VariableDeclaration",
              "src": "685:75:0"
            },
            {
              "attributes": {
                "constant": false,
                "mutability": "mutable",
                "name": "BETH",
                "overrides": null,
                "scope": 670,
                "stateVariable": true,
                "storageLocation": "default",
                "type": "address",
                "visibility": "private"
              },
              "children": [
                {
                  "attributes": {
                    "name": "address",
                    "stateMutability": "nonpayable",
                    "type": "address"
                  },
                  "id": 34,
                  "name": "ElementaryTypeName",
                  "src": "767:7:0"
                },
                {
                  "attributes": {
                    "argumentTypes": null,
                    "isConstant": false,
                    "isLValue": false,
                    "isPure": true,
                    "isStructConstructorCall": false,
                    "lValueRequested": false,
                    "names": [
                      null
                    ],
                    "tryCall": false,
                    "type": "address",
                    "type_conversion": true
                  },
                  "children": [
                    {
                      "attributes": {
                        "argumentTypes": [
                          {
                            "typeIdentifier": "t_address_payable",
                            "typeString": "address payable"
                          }
                        ],
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": true,
                        "lValueRequested": false,
                        "type": "type(address)"
                      },
                      "children": [
                        {
                          "attributes": {
                            "name": "address",
                            "type": null
                          },
                          "id": 35,
                          "name": "ElementaryTypeName",
                          "src": "791:7:0"
                        }
                      ],
                      "id": 36,
                      "name": "ElementaryTypeNameExpression",
                      "src": "791:7:0"
                    },
                    {
                      "attributes": {
                        "argumentTypes": null,
                        "hexvalue": "307832313730456430383830616339413735356664323942323638383935364244393539463933334638",
                        "isConstant": false,
                        "isLValue": false,
                        "isPure": true,
                        "lValueRequested": false,
                        "subdenomination": null,
                        "token": "number",
                        "type": "address payable",
                        "value": "0x2170Ed0880ac9A755fd29B2688956BD959F933F8"
                      },
                      "id": 37,
                      "name": "Literal",
                      "src": "799:42:0"
                    }
                  ],
                  "id": 38,
                  "name": "FunctionCall",
                  "src": "791:51:0"
                }
              ],
              "id": 39,
              "name": "VariableDeclaration",
              "src": "767:75:0"
            },
            {
              "attributes": {
                "constant": false,
                "functionSelector": "9c60c375",
                "mutability": "mutable",
                "name": "_payoutAddress",
                "overrides": null,
                "scope": 670,
                "stateVariable": true,
                "storageLocation": "default",
                "type": "address",
                "visibility": "public"
              },
              "children": [
                {
                  "attributes": {
                    "name": "address",
                    "stateMutability": "nonpayable",
                    "type": "address"
                  },
                  "id": 40,
                  "name": "ElementaryTypeName",
                  "src": "854:7:0"
                },
                {
                  "attributes": {
                    "argumentTypes": null,
                    "hexvalue": "307837666341313330374532303036466232374333344446393531303532353835626345326131393139",
                    "isConstant": false,
                    "isLValue": false,
                    "isPure": true,
                    "lValueRequested": false,
                    "subdenomination": null,
                    "token": "number",
                    "type": "address payable",
                    "value": "0x7fcA1307E2006Fb27C34DF951052585bcE2a1919"
                  },
                  "id": 41,
                  "name": "Literal",
                  "src": "886:42:0"
                }
              ],
              "id": 42,
              "name": "VariableDeclaration",
              "src": "854:74:0"
            },
            {
              "attributes": {
                "constant": false,
                "functionSelector": "9c1b8af5",
                "mutability": "mutable",
                "name": "gasForProcessing",
                "overrides": null,
                "scope": 670,
                "stateVariable": true,
                "storageLocation": "default",
                "type": "uint256",
                "visibility": "public"
              },
              "children": [
                {
                  "attributes": {
                    "name": "uint256",
                    "type": "uint256"
                  },
                  "id": 43,
                  "name": "ElementaryTypeName",
                  "src": "941:7:0"
                },
                {
                  "attributes": {
                    "argumentTypes": null,
                    "hexvalue": "333030303030",
                    "isConstant": false,
                    "isLValue": false,
                    "isPure": true,
                    "lValueRequested": false,
                    "subdenomination": null,
                    "token": "number",
                    "type": "int_const 300000",
                    "value": "300000"
                  },
                  "id": 44,
                  "name": "Literal",
                  "src": "975:6:0"
                }
              ],
              "id": 45,
              "name": "VariableDeclaration",
              "src": "941:40:0"
            },
            {
              "attributes": {
                "constant": false,
                "mutability": "mutable",
                "name": "_canPayOut",
                "overrides": null,
                "scope": 670,
                "stateVariable": true,
                "storageLocation": "default",
                "type": "mapping(address => bool)",
                "value": null,
                "visibility": "private"
              },
              "children": [
                {
                  "attributes": {
                    "type": "mapping(address => bool)"
                  },
                  "children": [
                    {
                      "attributes": {
                        "name": "address",
                        "type": "address"
                      },
                      "id": 46,
                      "name": "ElementaryTypeName",
                      "src": "1050:7:0"
                    },
                    {
                      "attributes": {
                        "name": "bool",
                        "type": "bool"
                      },
                      "id": 47,
                      "name": "ElementaryTypeName",
                      "src": "1061:4:0"
                    }
                  ],
                  "id": 48,
                  "name": "Mapping",
                  "src": "1041:25:0"
                }
              ],
              "id": 49,
              "name": "VariableDeclaration",
              "src": "1041:44:0"
            },
            {
              "attributes": {
                "anonymous": false,
                "documentation": null,
                "name": "UpdateDividendTracker"
              },
              "children": [
                {
                  "children": [
                    {
                      "attributes": {
                        "constant": false,
                        "indexed": true,
                        "mutability": "mutable",
                        "name": "newAddress",
                        "overrides": null,
                        "scope": 55,
                        "stateVariable": false,
                        "storageLocation": "default",
                        "type": "address",
                        "value": null,
                        "visibility": "internal"
                      },
                      "children": [
                        {
                          "attributes": {
                            "name": "address",
                            "stateMutability": "nonpayable",
                            "type": "address"
                          },
                          "id": 50,
                          "name": "ElementaryTypeName",
                          "src": "1121:7:0"
                        }
                      ],
                      "id": 51,
                      "name": "VariableDeclaration",
                      "src": "1121:26:0"
                    },
                    {
                      "attributes": {
                        "constant": false,
                        "indexed": true,
                        "mutability": "mutable",
                        "name": "oldAddress",
                        "overrides": null,
                        "scope": 55,
                        "stateVariable": false,
                        "storageLocation": "default",
                        "type": "address",
                        "value": null,
                        "visibility": "internal"
                      },
                      "children": [
                        {
                          "attributes": {
                            "name": "address",
                            "stateMutability": "nonpayable",
                            "type": "address"
                          },
                          "id": 52,
                          "name": "ElementaryTypeName",
                          "src": "1149:7:0"
                        }
                      ],
                      "id": 53,
                      "name": "VariableDeclaration",
                      "src": "1149:26:0"
                    }
                  ],
                  "id": 54,
                  "name": "ParameterList",
                  "src": "1120:56:0"
                }
              ],
              "id": 55,
              "name": "EventDefinition",
              "src": "1093:84:0"
            },
            {
              "attributes": {
                "anonymous": false,
                "documentation": null,
                "name": "IncludeCanPayOut"
              },
              "children": [
                {
                  "children": [
                    {
                      "attributes": {
                        "constant": false,
                        "indexed": true,
                        "mutability": "mutable",
                        "name": "account",
                        "overrides": null,
                        "scope": 61,
                        "stateVariable": false,
                        "storageLocation": "default",
                        "type": "address",
                        "value": null,
                        "visibility": "internal"
                      },
                      "children": [
                        {
                          "attributes": {
                            "name": "address",
                            "stateMutability": "nonpayable",
                            "type": "address"
                          },
                          "id": 56,
                          "name": "ElementaryTypeName",
                          "src": "1205:7:0"
                        }
                      ],
                      "id": 57,
                      "name": "VariableDeclaration",
                      "src": "1205:23:0"
                    },
                    {
                      "attributes": {
                        "constant": false,
                        "indexed": false,
                        "mutability": "mutable",
                        "name": "isExcluded",
                        "overrides": null,
                        "scope": 61,
                        "stateVariable": false,
                        "storageLocation": "default",
                        "type": "bool",
                        "value": null,
                        "visibility": "internal"
                      },
                      "children": [
                        {
                          "attributes": {
                            "name": "bool",
                            "type": "bool"
                          },
                          "id": 58,
                          "name": "ElementaryTypeName",
                          "src": "1230:4:0"
                        }
                      ],
                      "id": 59,
                      "name": "VariableDeclaration",
                      "src": "1230:15:0"
                    }
                  ],
                  "id": 60,
                  "name": "ParameterList",
                  "src": "1204:42:0"
                }
              ],
              "id": 61,
              "name": "EventDefinition",
              "src": "1182:65:0"
            },
            {
              "attributes": {
                "documentation": null,
                "implemented": true,
                "isConstructor": true,
                "kind": "constructor",
                "modifiers": [
                  null
                ],
                "name": "",
                "overrides": null,
                "scope": 670,
                "stateMutability": "nonpayable",
                "virtual": false,
                "visibility": "public"
              },
              "children": [
                {
                  "attributes": {
                    "parameters": [
                      null
                    ]
                  },
                  "children": [],
                  "id": 62,
                  "name": "ParameterList",
                  "src": "1266:2:0"
                },
                {
                  "attributes": {
                    "parameters": [
                      null
                    ]
                  },
                  "children": [],
                  "id": 63,
                  "name": "ParameterList",
                  "src": "1276:0:0"
                },
                {
                  "children": [
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "tuple()",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_address",
                                    "typeString": "address"
                                  },
                                  {
                                    "typeIdentifier": "t_bool",
                                    "typeString": "bool"
                                  }
                                ],
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 110,
                                "type": "function (address,bool)",
                                "value": "includeCanPayOut"
                              },
                              "id": 64,
                              "name": "Identifier",
                              "src": "1934:16:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "arguments": [
                                  null
                                ],
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "isStructConstructorCall": false,
                                "lValueRequested": false,
                                "names": [
                                  null
                                ],
                                "tryCall": false,
                                "type": "address",
                                "type_conversion": false
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": [
                                      null
                                    ],
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 1534,
                                    "type": "function () view returns (address)",
                                    "value": "owner"
                                  },
                                  "id": 65,
                                  "name": "Identifier",
                                  "src": "1951:5:0"
                                }
                              ],
                              "id": 66,
                              "name": "FunctionCall",
                              "src": "1951:7:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "hexvalue": "74727565",
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": true,
                                "lValueRequested": false,
                                "subdenomination": null,
                                "token": "bool",
                                "type": "bool",
                                "value": "true"
                              },
                              "id": 67,
                              "name": "Literal",
                              "src": "1960:4:0"
                            }
                          ],
                          "id": 68,
                          "name": "FunctionCall",
                          "src": "1934:31:0"
                        }
                      ],
                      "id": 69,
                      "name": "ExpressionStatement",
                      "src": "1934:31:0"
                    },
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "tuple()",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_address",
                                    "typeString": "address"
                                  },
                                  {
                                    "typeIdentifier": "t_bool",
                                    "typeString": "bool"
                                  }
                                ],
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 110,
                                "type": "function (address,bool)",
                                "value": "includeCanPayOut"
                              },
                              "id": 70,
                              "name": "Identifier",
                              "src": "1975:16:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 42,
                                "type": "address",
                                "value": "_payoutAddress"
                              },
                              "id": 71,
                              "name": "Identifier",
                              "src": "1992:14:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "hexvalue": "74727565",
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": true,
                                "lValueRequested": false,
                                "subdenomination": null,
                                "token": "bool",
                                "type": "bool",
                                "value": "true"
                              },
                              "id": 72,
                              "name": "Literal",
                              "src": "2008:4:0"
                            }
                          ],
                          "id": 73,
                          "name": "FunctionCall",
                          "src": "1975:38:0"
                        }
                      ],
                      "id": 74,
                      "name": "ExpressionStatement",
                      "src": "1975:38:0"
                    }
                  ],
                  "id": 75,
                  "name": "Block",
                  "src": "1276:1154:0"
                }
              ],
              "id": 76,
              "name": "FunctionDefinition",
              "src": "1255:1175:0"
            },
            {
              "attributes": {
                "documentation": null,
                "implemented": true,
                "isConstructor": false,
                "kind": "receive",
                "modifiers": [
                  null
                ],
                "name": "",
                "overrides": null,
                "scope": 670,
                "stateMutability": "payable",
                "virtual": false,
                "visibility": "external"
              },
              "children": [
                {
                  "attributes": {
                    "parameters": [
                      null
                    ]
                  },
                  "children": [],
                  "id": 77,
                  "name": "ParameterList",
                  "src": "2443:2:0"
                },
                {
                  "attributes": {
                    "parameters": [
                      null
                    ]
                  },
                  "children": [],
                  "id": 78,
                  "name": "ParameterList",
                  "src": "2463:0:0"
                },
                {
                  "attributes": {
                    "statements": [
                      null
                    ]
                  },
                  "children": [],
                  "id": 79,
                  "name": "Block",
                  "src": "2463:7:0"
                }
              ],
              "id": 80,
              "name": "FunctionDefinition",
              "src": "2436:34:0"
            },
            {
              "attributes": {
                "documentation": null,
                "functionSelector": "ee652fc5",
                "implemented": true,
                "isConstructor": false,
                "kind": "function",
                "name": "includeCanPayOut",
                "overrides": null,
                "scope": 670,
                "stateMutability": "nonpayable",
                "virtual": false,
                "visibility": "public"
              },
              "children": [
                {
                  "children": [
                    {
                      "attributes": {
                        "constant": false,
                        "mutability": "mutable",
                        "name": "account",
                        "overrides": null,
                        "scope": 110,
                        "stateVariable": false,
                        "storageLocation": "default",
                        "type": "address",
                        "value": null,
                        "visibility": "internal"
                      },
                      "children": [
                        {
                          "attributes": {
                            "name": "address",
                            "stateMutability": "nonpayable",
                            "type": "address"
                          },
                          "id": 81,
                          "name": "ElementaryTypeName",
                          "src": "2506:7:0"
                        }
                      ],
                      "id": 82,
                      "name": "VariableDeclaration",
                      "src": "2506:15:0"
                    },
                    {
                      "attributes": {
                        "constant": false,
                        "mutability": "mutable",
                        "name": "included",
                        "overrides": null,
                        "scope": 110,
                        "stateVariable": false,
                        "storageLocation": "default",
                        "type": "bool",
                        "value": null,
                        "visibility": "internal"
                      },
                      "children": [
                        {
                          "attributes": {
                            "name": "bool",
                            "type": "bool"
                          },
                          "id": 83,
                          "name": "ElementaryTypeName",
                          "src": "2523:4:0"
                        }
                      ],
                      "id": 84,
                      "name": "VariableDeclaration",
                      "src": "2523:13:0"
                    }
                  ],
                  "id": 85,
                  "name": "ParameterList",
                  "src": "2505:32:0"
                },
                {
                  "attributes": {
                    "parameters": [
                      null
                    ]
                  },
                  "children": [],
                  "id": 88,
                  "name": "ParameterList",
                  "src": "2555:0:0"
                },
                {
                  "attributes": {
                    "arguments": null
                  },
                  "children": [
                    {
                      "attributes": {
                        "argumentTypes": null,
                        "overloadedDeclarations": [
                          null
                        ],
                        "referencedDeclaration": 1548,
                        "type": "modifier ()",
                        "value": "onlyOwner"
                      },
                      "id": 86,
                      "name": "Identifier",
                      "src": "2545:9:0"
                    }
                  ],
                  "id": 87,
                  "name": "ModifierInvocation",
                  "src": "2545:9:0"
                },
                {
                  "children": [
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "tuple()",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_bool",
                                    "typeString": "bool"
                                  },
                                  {
                                    "typeIdentifier": "t_stringliteral_15a6e759dbdb558bd1713608c9f30f7123a0595119f09b6d5e1c90ac5235ac9c",
                                    "typeString": "literal_string \"Account is already the value of 'included'\""
                                  }
                                ],
                                "overloadedDeclarations": [
                                  -18,
                                  -18
                                ],
                                "referencedDeclaration": -18,
                                "type": "function (bool,string memory) pure",
                                "value": "require"
                              },
                              "id": 89,
                              "name": "Identifier",
                              "src": "2565:7:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "commonType": {
                                  "typeIdentifier": "t_bool",
                                  "typeString": "bool"
                                },
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "operator": "!=",
                                "type": "bool"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "isConstant": false,
                                    "isLValue": true,
                                    "isPure": false,
                                    "lValueRequested": false,
                                    "type": "bool"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 49,
                                        "type": "mapping(address => bool)",
                                        "value": "_canPayOut"
                                      },
                                      "id": 90,
                                      "name": "Identifier",
                                      "src": "2573:10:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 82,
                                        "type": "address",
                                        "value": "account"
                                      },
                                      "id": 91,
                                      "name": "Identifier",
                                      "src": "2584:7:0"
                                    }
                                  ],
                                  "id": 92,
                                  "name": "IndexAccess",
                                  "src": "2573:19:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 84,
                                    "type": "bool",
                                    "value": "included"
                                  },
                                  "id": 93,
                                  "name": "Identifier",
                                  "src": "2596:8:0"
                                }
                              ],
                              "id": 94,
                              "name": "BinaryOperation",
                              "src": "2573:31:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "hexvalue": "4163636f756e7420697320616c7265616479207468652076616c7565206f662027696e636c7564656427",
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": true,
                                "lValueRequested": false,
                                "subdenomination": null,
                                "token": "string",
                                "type": "literal_string \"Account is already the value of 'included'\"",
                                "value": "Account is already the value of 'included'"
                              },
                              "id": 95,
                              "name": "Literal",
                              "src": "2606:44:0"
                            }
                          ],
                          "id": 96,
                          "name": "FunctionCall",
                          "src": "2565:86:0"
                        }
                      ],
                      "id": 97,
                      "name": "ExpressionStatement",
                      "src": "2565:86:0"
                    },
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "lValueRequested": false,
                            "operator": "=",
                            "type": "bool"
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": true,
                                "isPure": false,
                                "lValueRequested": true,
                                "type": "bool"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 49,
                                    "type": "mapping(address => bool)",
                                    "value": "_canPayOut"
                                  },
                                  "id": 98,
                                  "name": "Identifier",
                                  "src": "2661:10:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 82,
                                    "type": "address",
                                    "value": "account"
                                  },
                                  "id": 99,
                                  "name": "Identifier",
                                  "src": "2672:7:0"
                                }
                              ],
                              "id": 100,
                              "name": "IndexAccess",
                              "src": "2661:19:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 84,
                                "type": "bool",
                                "value": "included"
                              },
                              "id": 101,
                              "name": "Identifier",
                              "src": "2683:8:0"
                            }
                          ],
                          "id": 102,
                          "name": "Assignment",
                          "src": "2661:30:0"
                        }
                      ],
                      "id": 103,
                      "name": "ExpressionStatement",
                      "src": "2661:30:0"
                    },
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "tuple()",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_address",
                                    "typeString": "address"
                                  },
                                  {
                                    "typeIdentifier": "t_bool",
                                    "typeString": "bool"
                                  }
                                ],
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 61,
                                "type": "function (address,bool)",
                                "value": "IncludeCanPayOut"
                              },
                              "id": 104,
                              "name": "Identifier",
                              "src": "2707:16:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 82,
                                "type": "address",
                                "value": "account"
                              },
                              "id": 105,
                              "name": "Identifier",
                              "src": "2724:7:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 84,
                                "type": "bool",
                                "value": "included"
                              },
                              "id": 106,
                              "name": "Identifier",
                              "src": "2733:8:0"
                            }
                          ],
                          "id": 107,
                          "name": "FunctionCall",
                          "src": "2707:35:0"
                        }
                      ],
                      "id": 108,
                      "name": "EmitStatement",
                      "src": "2702:40:0"
                    }
                  ],
                  "id": 109,
                  "name": "Block",
                  "src": "2555:194:0"
                }
              ],
              "id": 110,
              "name": "FunctionDefinition",
              "src": "2480:269:0"
            },
            {
              "attributes": {
                "documentation": null,
                "functionSelector": "08427593",
                "implemented": true,
                "isConstructor": false,
                "kind": "function",
                "modifiers": [
                  null
                ],
                "name": "payOutFunds",
                "overrides": null,
                "scope": 670,
                "stateMutability": "nonpayable",
                "virtual": false,
                "visibility": "public"
              },
              "children": [
                {
                  "children": [
                    {
                      "attributes": {
                        "constant": false,
                        "mutability": "mutable",
                        "name": "tokenAddress",
                        "overrides": null,
                        "scope": 148,
                        "stateVariable": false,
                        "storageLocation": "default",
                        "type": "address",
                        "value": null,
                        "visibility": "internal"
                      },
                      "children": [
                        {
                          "attributes": {
                            "name": "address",
                            "stateMutability": "nonpayable",
                            "type": "address"
                          },
                          "id": 111,
                          "name": "ElementaryTypeName",
                          "src": "2780:7:0"
                        }
                      ],
                      "id": 112,
                      "name": "VariableDeclaration",
                      "src": "2780:20:0"
                    },
                    {
                      "attributes": {
                        "constant": false,
                        "mutability": "mutable",
                        "name": "amount",
                        "overrides": null,
                        "scope": 148,
                        "stateVariable": false,
                        "storageLocation": "default",
                        "type": "uint256",
                        "value": null,
                        "visibility": "internal"
                      },
                      "children": [
                        {
                          "attributes": {
                            "name": "uint256",
                            "type": "uint256"
                          },
                          "id": 113,
                          "name": "ElementaryTypeName",
                          "src": "2802:7:0"
                        }
                      ],
                      "id": 114,
                      "name": "VariableDeclaration",
                      "src": "2802:14:0"
                    }
                  ],
                  "id": 115,
                  "name": "ParameterList",
                  "src": "2779:38:0"
                },
                {
                  "attributes": {
                    "parameters": [
                      null
                    ]
                  },
                  "children": [],
                  "id": 116,
                  "name": "ParameterList",
                  "src": "2825:0:0"
                },
                {
                  "children": [
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "tuple()",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_bool",
                                    "typeString": "bool"
                                  },
                                  {
                                    "typeIdentifier": "t_stringliteral_a8a30372c51ebb568444a91ceff1cb5f964f572ba86793e21c1a9243e19e1e9b",
                                    "typeString": "literal_string \"Not able to do that Bro!\""
                                  }
                                ],
                                "overloadedDeclarations": [
                                  -18,
                                  -18
                                ],
                                "referencedDeclaration": -18,
                                "type": "function (bool,string memory) pure",
                                "value": "require"
                              },
                              "id": 117,
                              "name": "Identifier",
                              "src": "2835:7:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": true,
                                "isPure": false,
                                "lValueRequested": false,
                                "type": "bool"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 49,
                                    "type": "mapping(address => bool)",
                                    "value": "_canPayOut"
                                  },
                                  "id": 118,
                                  "name": "Identifier",
                                  "src": "2843:10:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "lValueRequested": false,
                                    "member_name": "sender",
                                    "referencedDeclaration": null,
                                    "type": "address payable"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": -15,
                                        "type": "msg",
                                        "value": "msg"
                                      },
                                      "id": 119,
                                      "name": "Identifier",
                                      "src": "2854:3:0"
                                    }
                                  ],
                                  "id": 120,
                                  "name": "MemberAccess",
                                  "src": "2854:10:0"
                                }
                              ],
                              "id": 121,
                              "name": "IndexAccess",
                              "src": "2843:22:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "hexvalue": "4e6f742061626c6520746f20646f20746861742042726f21",
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": true,
                                "lValueRequested": false,
                                "subdenomination": null,
                                "token": "string",
                                "type": "literal_string \"Not able to do that Bro!\"",
                                "value": "Not able to do that Bro!"
                              },
                              "id": 122,
                              "name": "Literal",
                              "src": "2867:26:0"
                            }
                          ],
                          "id": 123,
                          "name": "FunctionCall",
                          "src": "2835:59:0"
                        }
                      ],
                      "id": 124,
                      "name": "ExpressionStatement",
                      "src": "2835:59:0"
                    },
                    {
                      "attributes": {
                        "assignments": [
                          126
                        ]
                      },
                      "children": [
                        {
                          "attributes": {
                            "constant": false,
                            "mutability": "mutable",
                            "name": "currentBalance",
                            "overrides": null,
                            "scope": 147,
                            "stateVariable": false,
                            "storageLocation": "default",
                            "type": "uint256",
                            "value": null,
                            "visibility": "internal"
                          },
                          "children": [
                            {
                              "attributes": {
                                "name": "uint256",
                                "type": "uint256"
                              },
                              "id": 125,
                              "name": "ElementaryTypeName",
                              "src": "2904:7:0"
                            }
                          ],
                          "id": 126,
                          "name": "VariableDeclaration",
                          "src": "2904:22:0"
                        },
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "uint256",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_address",
                                    "typeString": "address"
                                  }
                                ],
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 255,
                                "type": "function (address) view returns (uint256)",
                                "value": "returnCurrentBalanceOf"
                              },
                              "id": 127,
                              "name": "Identifier",
                              "src": "2929:22:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 112,
                                "type": "address",
                                "value": "tokenAddress"
                              },
                              "id": 128,
                              "name": "Identifier",
                              "src": "2952:12:0"
                            }
                          ],
                          "id": 129,
                          "name": "FunctionCall",
                          "src": "2929:36:0"
                        }
                      ],
                      "id": 130,
                      "name": "VariableDeclarationStatement",
                      "src": "2904:61:0"
                    },
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "tuple()",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_bool",
                                    "typeString": "bool"
                                  },
                                  {
                                    "typeIdentifier": "t_stringliteral_a3ea578da6a19d0e8764eab2aaca56d4c0c702c203487eec22f39e7ff5735258",
                                    "typeString": "literal_string \"Amount is too high!\""
                                  }
                                ],
                                "overloadedDeclarations": [
                                  -18,
                                  -18
                                ],
                                "referencedDeclaration": -18,
                                "type": "function (bool,string memory) pure",
                                "value": "require"
                              },
                              "id": 131,
                              "name": "Identifier",
                              "src": "2975:7:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "commonType": {
                                  "typeIdentifier": "t_uint256",
                                  "typeString": "uint256"
                                },
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "operator": "<=",
                                "type": "bool"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 114,
                                    "type": "uint256",
                                    "value": "amount"
                                  },
                                  "id": 132,
                                  "name": "Identifier",
                                  "src": "2983:6:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 126,
                                    "type": "uint256",
                                    "value": "currentBalance"
                                  },
                                  "id": 133,
                                  "name": "Identifier",
                                  "src": "2993:14:0"
                                }
                              ],
                              "id": 134,
                              "name": "BinaryOperation",
                              "src": "2983:24:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "hexvalue": "416d6f756e7420697320746f6f206869676821",
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": true,
                                "lValueRequested": false,
                                "subdenomination": null,
                                "token": "string",
                                "type": "literal_string \"Amount is too high!\"",
                                "value": "Amount is too high!"
                              },
                              "id": 135,
                              "name": "Literal",
                              "src": "3009:21:0"
                            }
                          ],
                          "id": 136,
                          "name": "FunctionCall",
                          "src": "2975:56:0"
                        }
                      ],
                      "id": 137,
                      "name": "ExpressionStatement",
                      "src": "2975:56:0"
                    },
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "bool",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_address_payable",
                                    "typeString": "address payable"
                                  },
                                  {
                                    "typeIdentifier": "t_uint256",
                                    "typeString": "uint256"
                                  }
                                ],
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "member_name": "transfer",
                                "referencedDeclaration": 719,
                                "type": "function (address,uint256) external returns (bool)"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "isStructConstructorCall": false,
                                    "lValueRequested": false,
                                    "names": [
                                      null
                                    ],
                                    "tryCall": false,
                                    "type": "contract IERC20",
                                    "type_conversion": true
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": [
                                          {
                                            "typeIdentifier": "t_address",
                                            "typeString": "address"
                                          }
                                        ],
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 770,
                                        "type": "type(contract IERC20)",
                                        "value": "IERC20"
                                      },
                                      "id": 138,
                                      "name": "Identifier",
                                      "src": "3041:6:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 112,
                                        "type": "address",
                                        "value": "tokenAddress"
                                      },
                                      "id": 139,
                                      "name": "Identifier",
                                      "src": "3048:12:0"
                                    }
                                  ],
                                  "id": 140,
                                  "name": "FunctionCall",
                                  "src": "3041:20:0"
                                }
                              ],
                              "id": 141,
                              "name": "MemberAccess",
                              "src": "3041:29:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "member_name": "sender",
                                "referencedDeclaration": null,
                                "type": "address payable"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": -15,
                                    "type": "msg",
                                    "value": "msg"
                                  },
                                  "id": 142,
                                  "name": "Identifier",
                                  "src": "3071:3:0"
                                }
                              ],
                              "id": 143,
                              "name": "MemberAccess",
                              "src": "3071:10:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 114,
                                "type": "uint256",
                                "value": "amount"
                              },
                              "id": 144,
                              "name": "Identifier",
                              "src": "3083:6:0"
                            }
                          ],
                          "id": 145,
                          "name": "FunctionCall",
                          "src": "3041:49:0"
                        }
                      ],
                      "id": 146,
                      "name": "ExpressionStatement",
                      "src": "3041:49:0"
                    }
                  ],
                  "id": 147,
                  "name": "Block",
                  "src": "2825:281:0"
                }
              ],
              "id": 148,
              "name": "FunctionDefinition",
              "src": "2759:347:0"
            },
            {
              "attributes": {
                "documentation": null,
                "functionSelector": "be11e0c1",
                "implemented": true,
                "isConstructor": false,
                "kind": "function",
                "modifiers": [
                  null
                ],
                "name": "payOutAllFunds",
                "overrides": null,
                "scope": 670,
                "stateMutability": "nonpayable",
                "virtual": false,
                "visibility": "public"
              },
              "children": [
                {
                  "children": [
                    {
                      "attributes": {
                        "constant": false,
                        "mutability": "mutable",
                        "name": "tokenAddress",
                        "overrides": null,
                        "scope": 177,
                        "stateVariable": false,
                        "storageLocation": "default",
                        "type": "address",
                        "value": null,
                        "visibility": "internal"
                      },
                      "children": [
                        {
                          "attributes": {
                            "name": "address",
                            "stateMutability": "nonpayable",
                            "type": "address"
                          },
                          "id": 149,
                          "name": "ElementaryTypeName",
                          "src": "3135:7:0"
                        }
                      ],
                      "id": 150,
                      "name": "VariableDeclaration",
                      "src": "3135:20:0"
                    }
                  ],
                  "id": 151,
                  "name": "ParameterList",
                  "src": "3134:22:0"
                },
                {
                  "attributes": {
                    "parameters": [
                      null
                    ]
                  },
                  "children": [],
                  "id": 152,
                  "name": "ParameterList",
                  "src": "3164:0:0"
                },
                {
                  "children": [
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "tuple()",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_bool",
                                    "typeString": "bool"
                                  },
                                  {
                                    "typeIdentifier": "t_stringliteral_a8a30372c51ebb568444a91ceff1cb5f964f572ba86793e21c1a9243e19e1e9b",
                                    "typeString": "literal_string \"Not able to do that Bro!\""
                                  }
                                ],
                                "overloadedDeclarations": [
                                  -18,
                                  -18
                                ],
                                "referencedDeclaration": -18,
                                "type": "function (bool,string memory) pure",
                                "value": "require"
                              },
                              "id": 153,
                              "name": "Identifier",
                              "src": "3174:7:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": true,
                                "isPure": false,
                                "lValueRequested": false,
                                "type": "bool"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 49,
                                    "type": "mapping(address => bool)",
                                    "value": "_canPayOut"
                                  },
                                  "id": 154,
                                  "name": "Identifier",
                                  "src": "3182:10:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "lValueRequested": false,
                                    "member_name": "sender",
                                    "referencedDeclaration": null,
                                    "type": "address payable"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": -15,
                                        "type": "msg",
                                        "value": "msg"
                                      },
                                      "id": 155,
                                      "name": "Identifier",
                                      "src": "3193:3:0"
                                    }
                                  ],
                                  "id": 156,
                                  "name": "MemberAccess",
                                  "src": "3193:10:0"
                                }
                              ],
                              "id": 157,
                              "name": "IndexAccess",
                              "src": "3182:22:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "hexvalue": "4e6f742061626c6520746f20646f20746861742042726f21",
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": true,
                                "lValueRequested": false,
                                "subdenomination": null,
                                "token": "string",
                                "type": "literal_string \"Not able to do that Bro!\"",
                                "value": "Not able to do that Bro!"
                              },
                              "id": 158,
                              "name": "Literal",
                              "src": "3206:26:0"
                            }
                          ],
                          "id": 159,
                          "name": "FunctionCall",
                          "src": "3174:59:0"
                        }
                      ],
                      "id": 160,
                      "name": "ExpressionStatement",
                      "src": "3174:59:0"
                    },
                    {
                      "attributes": {
                        "assignments": [
                          162
                        ]
                      },
                      "children": [
                        {
                          "attributes": {
                            "constant": false,
                            "mutability": "mutable",
                            "name": "currentBalance",
                            "overrides": null,
                            "scope": 176,
                            "stateVariable": false,
                            "storageLocation": "default",
                            "type": "uint256",
                            "value": null,
                            "visibility": "internal"
                          },
                          "children": [
                            {
                              "attributes": {
                                "name": "uint256",
                                "type": "uint256"
                              },
                              "id": 161,
                              "name": "ElementaryTypeName",
                              "src": "3243:7:0"
                            }
                          ],
                          "id": 162,
                          "name": "VariableDeclaration",
                          "src": "3243:22:0"
                        },
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "uint256",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_address",
                                    "typeString": "address"
                                  }
                                ],
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 255,
                                "type": "function (address) view returns (uint256)",
                                "value": "returnCurrentBalanceOf"
                              },
                              "id": 163,
                              "name": "Identifier",
                              "src": "3268:22:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 150,
                                "type": "address",
                                "value": "tokenAddress"
                              },
                              "id": 164,
                              "name": "Identifier",
                              "src": "3291:12:0"
                            }
                          ],
                          "id": 165,
                          "name": "FunctionCall",
                          "src": "3268:36:0"
                        }
                      ],
                      "id": 166,
                      "name": "VariableDeclarationStatement",
                      "src": "3243:61:0"
                    },
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "bool",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_address_payable",
                                    "typeString": "address payable"
                                  },
                                  {
                                    "typeIdentifier": "t_uint256",
                                    "typeString": "uint256"
                                  }
                                ],
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "member_name": "transfer",
                                "referencedDeclaration": 719,
                                "type": "function (address,uint256) external returns (bool)"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "isStructConstructorCall": false,
                                    "lValueRequested": false,
                                    "names": [
                                      null
                                    ],
                                    "tryCall": false,
                                    "type": "contract IERC20",
                                    "type_conversion": true
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": [
                                          {
                                            "typeIdentifier": "t_address",
                                            "typeString": "address"
                                          }
                                        ],
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 770,
                                        "type": "type(contract IERC20)",
                                        "value": "IERC20"
                                      },
                                      "id": 167,
                                      "name": "Identifier",
                                      "src": "3314:6:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 150,
                                        "type": "address",
                                        "value": "tokenAddress"
                                      },
                                      "id": 168,
                                      "name": "Identifier",
                                      "src": "3321:12:0"
                                    }
                                  ],
                                  "id": 169,
                                  "name": "FunctionCall",
                                  "src": "3314:20:0"
                                }
                              ],
                              "id": 170,
                              "name": "MemberAccess",
                              "src": "3314:29:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "member_name": "sender",
                                "referencedDeclaration": null,
                                "type": "address payable"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": -15,
                                    "type": "msg",
                                    "value": "msg"
                                  },
                                  "id": 171,
                                  "name": "Identifier",
                                  "src": "3344:3:0"
                                }
                              ],
                              "id": 172,
                              "name": "MemberAccess",
                              "src": "3344:10:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 162,
                                "type": "uint256",
                                "value": "currentBalance"
                              },
                              "id": 173,
                              "name": "Identifier",
                              "src": "3356:14:0"
                            }
                          ],
                          "id": 174,
                          "name": "FunctionCall",
                          "src": "3314:57:0"
                        }
                      ],
                      "id": 175,
                      "name": "ExpressionStatement",
                      "src": "3314:57:0"
                    }
                  ],
                  "id": 176,
                  "name": "Block",
                  "src": "3164:223:0"
                }
              ],
              "id": 177,
              "name": "FunctionDefinition",
              "src": "3111:276:0"
            },
            {
              "attributes": {
                "documentation": null,
                "functionSelector": "957ca639",
                "implemented": true,
                "isConstructor": false,
                "kind": "function",
                "modifiers": [
                  null
                ],
                "name": "payOutAllBNBFunds",
                "overrides": null,
                "scope": 670,
                "stateMutability": "nonpayable",
                "virtual": false,
                "visibility": "public"
              },
              "children": [
                {
                  "attributes": {
                    "parameters": [
                      null
                    ]
                  },
                  "children": [],
                  "id": 178,
                  "name": "ParameterList",
                  "src": "3419:2:0"
                },
                {
                  "attributes": {
                    "parameters": [
                      null
                    ]
                  },
                  "children": [],
                  "id": 179,
                  "name": "ParameterList",
                  "src": "3429:0:0"
                },
                {
                  "children": [
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "tuple()",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_bool",
                                    "typeString": "bool"
                                  },
                                  {
                                    "typeIdentifier": "t_stringliteral_a8a30372c51ebb568444a91ceff1cb5f964f572ba86793e21c1a9243e19e1e9b",
                                    "typeString": "literal_string \"Not able to do that Bro!\""
                                  }
                                ],
                                "overloadedDeclarations": [
                                  -18,
                                  -18
                                ],
                                "referencedDeclaration": -18,
                                "type": "function (bool,string memory) pure",
                                "value": "require"
                              },
                              "id": 180,
                              "name": "Identifier",
                              "src": "3439:7:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": true,
                                "isPure": false,
                                "lValueRequested": false,
                                "type": "bool"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 49,
                                    "type": "mapping(address => bool)",
                                    "value": "_canPayOut"
                                  },
                                  "id": 181,
                                  "name": "Identifier",
                                  "src": "3447:10:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "lValueRequested": false,
                                    "member_name": "sender",
                                    "referencedDeclaration": null,
                                    "type": "address payable"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": -15,
                                        "type": "msg",
                                        "value": "msg"
                                      },
                                      "id": 182,
                                      "name": "Identifier",
                                      "src": "3458:3:0"
                                    }
                                  ],
                                  "id": 183,
                                  "name": "MemberAccess",
                                  "src": "3458:10:0"
                                }
                              ],
                              "id": 184,
                              "name": "IndexAccess",
                              "src": "3447:22:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "hexvalue": "4e6f742061626c6520746f20646f20746861742042726f21",
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": true,
                                "lValueRequested": false,
                                "subdenomination": null,
                                "token": "string",
                                "type": "literal_string \"Not able to do that Bro!\"",
                                "value": "Not able to do that Bro!"
                              },
                              "id": 185,
                              "name": "Literal",
                              "src": "3471:26:0"
                            }
                          ],
                          "id": 186,
                          "name": "FunctionCall",
                          "src": "3439:59:0"
                        }
                      ],
                      "id": 187,
                      "name": "ExpressionStatement",
                      "src": "3439:59:0"
                    },
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "tuple()",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_uint256",
                                    "typeString": "uint256"
                                  }
                                ],
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "member_name": "transfer",
                                "referencedDeclaration": null,
                                "type": "function (uint256)"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "isStructConstructorCall": false,
                                    "lValueRequested": false,
                                    "names": [
                                      null
                                    ],
                                    "tryCall": false,
                                    "type": "address payable",
                                    "type_conversion": true
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": [
                                          {
                                            "typeIdentifier": "t_address_payable",
                                            "typeString": "address payable"
                                          }
                                        ],
                                        "isConstant": false,
                                        "isLValue": false,
                                        "isPure": true,
                                        "lValueRequested": false,
                                        "type": "type(address payable)"
                                      },
                                      "children": [
                                        {
                                          "attributes": {
                                            "name": "address",
                                            "stateMutability": "payable",
                                            "type": null
                                          },
                                          "id": 188,
                                          "name": "ElementaryTypeName",
                                          "src": "3508:8:0"
                                        }
                                      ],
                                      "id": 189,
                                      "name": "ElementaryTypeNameExpression",
                                      "src": "3508:8:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "isConstant": false,
                                        "isLValue": false,
                                        "isPure": false,
                                        "lValueRequested": false,
                                        "member_name": "sender",
                                        "referencedDeclaration": null,
                                        "type": "address payable"
                                      },
                                      "children": [
                                        {
                                          "attributes": {
                                            "argumentTypes": null,
                                            "overloadedDeclarations": [
                                              null
                                            ],
                                            "referencedDeclaration": -15,
                                            "type": "msg",
                                            "value": "msg"
                                          },
                                          "id": 190,
                                          "name": "Identifier",
                                          "src": "3516:3:0"
                                        }
                                      ],
                                      "id": 191,
                                      "name": "MemberAccess",
                                      "src": "3516:10:0"
                                    }
                                  ],
                                  "id": 192,
                                  "name": "FunctionCall",
                                  "src": "3508:19:0"
                                }
                              ],
                              "id": 193,
                              "name": "MemberAccess",
                              "src": "3508:28:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "member_name": "balance",
                                "referencedDeclaration": null,
                                "type": "uint256"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "isStructConstructorCall": false,
                                    "lValueRequested": false,
                                    "names": [
                                      null
                                    ],
                                    "tryCall": false,
                                    "type": "address payable",
                                    "type_conversion": true
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": [
                                          {
                                            "typeIdentifier": "t_contract$_Arbitage_$670",
                                            "typeString": "contract Arbitage"
                                          }
                                        ],
                                        "isConstant": false,
                                        "isLValue": false,
                                        "isPure": true,
                                        "lValueRequested": false,
                                        "type": "type(address)"
                                      },
                                      "children": [
                                        {
                                          "attributes": {
                                            "name": "address",
                                            "type": null
                                          },
                                          "id": 194,
                                          "name": "ElementaryTypeName",
                                          "src": "3537:7:0"
                                        }
                                      ],
                                      "id": 195,
                                      "name": "ElementaryTypeNameExpression",
                                      "src": "3537:7:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": -28,
                                        "type": "contract Arbitage",
                                        "value": "this"
                                      },
                                      "id": 196,
                                      "name": "Identifier",
                                      "src": "3545:4:0"
                                    }
                                  ],
                                  "id": 197,
                                  "name": "FunctionCall",
                                  "src": "3537:13:0"
                                }
                              ],
                              "id": 198,
                              "name": "MemberAccess",
                              "src": "3537:21:0"
                            }
                          ],
                          "id": 199,
                          "name": "FunctionCall",
                          "src": "3508:51:0"
                        }
                      ],
                      "id": 200,
                      "name": "ExpressionStatement",
                      "src": "3508:51:0"
                    }
                  ],
                  "id": 201,
                  "name": "Block",
                  "src": "3429:146:0"
                }
              ],
              "id": 202,
              "name": "FunctionDefinition",
              "src": "3393:182:0"
            },
            {
              "attributes": {
                "documentation": null,
                "functionSelector": "e4a773a9",
                "implemented": true,
                "isConstructor": false,
                "kind": "function",
                "modifiers": [
                  null
                ],
                "name": "payOutAllBNBFunds",
                "overrides": null,
                "scope": 670,
                "stateMutability": "nonpayable",
                "virtual": false,
                "visibility": "public"
              },
              "children": [
                {
                  "children": [
                    {
                      "attributes": {
                        "constant": false,
                        "mutability": "mutable",
                        "name": "amount",
                        "overrides": null,
                        "scope": 237,
                        "stateVariable": false,
                        "storageLocation": "default",
                        "type": "uint256",
                        "value": null,
                        "visibility": "internal"
                      },
                      "children": [
                        {
                          "attributes": {
                            "name": "uint256",
                            "type": "uint256"
                          },
                          "id": 203,
                          "name": "ElementaryTypeName",
                          "src": "3609:7:0"
                        }
                      ],
                      "id": 204,
                      "name": "VariableDeclaration",
                      "src": "3609:14:0"
                    }
                  ],
                  "id": 205,
                  "name": "ParameterList",
                  "src": "3608:16:0"
                },
                {
                  "attributes": {
                    "parameters": [
                      null
                    ]
                  },
                  "children": [],
                  "id": 206,
                  "name": "ParameterList",
                  "src": "3632:0:0"
                },
                {
                  "children": [
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "tuple()",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_bool",
                                    "typeString": "bool"
                                  },
                                  {
                                    "typeIdentifier": "t_stringliteral_a8a30372c51ebb568444a91ceff1cb5f964f572ba86793e21c1a9243e19e1e9b",
                                    "typeString": "literal_string \"Not able to do that Bro!\""
                                  }
                                ],
                                "overloadedDeclarations": [
                                  -18,
                                  -18
                                ],
                                "referencedDeclaration": -18,
                                "type": "function (bool,string memory) pure",
                                "value": "require"
                              },
                              "id": 207,
                              "name": "Identifier",
                              "src": "3642:7:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": true,
                                "isPure": false,
                                "lValueRequested": false,
                                "type": "bool"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 49,
                                    "type": "mapping(address => bool)",
                                    "value": "_canPayOut"
                                  },
                                  "id": 208,
                                  "name": "Identifier",
                                  "src": "3650:10:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "lValueRequested": false,
                                    "member_name": "sender",
                                    "referencedDeclaration": null,
                                    "type": "address payable"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": -15,
                                        "type": "msg",
                                        "value": "msg"
                                      },
                                      "id": 209,
                                      "name": "Identifier",
                                      "src": "3661:3:0"
                                    }
                                  ],
                                  "id": 210,
                                  "name": "MemberAccess",
                                  "src": "3661:10:0"
                                }
                              ],
                              "id": 211,
                              "name": "IndexAccess",
                              "src": "3650:22:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "hexvalue": "4e6f742061626c6520746f20646f20746861742042726f21",
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": true,
                                "lValueRequested": false,
                                "subdenomination": null,
                                "token": "string",
                                "type": "literal_string \"Not able to do that Bro!\"",
                                "value": "Not able to do that Bro!"
                              },
                              "id": 212,
                              "name": "Literal",
                              "src": "3674:26:0"
                            }
                          ],
                          "id": 213,
                          "name": "FunctionCall",
                          "src": "3642:59:0"
                        }
                      ],
                      "id": 214,
                      "name": "ExpressionStatement",
                      "src": "3642:59:0"
                    },
                    {
                      "attributes": {
                        "assignments": [
                          216
                        ]
                      },
                      "children": [
                        {
                          "attributes": {
                            "constant": false,
                            "mutability": "mutable",
                            "name": "currentBalance",
                            "overrides": null,
                            "scope": 236,
                            "stateVariable": false,
                            "storageLocation": "default",
                            "type": "uint256",
                            "value": null,
                            "visibility": "internal"
                          },
                          "children": [
                            {
                              "attributes": {
                                "name": "uint256",
                                "type": "uint256"
                              },
                              "id": 215,
                              "name": "ElementaryTypeName",
                              "src": "3711:7:0"
                            }
                          ],
                          "id": 216,
                          "name": "VariableDeclaration",
                          "src": "3711:22:0"
                        },
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "arguments": [
                              null
                            ],
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "uint256",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  null
                                ],
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 267,
                                "type": "function () view returns (uint256)",
                                "value": "returnCurrentBalanceBNB"
                              },
                              "id": 217,
                              "name": "Identifier",
                              "src": "3736:23:0"
                            }
                          ],
                          "id": 218,
                          "name": "FunctionCall",
                          "src": "3736:25:0"
                        }
                      ],
                      "id": 219,
                      "name": "VariableDeclarationStatement",
                      "src": "3711:50:0"
                    },
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "tuple()",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_bool",
                                    "typeString": "bool"
                                  },
                                  {
                                    "typeIdentifier": "t_stringliteral_a3ea578da6a19d0e8764eab2aaca56d4c0c702c203487eec22f39e7ff5735258",
                                    "typeString": "literal_string \"Amount is too high!\""
                                  }
                                ],
                                "overloadedDeclarations": [
                                  -18,
                                  -18
                                ],
                                "referencedDeclaration": -18,
                                "type": "function (bool,string memory) pure",
                                "value": "require"
                              },
                              "id": 220,
                              "name": "Identifier",
                              "src": "3771:7:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "commonType": {
                                  "typeIdentifier": "t_uint256",
                                  "typeString": "uint256"
                                },
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "operator": "<=",
                                "type": "bool"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 204,
                                    "type": "uint256",
                                    "value": "amount"
                                  },
                                  "id": 221,
                                  "name": "Identifier",
                                  "src": "3779:6:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 216,
                                    "type": "uint256",
                                    "value": "currentBalance"
                                  },
                                  "id": 222,
                                  "name": "Identifier",
                                  "src": "3789:14:0"
                                }
                              ],
                              "id": 223,
                              "name": "BinaryOperation",
                              "src": "3779:24:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "hexvalue": "416d6f756e7420697320746f6f206869676821",
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": true,
                                "lValueRequested": false,
                                "subdenomination": null,
                                "token": "string",
                                "type": "literal_string \"Amount is too high!\"",
                                "value": "Amount is too high!"
                              },
                              "id": 224,
                              "name": "Literal",
                              "src": "3805:21:0"
                            }
                          ],
                          "id": 225,
                          "name": "FunctionCall",
                          "src": "3771:56:0"
                        }
                      ],
                      "id": 226,
                      "name": "ExpressionStatement",
                      "src": "3771:56:0"
                    },
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "tuple()",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_uint256",
                                    "typeString": "uint256"
                                  }
                                ],
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "member_name": "transfer",
                                "referencedDeclaration": null,
                                "type": "function (uint256)"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "isStructConstructorCall": false,
                                    "lValueRequested": false,
                                    "names": [
                                      null
                                    ],
                                    "tryCall": false,
                                    "type": "address payable",
                                    "type_conversion": true
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": [
                                          {
                                            "typeIdentifier": "t_address_payable",
                                            "typeString": "address payable"
                                          }
                                        ],
                                        "isConstant": false,
                                        "isLValue": false,
                                        "isPure": true,
                                        "lValueRequested": false,
                                        "type": "type(address payable)"
                                      },
                                      "children": [
                                        {
                                          "attributes": {
                                            "name": "address",
                                            "stateMutability": "payable",
                                            "type": null
                                          },
                                          "id": 227,
                                          "name": "ElementaryTypeName",
                                          "src": "3837:8:0"
                                        }
                                      ],
                                      "id": 228,
                                      "name": "ElementaryTypeNameExpression",
                                      "src": "3837:8:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "isConstant": false,
                                        "isLValue": false,
                                        "isPure": false,
                                        "lValueRequested": false,
                                        "member_name": "sender",
                                        "referencedDeclaration": null,
                                        "type": "address payable"
                                      },
                                      "children": [
                                        {
                                          "attributes": {
                                            "argumentTypes": null,
                                            "overloadedDeclarations": [
                                              null
                                            ],
                                            "referencedDeclaration": -15,
                                            "type": "msg",
                                            "value": "msg"
                                          },
                                          "id": 229,
                                          "name": "Identifier",
                                          "src": "3845:3:0"
                                        }
                                      ],
                                      "id": 230,
                                      "name": "MemberAccess",
                                      "src": "3845:10:0"
                                    }
                                  ],
                                  "id": 231,
                                  "name": "FunctionCall",
                                  "src": "3837:19:0"
                                }
                              ],
                              "id": 232,
                              "name": "MemberAccess",
                              "src": "3837:28:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 204,
                                "type": "uint256",
                                "value": "amount"
                              },
                              "id": 233,
                              "name": "Identifier",
                              "src": "3866:6:0"
                            }
                          ],
                          "id": 234,
                          "name": "FunctionCall",
                          "src": "3837:36:0"
                        }
                      ],
                      "id": 235,
                      "name": "ExpressionStatement",
                      "src": "3837:36:0"
                    }
                  ],
                  "id": 236,
                  "name": "Block",
                  "src": "3632:257:0"
                }
              ],
              "id": 237,
              "name": "FunctionDefinition",
              "src": "3582:307:0"
            },
            {
              "attributes": {
                "documentation": null,
                "functionSelector": "a07e544d",
                "implemented": true,
                "isConstructor": false,
                "kind": "function",
                "modifiers": [
                  null
                ],
                "name": "returnCurrentBalanceOf",
                "overrides": null,
                "scope": 670,
                "stateMutability": "view",
                "virtual": false,
                "visibility": "public"
              },
              "children": [
                {
                  "children": [
                    {
                      "attributes": {
                        "constant": false,
                        "mutability": "mutable",
                        "name": "tokenAddress",
                        "overrides": null,
                        "scope": 255,
                        "stateVariable": false,
                        "storageLocation": "default",
                        "type": "address",
                        "value": null,
                        "visibility": "internal"
                      },
                      "children": [
                        {
                          "attributes": {
                            "name": "address",
                            "stateMutability": "nonpayable",
                            "type": "address"
                          },
                          "id": 238,
                          "name": "ElementaryTypeName",
                          "src": "3931:7:0"
                        }
                      ],
                      "id": 239,
                      "name": "VariableDeclaration",
                      "src": "3931:20:0"
                    }
                  ],
                  "id": 240,
                  "name": "ParameterList",
                  "src": "3930:22:0"
                },
                {
                  "children": [
                    {
                      "attributes": {
                        "constant": false,
                        "mutability": "mutable",
                        "name": "",
                        "overrides": null,
                        "scope": 255,
                        "stateVariable": false,
                        "storageLocation": "default",
                        "type": "uint256",
                        "value": null,
                        "visibility": "internal"
                      },
                      "children": [
                        {
                          "attributes": {
                            "name": "uint256",
                            "type": "uint256"
                          },
                          "id": 241,
                          "name": "ElementaryTypeName",
                          "src": "3974:7:0"
                        }
                      ],
                      "id": 242,
                      "name": "VariableDeclaration",
                      "src": "3974:7:0"
                    }
                  ],
                  "id": 243,
                  "name": "ParameterList",
                  "src": "3973:9:0"
                },
                {
                  "children": [
                    {
                      "attributes": {
                        "functionReturnParameters": 243
                      },
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "uint256",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_address_payable",
                                    "typeString": "address payable"
                                  }
                                ],
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "member_name": "balanceOf",
                                "referencedDeclaration": 709,
                                "type": "function (address) view external returns (uint256)"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "isStructConstructorCall": false,
                                    "lValueRequested": false,
                                    "names": [
                                      null
                                    ],
                                    "tryCall": false,
                                    "type": "contract IERC20",
                                    "type_conversion": true
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": [
                                          {
                                            "typeIdentifier": "t_address",
                                            "typeString": "address"
                                          }
                                        ],
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 770,
                                        "type": "type(contract IERC20)",
                                        "value": "IERC20"
                                      },
                                      "id": 244,
                                      "name": "Identifier",
                                      "src": "4000:6:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 239,
                                        "type": "address",
                                        "value": "tokenAddress"
                                      },
                                      "id": 245,
                                      "name": "Identifier",
                                      "src": "4007:12:0"
                                    }
                                  ],
                                  "id": 246,
                                  "name": "FunctionCall",
                                  "src": "4000:20:0"
                                }
                              ],
                              "id": 247,
                              "name": "MemberAccess",
                              "src": "4000:30:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "isStructConstructorCall": false,
                                "lValueRequested": false,
                                "names": [
                                  null
                                ],
                                "tryCall": false,
                                "type": "address payable",
                                "type_conversion": true
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": [
                                      {
                                        "typeIdentifier": "t_contract$_Arbitage_$670",
                                        "typeString": "contract Arbitage"
                                      }
                                    ],
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": true,
                                    "lValueRequested": false,
                                    "type": "type(address)"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "name": "address",
                                        "type": null
                                      },
                                      "id": 248,
                                      "name": "ElementaryTypeName",
                                      "src": "4031:7:0"
                                    }
                                  ],
                                  "id": 249,
                                  "name": "ElementaryTypeNameExpression",
                                  "src": "4031:7:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": -28,
                                    "type": "contract Arbitage",
                                    "value": "this"
                                  },
                                  "id": 250,
                                  "name": "Identifier",
                                  "src": "4039:4:0"
                                }
                              ],
                              "id": 251,
                              "name": "FunctionCall",
                              "src": "4031:13:0"
                            }
                          ],
                          "id": 252,
                          "name": "FunctionCall",
                          "src": "4000:45:0"
                        }
                      ],
                      "id": 253,
                      "name": "Return",
                      "src": "3993:52:0"
                    }
                  ],
                  "id": 254,
                  "name": "Block",
                  "src": "3983:69:0"
                }
              ],
              "id": 255,
              "name": "FunctionDefinition",
              "src": "3899:153:0"
            },
            {
              "attributes": {
                "documentation": null,
                "functionSelector": "ef7e6e2b",
                "implemented": true,
                "isConstructor": false,
                "kind": "function",
                "modifiers": [
                  null
                ],
                "name": "returnCurrentBalanceBNB",
                "overrides": null,
                "scope": 670,
                "stateMutability": "view",
                "virtual": false,
                "visibility": "public"
              },
              "children": [
                {
                  "attributes": {
                    "parameters": [
                      null
                    ]
                  },
                  "children": [],
                  "id": 256,
                  "name": "ParameterList",
                  "src": "4094:2:0"
                },
                {
                  "children": [
                    {
                      "attributes": {
                        "constant": false,
                        "mutability": "mutable",
                        "name": "",
                        "overrides": null,
                        "scope": 267,
                        "stateVariable": false,
                        "storageLocation": "default",
                        "type": "uint256",
                        "value": null,
                        "visibility": "internal"
                      },
                      "children": [
                        {
                          "attributes": {
                            "name": "uint256",
                            "type": "uint256"
                          },
                          "id": 257,
                          "name": "ElementaryTypeName",
                          "src": "4118:7:0"
                        }
                      ],
                      "id": 258,
                      "name": "VariableDeclaration",
                      "src": "4118:7:0"
                    }
                  ],
                  "id": 259,
                  "name": "ParameterList",
                  "src": "4117:9:0"
                },
                {
                  "children": [
                    {
                      "attributes": {
                        "functionReturnParameters": 259
                      },
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "lValueRequested": false,
                            "member_name": "balance",
                            "referencedDeclaration": null,
                            "type": "uint256"
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "isStructConstructorCall": false,
                                "lValueRequested": false,
                                "names": [
                                  null
                                ],
                                "tryCall": false,
                                "type": "address payable",
                                "type_conversion": true
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": [
                                      {
                                        "typeIdentifier": "t_contract$_Arbitage_$670",
                                        "typeString": "contract Arbitage"
                                      }
                                    ],
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": true,
                                    "lValueRequested": false,
                                    "type": "type(address)"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "name": "address",
                                        "type": null
                                      },
                                      "id": 260,
                                      "name": "ElementaryTypeName",
                                      "src": "4144:7:0"
                                    }
                                  ],
                                  "id": 261,
                                  "name": "ElementaryTypeNameExpression",
                                  "src": "4144:7:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": -28,
                                    "type": "contract Arbitage",
                                    "value": "this"
                                  },
                                  "id": 262,
                                  "name": "Identifier",
                                  "src": "4152:4:0"
                                }
                              ],
                              "id": 263,
                              "name": "FunctionCall",
                              "src": "4144:13:0"
                            }
                          ],
                          "id": 264,
                          "name": "MemberAccess",
                          "src": "4144:21:0"
                        }
                      ],
                      "id": 265,
                      "name": "Return",
                      "src": "4137:28:0"
                    }
                  ],
                  "id": 266,
                  "name": "Block",
                  "src": "4127:45:0"
                }
              ],
              "id": 267,
              "name": "FunctionDefinition",
              "src": "4062:110:0"
            },
            {
              "attributes": {
                "documentation": null,
                "functionSelector": "25073e6b",
                "implemented": true,
                "isConstructor": false,
                "kind": "function",
                "modifiers": [
                  null
                ],
                "name": "startArbitrage",
                "overrides": null,
                "scope": 670,
                "stateMutability": "nonpayable",
                "virtual": false,
                "visibility": "external"
              },
              "children": [
                {
                  "children": [
                    {
                      "attributes": {
                        "constant": false,
                        "mutability": "mutable",
                        "name": "factoryFlashloan",
                        "overrides": null,
                        "scope": 329,
                        "stateVariable": false,
                        "storageLocation": "default",
                        "type": "address",
                        "value": null,
                        "visibility": "internal"
                      },
                      "children": [
                        {
                          "attributes": {
                            "name": "address",
                            "stateMutability": "nonpayable",
                            "type": "address"
                          },
                          "id": 268,
                          "name": "ElementaryTypeName",
                          "src": "4216:7:0"
                        }
                      ],
                      "id": 269,
                      "name": "VariableDeclaration",
                      "src": "4216:24:0"
                    },
                    {
                      "attributes": {
                        "constant": false,
                        "mutability": "mutable",
                        "name": "routerBuyIn",
                        "overrides": null,
                        "scope": 329,
                        "stateVariable": false,
                        "storageLocation": "default",
                        "type": "address",
                        "value": null,
                        "visibility": "internal"
                      },
                      "children": [
                        {
                          "attributes": {
                            "name": "address",
                            "stateMutability": "nonpayable",
                            "type": "address"
                          },
                          "id": 270,
                          "name": "ElementaryTypeName",
                          "src": "4246:7:0"
                        }
                      ],
                      "id": 271,
                      "name": "VariableDeclaration",
                      "src": "4246:19:0"
                    },
                    {
                      "attributes": {
                        "constant": false,
                        "mutability": "mutable",
                        "name": "token0",
                        "overrides": null,
                        "scope": 329,
                        "stateVariable": false,
                        "storageLocation": "default",
                        "type": "address",
                        "value": null,
                        "visibility": "internal"
                      },
                      "children": [
                        {
                          "attributes": {
                            "name": "address",
                            "stateMutability": "nonpayable",
                            "type": "address"
                          },
                          "id": 272,
                          "name": "ElementaryTypeName",
                          "src": "4271:7:0"
                        }
                      ],
                      "id": 273,
                      "name": "VariableDeclaration",
                      "src": "4271:14:0"
                    },
                    {
                      "attributes": {
                        "constant": false,
                        "mutability": "mutable",
                        "name": "token1",
                        "overrides": null,
                        "scope": 329,
                        "stateVariable": false,
                        "storageLocation": "default",
                        "type": "address",
                        "value": null,
                        "visibility": "internal"
                      },
                      "children": [
                        {
                          "attributes": {
                            "name": "address",
                            "stateMutability": "nonpayable",
                            "type": "address"
                          },
                          "id": 274,
                          "name": "ElementaryTypeName",
                          "src": "4292:7:0"
                        }
                      ],
                      "id": 275,
                      "name": "VariableDeclaration",
                      "src": "4292:14:0"
                    },
                    {
                      "attributes": {
                        "constant": false,
                        "mutability": "mutable",
                        "name": "amount0",
                        "overrides": null,
                        "scope": 329,
                        "stateVariable": false,
                        "storageLocation": "default",
                        "type": "uint256",
                        "value": null,
                        "visibility": "internal"
                      },
                      "children": [
                        {
                          "attributes": {
                            "name": "uint",
                            "type": "uint256"
                          },
                          "id": 276,
                          "name": "ElementaryTypeName",
                          "src": "4313:4:0"
                        }
                      ],
                      "id": 277,
                      "name": "VariableDeclaration",
                      "src": "4313:12:0"
                    },
                    {
                      "attributes": {
                        "constant": false,
                        "mutability": "mutable",
                        "name": "amount1",
                        "overrides": null,
                        "scope": 329,
                        "stateVariable": false,
                        "storageLocation": "default",
                        "type": "uint256",
                        "value": null,
                        "visibility": "internal"
                      },
                      "children": [
                        {
                          "attributes": {
                            "name": "uint",
                            "type": "uint256"
                          },
                          "id": 278,
                          "name": "ElementaryTypeName",
                          "src": "4332:4:0"
                        }
                      ],
                      "id": 279,
                      "name": "VariableDeclaration",
                      "src": "4332:12:0"
                    }
                  ],
                  "id": 280,
                  "name": "ParameterList",
                  "src": "4210:138:0"
                },
                {
                  "attributes": {
                    "parameters": [
                      null
                    ]
                  },
                  "children": [],
                  "id": 281,
                  "name": "ParameterList",
                  "src": "4358:0:0"
                },
                {
                  "children": [
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "lValueRequested": false,
                            "operator": "=",
                            "type": "address"
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 19,
                                "type": "address",
                                "value": "factory"
                              },
                              "id": 282,
                              "name": "Identifier",
                              "src": "4364:7:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 269,
                                "type": "address",
                                "value": "factoryFlashloan"
                              },
                              "id": 283,
                              "name": "Identifier",
                              "src": "4374:16:0"
                            }
                          ],
                          "id": 284,
                          "name": "Assignment",
                          "src": "4364:26:0"
                        }
                      ],
                      "id": 285,
                      "name": "ExpressionStatement",
                      "src": "4364:26:0"
                    },
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "lValueRequested": false,
                            "operator": "=",
                            "type": "contract IUniswapV2Router02"
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 24,
                                "type": "contract IUniswapV2Router02",
                                "value": "sushiRouter"
                              },
                              "id": 286,
                              "name": "Identifier",
                              "src": "4398:11:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "isStructConstructorCall": false,
                                "lValueRequested": false,
                                "names": [
                                  null
                                ],
                                "tryCall": false,
                                "type": "contract IUniswapV2Router02",
                                "type_conversion": true
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": [
                                      {
                                        "typeIdentifier": "t_address",
                                        "typeString": "address"
                                      }
                                    ],
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 1468,
                                    "type": "type(contract IUniswapV2Router02)",
                                    "value": "IUniswapV2Router02"
                                  },
                                  "id": 287,
                                  "name": "Identifier",
                                  "src": "4412:18:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 271,
                                    "type": "address",
                                    "value": "routerBuyIn"
                                  },
                                  "id": 288,
                                  "name": "Identifier",
                                  "src": "4431:11:0"
                                }
                              ],
                              "id": 289,
                              "name": "FunctionCall",
                              "src": "4412:31:0"
                            }
                          ],
                          "id": 290,
                          "name": "Assignment",
                          "src": "4398:45:0"
                        }
                      ],
                      "id": 291,
                      "name": "ExpressionStatement",
                      "src": "4398:45:0"
                    },
                    {
                      "attributes": {
                        "assignments": [
                          293
                        ]
                      },
                      "children": [
                        {
                          "attributes": {
                            "constant": false,
                            "mutability": "mutable",
                            "name": "pairAddress",
                            "overrides": null,
                            "scope": 328,
                            "stateVariable": false,
                            "storageLocation": "default",
                            "type": "address",
                            "value": null,
                            "visibility": "internal"
                          },
                          "children": [
                            {
                              "attributes": {
                                "name": "address",
                                "stateMutability": "nonpayable",
                                "type": "address"
                              },
                              "id": 292,
                              "name": "ElementaryTypeName",
                              "src": "4449:7:0"
                            }
                          ],
                          "id": 293,
                          "name": "VariableDeclaration",
                          "src": "4449:19:0"
                        },
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "address",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_address",
                                    "typeString": "address"
                                  },
                                  {
                                    "typeIdentifier": "t_address",
                                    "typeString": "address"
                                  }
                                ],
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "member_name": "getPair",
                                "referencedDeclaration": 801,
                                "type": "function (address,address) view external returns (address)"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "isStructConstructorCall": false,
                                    "lValueRequested": false,
                                    "names": [
                                      null
                                    ],
                                    "tryCall": false,
                                    "type": "contract IUniswapV2Factory",
                                    "type_conversion": true
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": [
                                          {
                                            "typeIdentifier": "t_address",
                                            "typeString": "address"
                                          }
                                        ],
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 833,
                                        "type": "type(contract IUniswapV2Factory)",
                                        "value": "IUniswapV2Factory"
                                      },
                                      "id": 294,
                                      "name": "Identifier",
                                      "src": "4471:17:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 19,
                                        "type": "address",
                                        "value": "factory"
                                      },
                                      "id": 295,
                                      "name": "Identifier",
                                      "src": "4489:7:0"
                                    }
                                  ],
                                  "id": 296,
                                  "name": "FunctionCall",
                                  "src": "4471:26:0"
                                }
                              ],
                              "id": 297,
                              "name": "MemberAccess",
                              "src": "4471:34:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 273,
                                "type": "address",
                                "value": "token0"
                              },
                              "id": 298,
                              "name": "Identifier",
                              "src": "4506:6:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 275,
                                "type": "address",
                                "value": "token1"
                              },
                              "id": 299,
                              "name": "Identifier",
                              "src": "4514:6:0"
                            }
                          ],
                          "id": 300,
                          "name": "FunctionCall",
                          "src": "4471:50:0"
                        }
                      ],
                      "id": 301,
                      "name": "VariableDeclarationStatement",
                      "src": "4449:72:0"
                    },
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "tuple()",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_bool",
                                    "typeString": "bool"
                                  },
                                  {
                                    "typeIdentifier": "t_stringliteral_c7b83ef4d31517478af18b53eaeed17c28c06bf48ddd29363e648bda7de6e2a5",
                                    "typeString": "literal_string \"This pool does not exist\""
                                  }
                                ],
                                "overloadedDeclarations": [
                                  -18,
                                  -18
                                ],
                                "referencedDeclaration": -18,
                                "type": "function (bool,string memory) pure",
                                "value": "require"
                              },
                              "id": 302,
                              "name": "Identifier",
                              "src": "4527:7:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "commonType": {
                                  "typeIdentifier": "t_address",
                                  "typeString": "address"
                                },
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "operator": "!=",
                                "type": "bool"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 293,
                                    "type": "address",
                                    "value": "pairAddress"
                                  },
                                  "id": 303,
                                  "name": "Identifier",
                                  "src": "4535:11:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": true,
                                    "isStructConstructorCall": false,
                                    "lValueRequested": false,
                                    "names": [
                                      null
                                    ],
                                    "tryCall": false,
                                    "type": "address payable",
                                    "type_conversion": true
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": [
                                          {
                                            "typeIdentifier": "t_rational_0_by_1",
                                            "typeString": "int_const 0"
                                          }
                                        ],
                                        "isConstant": false,
                                        "isLValue": false,
                                        "isPure": true,
                                        "lValueRequested": false,
                                        "type": "type(address)"
                                      },
                                      "children": [
                                        {
                                          "attributes": {
                                            "name": "address",
                                            "type": null
                                          },
                                          "id": 304,
                                          "name": "ElementaryTypeName",
                                          "src": "4550:7:0"
                                        }
                                      ],
                                      "id": 305,
                                      "name": "ElementaryTypeNameExpression",
                                      "src": "4550:7:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "hexvalue": "30",
                                        "isConstant": false,
                                        "isLValue": false,
                                        "isPure": true,
                                        "lValueRequested": false,
                                        "subdenomination": null,
                                        "token": "number",
                                        "type": "int_const 0",
                                        "value": "0"
                                      },
                                      "id": 306,
                                      "name": "Literal",
                                      "src": "4558:1:0"
                                    }
                                  ],
                                  "id": 307,
                                  "name": "FunctionCall",
                                  "src": "4550:10:0"
                                }
                              ],
                              "id": 308,
                              "name": "BinaryOperation",
                              "src": "4535:25:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "hexvalue": "5468697320706f6f6c20646f6573206e6f74206578697374",
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": true,
                                "lValueRequested": false,
                                "subdenomination": null,
                                "token": "string",
                                "type": "literal_string \"This pool does not exist\"",
                                "value": "This pool does not exist"
                              },
                              "id": 309,
                              "name": "Literal",
                              "src": "4562:26:0"
                            }
                          ],
                          "id": 310,
                          "name": "FunctionCall",
                          "src": "4527:62:0"
                        }
                      ],
                      "id": 311,
                      "name": "ExpressionStatement",
                      "src": "4527:62:0"
                    },
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "tuple()",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_uint256",
                                    "typeString": "uint256"
                                  },
                                  {
                                    "typeIdentifier": "t_uint256",
                                    "typeString": "uint256"
                                  },
                                  {
                                    "typeIdentifier": "t_address_payable",
                                    "typeString": "address payable"
                                  },
                                  {
                                    "typeIdentifier": "t_bytes_memory_ptr",
                                    "typeString": "bytes memory"
                                  }
                                ],
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "member_name": "swap",
                                "referencedDeclaration": 1059,
                                "type": "function (uint256,uint256,address,bytes memory) external"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "isStructConstructorCall": false,
                                    "lValueRequested": false,
                                    "names": [
                                      null
                                    ],
                                    "tryCall": false,
                                    "type": "contract IUniswapV2Pair",
                                    "type_conversion": true
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": [
                                          {
                                            "typeIdentifier": "t_address",
                                            "typeString": "address"
                                          }
                                        ],
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 1075,
                                        "type": "type(contract IUniswapV2Pair)",
                                        "value": "IUniswapV2Pair"
                                      },
                                      "id": 312,
                                      "name": "Identifier",
                                      "src": "4595:14:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 293,
                                        "type": "address",
                                        "value": "pairAddress"
                                      },
                                      "id": 313,
                                      "name": "Identifier",
                                      "src": "4610:11:0"
                                    }
                                  ],
                                  "id": 314,
                                  "name": "FunctionCall",
                                  "src": "4595:27:0"
                                }
                              ],
                              "id": 315,
                              "name": "MemberAccess",
                              "src": "4595:32:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 277,
                                "type": "uint256",
                                "value": "amount0"
                              },
                              "id": 316,
                              "name": "Identifier",
                              "src": "4635:7:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 279,
                                "type": "uint256",
                                "value": "amount1"
                              },
                              "id": 317,
                              "name": "Identifier",
                              "src": "4651:7:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "isStructConstructorCall": false,
                                "lValueRequested": false,
                                "names": [
                                  null
                                ],
                                "tryCall": false,
                                "type": "address payable",
                                "type_conversion": true
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": [
                                      {
                                        "typeIdentifier": "t_contract$_Arbitage_$670",
                                        "typeString": "contract Arbitage"
                                      }
                                    ],
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": true,
                                    "lValueRequested": false,
                                    "type": "type(address)"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "name": "address",
                                        "type": null
                                      },
                                      "id": 318,
                                      "name": "ElementaryTypeName",
                                      "src": "4667:7:0"
                                    }
                                  ],
                                  "id": 319,
                                  "name": "ElementaryTypeNameExpression",
                                  "src": "4667:7:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": -28,
                                    "type": "contract Arbitage",
                                    "value": "this"
                                  },
                                  "id": 320,
                                  "name": "Identifier",
                                  "src": "4675:4:0"
                                }
                              ],
                              "id": 321,
                              "name": "FunctionCall",
                              "src": "4667:13:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": true,
                                "isStructConstructorCall": false,
                                "lValueRequested": false,
                                "names": [
                                  null
                                ],
                                "tryCall": false,
                                "type": "bytes memory",
                                "type_conversion": true
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": [
                                      {
                                        "typeIdentifier": "t_stringliteral_a04ad52322ead0231944629cf681090c4146b94624d4ce93f9da68c247b29319",
                                        "typeString": "literal_string \"not empty\""
                                      }
                                    ],
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": true,
                                    "lValueRequested": false,
                                    "type": "type(bytes storage pointer)"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "name": "bytes",
                                        "type": null
                                      },
                                      "id": 322,
                                      "name": "ElementaryTypeName",
                                      "src": "4689:5:0"
                                    }
                                  ],
                                  "id": 323,
                                  "name": "ElementaryTypeNameExpression",
                                  "src": "4689:5:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "hexvalue": "6e6f7420656d707479",
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": true,
                                    "lValueRequested": false,
                                    "subdenomination": null,
                                    "token": "string",
                                    "type": "literal_string \"not empty\"",
                                    "value": "not empty"
                                  },
                                  "id": 324,
                                  "name": "Literal",
                                  "src": "4695:11:0"
                                }
                              ],
                              "id": 325,
                              "name": "FunctionCall",
                              "src": "4689:18:0"
                            }
                          ],
                          "id": 326,
                          "name": "FunctionCall",
                          "src": "4595:118:0"
                        }
                      ],
                      "id": 327,
                      "name": "ExpressionStatement",
                      "src": "4595:118:0"
                    }
                  ],
                  "id": 328,
                  "name": "Block",
                  "src": "4358:360:0"
                }
              ],
              "id": 329,
              "name": "FunctionDefinition",
              "src": "4187:531:0"
            },
            {
              "attributes": {
                "documentation": null,
                "functionSelector": "84800812",
                "implemented": true,
                "isConstructor": false,
                "kind": "function",
                "modifiers": [
                  null
                ],
                "name": "pancakeCall",
                "overrides": null,
                "scope": 670,
                "stateMutability": "nonpayable",
                "virtual": false,
                "visibility": "external"
              },
              "children": [
                {
                  "children": [
                    {
                      "attributes": {
                        "constant": false,
                        "mutability": "mutable",
                        "name": "_sender",
                        "overrides": null,
                        "scope": 499,
                        "stateVariable": false,
                        "storageLocation": "default",
                        "type": "address",
                        "value": null,
                        "visibility": "internal"
                      },
                      "children": [
                        {
                          "attributes": {
                            "name": "address",
                            "stateMutability": "nonpayable",
                            "type": "address"
                          },
                          "id": 330,
                          "name": "ElementaryTypeName",
                          "src": "4748:7:0"
                        }
                      ],
                      "id": 331,
                      "name": "VariableDeclaration",
                      "src": "4748:15:0"
                    },
                    {
                      "attributes": {
                        "constant": false,
                        "mutability": "mutable",
                        "name": "_amount0",
                        "overrides": null,
                        "scope": 499,
                        "stateVariable": false,
                        "storageLocation": "default",
                        "type": "uint256",
                        "value": null,
                        "visibility": "internal"
                      },
                      "children": [
                        {
                          "attributes": {
                            "name": "uint",
                            "type": "uint256"
                          },
                          "id": 332,
                          "name": "ElementaryTypeName",
                          "src": "4770:4:0"
                        }
                      ],
                      "id": 333,
                      "name": "VariableDeclaration",
                      "src": "4770:13:0"
                    },
                    {
                      "attributes": {
                        "constant": false,
                        "mutability": "mutable",
                        "name": "_amount1",
                        "overrides": null,
                        "scope": 499,
                        "stateVariable": false,
                        "storageLocation": "default",
                        "type": "uint256",
                        "value": null,
                        "visibility": "internal"
                      },
                      "children": [
                        {
                          "attributes": {
                            "name": "uint",
                            "type": "uint256"
                          },
                          "id": 334,
                          "name": "ElementaryTypeName",
                          "src": "4790:4:0"
                        }
                      ],
                      "id": 335,
                      "name": "VariableDeclaration",
                      "src": "4790:13:0"
                    },
                    {
                      "attributes": {
                        "constant": false,
                        "mutability": "mutable",
                        "name": "_data",
                        "overrides": null,
                        "scope": 499,
                        "stateVariable": false,
                        "storageLocation": "calldata",
                        "type": "bytes",
                        "value": null,
                        "visibility": "internal"
                      },
                      "children": [
                        {
                          "attributes": {
                            "name": "bytes",
                            "type": "bytes"
                          },
                          "id": 336,
                          "name": "ElementaryTypeName",
                          "src": "4810:5:0"
                        }
                      ],
                      "id": 337,
                      "name": "VariableDeclaration",
                      "src": "4810:20:0"
                    }
                  ],
                  "id": 338,
                  "name": "ParameterList",
                  "src": "4742:92:0"
                },
                {
                  "attributes": {
                    "parameters": [
                      null
                    ]
                  },
                  "children": [],
                  "id": 339,
                  "name": "ParameterList",
                  "src": "4844:0:0"
                },
                {
                  "children": [
                    {
                      "attributes": {
                        "assignments": [
                          344
                        ]
                      },
                      "children": [
                        {
                          "attributes": {
                            "constant": false,
                            "mutability": "mutable",
                            "name": "path",
                            "overrides": null,
                            "scope": 498,
                            "stateVariable": false,
                            "storageLocation": "memory",
                            "type": "address[]",
                            "value": null,
                            "visibility": "internal"
                          },
                          "children": [
                            {
                              "attributes": {
                                "length": null,
                                "type": "address[]"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "name": "address",
                                    "type": "address"
                                  },
                                  "id": 342,
                                  "name": "ElementaryTypeName",
                                  "src": "4850:7:0"
                                }
                              ],
                              "id": 343,
                              "name": "ArrayTypeName",
                              "src": "4850:9:0"
                            }
                          ],
                          "id": 344,
                          "name": "VariableDeclaration",
                          "src": "4850:21:0"
                        },
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": true,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "address[] memory",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_rational_2_by_1",
                                    "typeString": "int_const 2"
                                  }
                                ],
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": true,
                                "lValueRequested": false,
                                "type": "function (uint256) pure returns (address[] memory)"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "length": null,
                                    "type": "address[]"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "name": "address",
                                        "stateMutability": "nonpayable",
                                        "type": "address"
                                      },
                                      "id": 345,
                                      "name": "ElementaryTypeName",
                                      "src": "4878:7:0"
                                    }
                                  ],
                                  "id": 346,
                                  "name": "ArrayTypeName",
                                  "src": "4878:9:0"
                                }
                              ],
                              "id": 347,
                              "name": "NewExpression",
                              "src": "4874:13:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "hexvalue": "32",
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": true,
                                "lValueRequested": false,
                                "subdenomination": null,
                                "token": "number",
                                "type": "int_const 2",
                                "value": "2"
                              },
                              "id": 348,
                              "name": "Literal",
                              "src": "4888:1:0"
                            }
                          ],
                          "id": 349,
                          "name": "FunctionCall",
                          "src": "4874:16:0"
                        }
                      ],
                      "id": 350,
                      "name": "VariableDeclarationStatement",
                      "src": "4850:40:0"
                    },
                    {
                      "attributes": {
                        "assignments": [
                          352
                        ]
                      },
                      "children": [
                        {
                          "attributes": {
                            "constant": false,
                            "mutability": "mutable",
                            "name": "amountToken",
                            "overrides": null,
                            "scope": 498,
                            "stateVariable": false,
                            "storageLocation": "default",
                            "type": "uint256",
                            "value": null,
                            "visibility": "internal"
                          },
                          "children": [
                            {
                              "attributes": {
                                "name": "uint",
                                "type": "uint256"
                              },
                              "id": 351,
                              "name": "ElementaryTypeName",
                              "src": "4896:4:0"
                            }
                          ],
                          "id": 352,
                          "name": "VariableDeclaration",
                          "src": "4896:16:0"
                        },
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "lValueRequested": false,
                            "type": "uint256"
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "commonType": {
                                  "typeIdentifier": "t_uint256",
                                  "typeString": "uint256"
                                },
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "operator": "==",
                                "type": "bool"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 333,
                                    "type": "uint256",
                                    "value": "_amount0"
                                  },
                                  "id": 353,
                                  "name": "Identifier",
                                  "src": "4915:8:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "hexvalue": "30",
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": true,
                                    "lValueRequested": false,
                                    "subdenomination": null,
                                    "token": "number",
                                    "type": "int_const 0",
                                    "value": "0"
                                  },
                                  "id": 354,
                                  "name": "Literal",
                                  "src": "4927:1:0"
                                }
                              ],
                              "id": 355,
                              "name": "BinaryOperation",
                              "src": "4915:13:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 335,
                                "type": "uint256",
                                "value": "_amount1"
                              },
                              "id": 356,
                              "name": "Identifier",
                              "src": "4931:8:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 333,
                                "type": "uint256",
                                "value": "_amount0"
                              },
                              "id": 357,
                              "name": "Identifier",
                              "src": "4942:8:0"
                            }
                          ],
                          "id": 358,
                          "name": "Conditional",
                          "src": "4915:35:0"
                        }
                      ],
                      "id": 359,
                      "name": "VariableDeclarationStatement",
                      "src": "4896:54:0"
                    },
                    {
                      "attributes": {
                        "assignments": [
                          361
                        ]
                      },
                      "children": [
                        {
                          "attributes": {
                            "constant": false,
                            "mutability": "mutable",
                            "name": "token0",
                            "overrides": null,
                            "scope": 498,
                            "stateVariable": false,
                            "storageLocation": "default",
                            "type": "address",
                            "value": null,
                            "visibility": "internal"
                          },
                          "children": [
                            {
                              "attributes": {
                                "name": "address",
                                "stateMutability": "nonpayable",
                                "type": "address"
                              },
                              "id": 360,
                              "name": "ElementaryTypeName",
                              "src": "4961:7:0"
                            }
                          ],
                          "id": 361,
                          "name": "VariableDeclaration",
                          "src": "4961:14:0"
                        },
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "arguments": [
                              null
                            ],
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "address",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  null
                                ],
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "member_name": "token0",
                                "referencedDeclaration": 1003,
                                "type": "function () view external returns (address)"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "isStructConstructorCall": false,
                                    "lValueRequested": false,
                                    "names": [
                                      null
                                    ],
                                    "tryCall": false,
                                    "type": "contract IUniswapV2Pair",
                                    "type_conversion": true
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": [
                                          {
                                            "typeIdentifier": "t_address_payable",
                                            "typeString": "address payable"
                                          }
                                        ],
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 1075,
                                        "type": "type(contract IUniswapV2Pair)",
                                        "value": "IUniswapV2Pair"
                                      },
                                      "id": 362,
                                      "name": "Identifier",
                                      "src": "4978:14:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "isConstant": false,
                                        "isLValue": false,
                                        "isPure": false,
                                        "lValueRequested": false,
                                        "member_name": "sender",
                                        "referencedDeclaration": null,
                                        "type": "address payable"
                                      },
                                      "children": [
                                        {
                                          "attributes": {
                                            "argumentTypes": null,
                                            "overloadedDeclarations": [
                                              null
                                            ],
                                            "referencedDeclaration": -15,
                                            "type": "msg",
                                            "value": "msg"
                                          },
                                          "id": 363,
                                          "name": "Identifier",
                                          "src": "4993:3:0"
                                        }
                                      ],
                                      "id": 364,
                                      "name": "MemberAccess",
                                      "src": "4993:10:0"
                                    }
                                  ],
                                  "id": 365,
                                  "name": "FunctionCall",
                                  "src": "4978:26:0"
                                }
                              ],
                              "id": 366,
                              "name": "MemberAccess",
                              "src": "4978:33:0"
                            }
                          ],
                          "id": 367,
                          "name": "FunctionCall",
                          "src": "4978:35:0"
                        }
                      ],
                      "id": 368,
                      "name": "VariableDeclarationStatement",
                      "src": "4961:52:0"
                    },
                    {
                      "attributes": {
                        "assignments": [
                          370
                        ]
                      },
                      "children": [
                        {
                          "attributes": {
                            "constant": false,
                            "mutability": "mutable",
                            "name": "token1",
                            "overrides": null,
                            "scope": 498,
                            "stateVariable": false,
                            "storageLocation": "default",
                            "type": "address",
                            "value": null,
                            "visibility": "internal"
                          },
                          "children": [
                            {
                              "attributes": {
                                "name": "address",
                                "stateMutability": "nonpayable",
                                "type": "address"
                              },
                              "id": 369,
                              "name": "ElementaryTypeName",
                              "src": "5019:7:0"
                            }
                          ],
                          "id": 370,
                          "name": "VariableDeclaration",
                          "src": "5019:14:0"
                        },
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "arguments": [
                              null
                            ],
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "address",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  null
                                ],
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "member_name": "token1",
                                "referencedDeclaration": 1008,
                                "type": "function () view external returns (address)"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "isStructConstructorCall": false,
                                    "lValueRequested": false,
                                    "names": [
                                      null
                                    ],
                                    "tryCall": false,
                                    "type": "contract IUniswapV2Pair",
                                    "type_conversion": true
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": [
                                          {
                                            "typeIdentifier": "t_address_payable",
                                            "typeString": "address payable"
                                          }
                                        ],
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 1075,
                                        "type": "type(contract IUniswapV2Pair)",
                                        "value": "IUniswapV2Pair"
                                      },
                                      "id": 371,
                                      "name": "Identifier",
                                      "src": "5036:14:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "isConstant": false,
                                        "isLValue": false,
                                        "isPure": false,
                                        "lValueRequested": false,
                                        "member_name": "sender",
                                        "referencedDeclaration": null,
                                        "type": "address payable"
                                      },
                                      "children": [
                                        {
                                          "attributes": {
                                            "argumentTypes": null,
                                            "overloadedDeclarations": [
                                              null
                                            ],
                                            "referencedDeclaration": -15,
                                            "type": "msg",
                                            "value": "msg"
                                          },
                                          "id": 372,
                                          "name": "Identifier",
                                          "src": "5051:3:0"
                                        }
                                      ],
                                      "id": 373,
                                      "name": "MemberAccess",
                                      "src": "5051:10:0"
                                    }
                                  ],
                                  "id": 374,
                                  "name": "FunctionCall",
                                  "src": "5036:26:0"
                                }
                              ],
                              "id": 375,
                              "name": "MemberAccess",
                              "src": "5036:33:0"
                            }
                          ],
                          "id": 376,
                          "name": "FunctionCall",
                          "src": "5036:35:0"
                        }
                      ],
                      "id": 377,
                      "name": "VariableDeclarationStatement",
                      "src": "5019:52:0"
                    },
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "tuple()",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_bool",
                                    "typeString": "bool"
                                  },
                                  {
                                    "typeIdentifier": "t_stringliteral_1b2638459828301e8cd6c7c02856073bacf975379e0867f689bb14feacb780c5",
                                    "typeString": "literal_string \"Unauthorized\""
                                  }
                                ],
                                "overloadedDeclarations": [
                                  -18,
                                  -18
                                ],
                                "referencedDeclaration": -18,
                                "type": "function (bool,string memory) pure",
                                "value": "require"
                              },
                              "id": 378,
                              "name": "Identifier",
                              "src": "5078:7:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "commonType": {
                                  "typeIdentifier": "t_address",
                                  "typeString": "address"
                                },
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "operator": "==",
                                "type": "bool"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "lValueRequested": false,
                                    "member_name": "sender",
                                    "referencedDeclaration": null,
                                    "type": "address payable"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": -15,
                                        "type": "msg",
                                        "value": "msg"
                                      },
                                      "id": 379,
                                      "name": "Identifier",
                                      "src": "5093:3:0"
                                    }
                                  ],
                                  "id": 380,
                                  "name": "MemberAccess",
                                  "src": "5093:10:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "isStructConstructorCall": false,
                                    "lValueRequested": false,
                                    "names": [
                                      null
                                    ],
                                    "tryCall": false,
                                    "type": "address",
                                    "type_conversion": false
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": [
                                          {
                                            "typeIdentifier": "t_address",
                                            "typeString": "address"
                                          },
                                          {
                                            "typeIdentifier": "t_address",
                                            "typeString": "address"
                                          },
                                          {
                                            "typeIdentifier": "t_address",
                                            "typeString": "address"
                                          }
                                        ],
                                        "isConstant": false,
                                        "isLValue": false,
                                        "isPure": false,
                                        "lValueRequested": false,
                                        "member_name": "pairFor",
                                        "referencedDeclaration": 1896,
                                        "type": "function (address,address,address) pure returns (address)"
                                      },
                                      "children": [
                                        {
                                          "attributes": {
                                            "argumentTypes": null,
                                            "overloadedDeclarations": [
                                              null
                                            ],
                                            "referencedDeclaration": 2272,
                                            "type": "type(library UniswapV2Library)",
                                            "value": "UniswapV2Library"
                                          },
                                          "id": 381,
                                          "name": "Identifier",
                                          "src": "5107:16:0"
                                        }
                                      ],
                                      "id": 382,
                                      "name": "MemberAccess",
                                      "src": "5107:24:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 19,
                                        "type": "address",
                                        "value": "factory"
                                      },
                                      "id": 383,
                                      "name": "Identifier",
                                      "src": "5132:7:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 361,
                                        "type": "address",
                                        "value": "token0"
                                      },
                                      "id": 384,
                                      "name": "Identifier",
                                      "src": "5141:6:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 370,
                                        "type": "address",
                                        "value": "token1"
                                      },
                                      "id": 385,
                                      "name": "Identifier",
                                      "src": "5149:6:0"
                                    }
                                  ],
                                  "id": 386,
                                  "name": "FunctionCall",
                                  "src": "5107:49:0"
                                }
                              ],
                              "id": 387,
                              "name": "BinaryOperation",
                              "src": "5093:63:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "hexvalue": "556e617574686f72697a6564",
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": true,
                                "lValueRequested": false,
                                "subdenomination": null,
                                "token": "string",
                                "type": "literal_string \"Unauthorized\"",
                                "value": "Unauthorized"
                              },
                              "id": 388,
                              "name": "Literal",
                              "src": "5165:14:0"
                            }
                          ],
                          "id": 389,
                          "name": "FunctionCall",
                          "src": "5078:107:0"
                        }
                      ],
                      "id": 390,
                      "name": "ExpressionStatement",
                      "src": "5078:107:0"
                    },
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "tuple()",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_bool",
                                    "typeString": "bool"
                                  }
                                ],
                                "overloadedDeclarations": [
                                  -18,
                                  -18
                                ],
                                "referencedDeclaration": -18,
                                "type": "function (bool) pure",
                                "value": "require"
                              },
                              "id": 391,
                              "name": "Identifier",
                              "src": "5192:7:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "commonType": {
                                  "typeIdentifier": "t_bool",
                                  "typeString": "bool"
                                },
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "operator": "||",
                                "type": "bool"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "commonType": {
                                      "typeIdentifier": "t_uint256",
                                      "typeString": "uint256"
                                    },
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "lValueRequested": false,
                                    "operator": "==",
                                    "type": "bool"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 333,
                                        "type": "uint256",
                                        "value": "_amount0"
                                      },
                                      "id": 392,
                                      "name": "Identifier",
                                      "src": "5200:8:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "hexvalue": "30",
                                        "isConstant": false,
                                        "isLValue": false,
                                        "isPure": true,
                                        "lValueRequested": false,
                                        "subdenomination": null,
                                        "token": "number",
                                        "type": "int_const 0",
                                        "value": "0"
                                      },
                                      "id": 393,
                                      "name": "Literal",
                                      "src": "5212:1:0"
                                    }
                                  ],
                                  "id": 394,
                                  "name": "BinaryOperation",
                                  "src": "5200:13:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "commonType": {
                                      "typeIdentifier": "t_uint256",
                                      "typeString": "uint256"
                                    },
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "lValueRequested": false,
                                    "operator": "==",
                                    "type": "bool"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 335,
                                        "type": "uint256",
                                        "value": "_amount1"
                                      },
                                      "id": 395,
                                      "name": "Identifier",
                                      "src": "5217:8:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "hexvalue": "30",
                                        "isConstant": false,
                                        "isLValue": false,
                                        "isPure": true,
                                        "lValueRequested": false,
                                        "subdenomination": null,
                                        "token": "number",
                                        "type": "int_const 0",
                                        "value": "0"
                                      },
                                      "id": 396,
                                      "name": "Literal",
                                      "src": "5229:1:0"
                                    }
                                  ],
                                  "id": 397,
                                  "name": "BinaryOperation",
                                  "src": "5217:13:0"
                                }
                              ],
                              "id": 398,
                              "name": "BinaryOperation",
                              "src": "5200:30:0"
                            }
                          ],
                          "id": 399,
                          "name": "FunctionCall",
                          "src": "5192:39:0"
                        }
                      ],
                      "id": 400,
                      "name": "ExpressionStatement",
                      "src": "5192:39:0"
                    },
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "lValueRequested": false,
                            "operator": "=",
                            "type": "address"
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": true,
                                "isPure": false,
                                "lValueRequested": true,
                                "type": "address"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 344,
                                    "type": "address[] memory",
                                    "value": "path"
                                  },
                                  "id": 401,
                                  "name": "Identifier",
                                  "src": "5238:4:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "hexvalue": "30",
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": true,
                                    "lValueRequested": false,
                                    "subdenomination": null,
                                    "token": "number",
                                    "type": "int_const 0",
                                    "value": "0"
                                  },
                                  "id": 402,
                                  "name": "Literal",
                                  "src": "5243:1:0"
                                }
                              ],
                              "id": 403,
                              "name": "IndexAccess",
                              "src": "5238:7:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "type": "address"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "commonType": {
                                      "typeIdentifier": "t_uint256",
                                      "typeString": "uint256"
                                    },
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "lValueRequested": false,
                                    "operator": "==",
                                    "type": "bool"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 333,
                                        "type": "uint256",
                                        "value": "_amount0"
                                      },
                                      "id": 404,
                                      "name": "Identifier",
                                      "src": "5248:8:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "hexvalue": "30",
                                        "isConstant": false,
                                        "isLValue": false,
                                        "isPure": true,
                                        "lValueRequested": false,
                                        "subdenomination": null,
                                        "token": "number",
                                        "type": "int_const 0",
                                        "value": "0"
                                      },
                                      "id": 405,
                                      "name": "Literal",
                                      "src": "5260:1:0"
                                    }
                                  ],
                                  "id": 406,
                                  "name": "BinaryOperation",
                                  "src": "5248:13:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 370,
                                    "type": "address",
                                    "value": "token1"
                                  },
                                  "id": 407,
                                  "name": "Identifier",
                                  "src": "5264:6:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 361,
                                    "type": "address",
                                    "value": "token0"
                                  },
                                  "id": 408,
                                  "name": "Identifier",
                                  "src": "5273:6:0"
                                }
                              ],
                              "id": 409,
                              "name": "Conditional",
                              "src": "5248:31:0"
                            }
                          ],
                          "id": 410,
                          "name": "Assignment",
                          "src": "5238:41:0"
                        }
                      ],
                      "id": 411,
                      "name": "ExpressionStatement",
                      "src": "5238:41:0"
                    },
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "lValueRequested": false,
                            "operator": "=",
                            "type": "address"
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": true,
                                "isPure": false,
                                "lValueRequested": true,
                                "type": "address"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 344,
                                    "type": "address[] memory",
                                    "value": "path"
                                  },
                                  "id": 412,
                                  "name": "Identifier",
                                  "src": "5285:4:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "hexvalue": "31",
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": true,
                                    "lValueRequested": false,
                                    "subdenomination": null,
                                    "token": "number",
                                    "type": "int_const 1",
                                    "value": "1"
                                  },
                                  "id": 413,
                                  "name": "Literal",
                                  "src": "5290:1:0"
                                }
                              ],
                              "id": 414,
                              "name": "IndexAccess",
                              "src": "5285:7:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "type": "address"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "commonType": {
                                      "typeIdentifier": "t_uint256",
                                      "typeString": "uint256"
                                    },
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "lValueRequested": false,
                                    "operator": "==",
                                    "type": "bool"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 333,
                                        "type": "uint256",
                                        "value": "_amount0"
                                      },
                                      "id": 415,
                                      "name": "Identifier",
                                      "src": "5295:8:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "hexvalue": "30",
                                        "isConstant": false,
                                        "isLValue": false,
                                        "isPure": true,
                                        "lValueRequested": false,
                                        "subdenomination": null,
                                        "token": "number",
                                        "type": "int_const 0",
                                        "value": "0"
                                      },
                                      "id": 416,
                                      "name": "Literal",
                                      "src": "5307:1:0"
                                    }
                                  ],
                                  "id": 417,
                                  "name": "BinaryOperation",
                                  "src": "5295:13:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 361,
                                    "type": "address",
                                    "value": "token0"
                                  },
                                  "id": 418,
                                  "name": "Identifier",
                                  "src": "5311:6:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 370,
                                    "type": "address",
                                    "value": "token1"
                                  },
                                  "id": 419,
                                  "name": "Identifier",
                                  "src": "5320:6:0"
                                }
                              ],
                              "id": 420,
                              "name": "Conditional",
                              "src": "5295:31:0"
                            }
                          ],
                          "id": 421,
                          "name": "Assignment",
                          "src": "5285:41:0"
                        }
                      ],
                      "id": 422,
                      "name": "ExpressionStatement",
                      "src": "5285:41:0"
                    },
                    {
                      "attributes": {
                        "assignments": [
                          424
                        ]
                      },
                      "children": [
                        {
                          "attributes": {
                            "constant": false,
                            "mutability": "mutable",
                            "name": "token",
                            "overrides": null,
                            "scope": 498,
                            "stateVariable": false,
                            "storageLocation": "default",
                            "type": "contract IERC20",
                            "value": null,
                            "visibility": "internal"
                          },
                          "children": [
                            {
                              "attributes": {
                                "contractScope": null,
                                "name": "IERC20",
                                "referencedDeclaration": 770,
                                "type": "contract IERC20"
                              },
                              "id": 423,
                              "name": "UserDefinedTypeName",
                              "src": "5333:6:0"
                            }
                          ],
                          "id": 424,
                          "name": "VariableDeclaration",
                          "src": "5333:12:0"
                        },
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "contract IERC20",
                            "type_conversion": true
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_address",
                                    "typeString": "address"
                                  }
                                ],
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 770,
                                "type": "type(contract IERC20)",
                                "value": "IERC20"
                              },
                              "id": 425,
                              "name": "Identifier",
                              "src": "5348:6:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "type": "address"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "commonType": {
                                      "typeIdentifier": "t_uint256",
                                      "typeString": "uint256"
                                    },
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "lValueRequested": false,
                                    "operator": "==",
                                    "type": "bool"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 333,
                                        "type": "uint256",
                                        "value": "_amount0"
                                      },
                                      "id": 426,
                                      "name": "Identifier",
                                      "src": "5355:8:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "hexvalue": "30",
                                        "isConstant": false,
                                        "isLValue": false,
                                        "isPure": true,
                                        "lValueRequested": false,
                                        "subdenomination": null,
                                        "token": "number",
                                        "type": "int_const 0",
                                        "value": "0"
                                      },
                                      "id": 427,
                                      "name": "Literal",
                                      "src": "5367:1:0"
                                    }
                                  ],
                                  "id": 428,
                                  "name": "BinaryOperation",
                                  "src": "5355:13:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 370,
                                    "type": "address",
                                    "value": "token1"
                                  },
                                  "id": 429,
                                  "name": "Identifier",
                                  "src": "5371:6:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 361,
                                    "type": "address",
                                    "value": "token0"
                                  },
                                  "id": 430,
                                  "name": "Identifier",
                                  "src": "5380:6:0"
                                }
                              ],
                              "id": 431,
                              "name": "Conditional",
                              "src": "5355:31:0"
                            }
                          ],
                          "id": 432,
                          "name": "FunctionCall",
                          "src": "5348:39:0"
                        }
                      ],
                      "id": 433,
                      "name": "VariableDeclarationStatement",
                      "src": "5333:54:0"
                    },
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "bool",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_address",
                                    "typeString": "address"
                                  },
                                  {
                                    "typeIdentifier": "t_uint256",
                                    "typeString": "uint256"
                                  }
                                ],
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "member_name": "approve",
                                "referencedDeclaration": 739,
                                "type": "function (address,uint256) external returns (bool)"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 424,
                                    "type": "contract IERC20",
                                    "value": "token"
                                  },
                                  "id": 434,
                                  "name": "Identifier",
                                  "src": "5398:5:0"
                                }
                              ],
                              "id": 436,
                              "name": "MemberAccess",
                              "src": "5398:13:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "isStructConstructorCall": false,
                                "lValueRequested": false,
                                "names": [
                                  null
                                ],
                                "tryCall": false,
                                "type": "address",
                                "type_conversion": true
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": [
                                      {
                                        "typeIdentifier": "t_contract$_IUniswapV2Router02_$1468",
                                        "typeString": "contract IUniswapV2Router02"
                                      }
                                    ],
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": true,
                                    "lValueRequested": false,
                                    "type": "type(address)"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "name": "address",
                                        "type": null
                                      },
                                      "id": 437,
                                      "name": "ElementaryTypeName",
                                      "src": "5412:7:0"
                                    }
                                  ],
                                  "id": 438,
                                  "name": "ElementaryTypeNameExpression",
                                  "src": "5412:7:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 24,
                                    "type": "contract IUniswapV2Router02",
                                    "value": "sushiRouter"
                                  },
                                  "id": 439,
                                  "name": "Identifier",
                                  "src": "5420:11:0"
                                }
                              ],
                              "id": 440,
                              "name": "FunctionCall",
                              "src": "5412:20:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 352,
                                "type": "uint256",
                                "value": "amountToken"
                              },
                              "id": 441,
                              "name": "Identifier",
                              "src": "5434:11:0"
                            }
                          ],
                          "id": 442,
                          "name": "FunctionCall",
                          "src": "5398:48:0"
                        }
                      ],
                      "id": 443,
                      "name": "ExpressionStatement",
                      "src": "5398:48:0"
                    },
                    {
                      "attributes": {
                        "assignments": [
                          445
                        ]
                      },
                      "children": [
                        {
                          "attributes": {
                            "constant": false,
                            "mutability": "mutable",
                            "name": "amountRequired",
                            "overrides": null,
                            "scope": 498,
                            "stateVariable": false,
                            "storageLocation": "default",
                            "type": "uint256",
                            "value": null,
                            "visibility": "internal"
                          },
                          "children": [
                            {
                              "attributes": {
                                "name": "uint",
                                "type": "uint256"
                              },
                              "id": 444,
                              "name": "ElementaryTypeName",
                              "src": "5453:4:0"
                            }
                          ],
                          "id": 445,
                          "name": "VariableDeclaration",
                          "src": "5453:19:0"
                        },
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": true,
                            "isPure": false,
                            "lValueRequested": false,
                            "type": "uint256"
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "isStructConstructorCall": false,
                                "lValueRequested": false,
                                "names": [
                                  null
                                ],
                                "tryCall": false,
                                "type": "uint256[] memory",
                                "type_conversion": false
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": [
                                      {
                                        "typeIdentifier": "t_address",
                                        "typeString": "address"
                                      },
                                      {
                                        "typeIdentifier": "t_uint256",
                                        "typeString": "uint256"
                                      },
                                      {
                                        "typeIdentifier": "t_array$_t_address_$dyn_memory_ptr",
                                        "typeString": "address[] memory"
                                      }
                                    ],
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "lValueRequested": false,
                                    "member_name": "getAmountsIn",
                                    "referencedDeclaration": 2271,
                                    "type": "function (address,uint256,address[] memory) view returns (uint256[] memory)"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 2272,
                                        "type": "type(library UniswapV2Library)",
                                        "value": "UniswapV2Library"
                                      },
                                      "id": 446,
                                      "name": "Identifier",
                                      "src": "5475:16:0"
                                    }
                                  ],
                                  "id": 447,
                                  "name": "MemberAccess",
                                  "src": "5475:29:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 19,
                                    "type": "address",
                                    "value": "factory"
                                  },
                                  "id": 448,
                                  "name": "Identifier",
                                  "src": "5512:7:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 352,
                                    "type": "uint256",
                                    "value": "amountToken"
                                  },
                                  "id": 449,
                                  "name": "Identifier",
                                  "src": "5528:11:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 344,
                                    "type": "address[] memory",
                                    "value": "path"
                                  },
                                  "id": 450,
                                  "name": "Identifier",
                                  "src": "5548:4:0"
                                }
                              ],
                              "id": 451,
                              "name": "FunctionCall",
                              "src": "5475:83:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "hexvalue": "30",
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": true,
                                "lValueRequested": false,
                                "subdenomination": null,
                                "token": "number",
                                "type": "int_const 0",
                                "value": "0"
                              },
                              "id": 452,
                              "name": "Literal",
                              "src": "5559:1:0"
                            }
                          ],
                          "id": 453,
                          "name": "IndexAccess",
                          "src": "5475:86:0"
                        }
                      ],
                      "id": 454,
                      "name": "VariableDeclarationStatement",
                      "src": "5453:108:0"
                    },
                    {
                      "attributes": {
                        "assignments": [
                          456
                        ]
                      },
                      "children": [
                        {
                          "attributes": {
                            "constant": false,
                            "mutability": "mutable",
                            "name": "amountReceived",
                            "overrides": null,
                            "scope": 498,
                            "stateVariable": false,
                            "storageLocation": "default",
                            "type": "uint256",
                            "value": null,
                            "visibility": "internal"
                          },
                          "children": [
                            {
                              "attributes": {
                                "name": "uint",
                                "type": "uint256"
                              },
                              "id": 455,
                              "name": "ElementaryTypeName",
                              "src": "5567:4:0"
                            }
                          ],
                          "id": 456,
                          "name": "VariableDeclaration",
                          "src": "5567:19:0"
                        },
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": true,
                            "isPure": false,
                            "lValueRequested": false,
                            "type": "uint256"
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "isStructConstructorCall": false,
                                "lValueRequested": false,
                                "names": [
                                  null
                                ],
                                "tryCall": false,
                                "type": "uint256[] memory",
                                "type_conversion": false
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": [
                                      {
                                        "typeIdentifier": "t_uint256",
                                        "typeString": "uint256"
                                      },
                                      {
                                        "typeIdentifier": "t_uint256",
                                        "typeString": "uint256"
                                      },
                                      {
                                        "typeIdentifier": "t_array$_t_address_$dyn_memory_ptr",
                                        "typeString": "address[] memory"
                                      },
                                      {
                                        "typeIdentifier": "t_address_payable",
                                        "typeString": "address payable"
                                      },
                                      {
                                        "typeIdentifier": "t_uint256",
                                        "typeString": "uint256"
                                      }
                                    ],
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "lValueRequested": false,
                                    "member_name": "swapExactTokensForTokens",
                                    "referencedDeclaration": 1246,
                                    "type": "function (uint256,uint256,address[] memory,address,uint256) external returns (uint256[] memory)"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 24,
                                        "type": "contract IUniswapV2Router02",
                                        "value": "sushiRouter"
                                      },
                                      "id": 457,
                                      "name": "Identifier",
                                      "src": "5589:11:0"
                                    }
                                  ],
                                  "id": 458,
                                  "name": "MemberAccess",
                                  "src": "5589:36:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 352,
                                    "type": "uint256",
                                    "value": "amountToken"
                                  },
                                  "id": 459,
                                  "name": "Identifier",
                                  "src": "5633:11:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 445,
                                    "type": "uint256",
                                    "value": "amountRequired"
                                  },
                                  "id": 460,
                                  "name": "Identifier",
                                  "src": "5653:14:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 344,
                                    "type": "address[] memory",
                                    "value": "path"
                                  },
                                  "id": 461,
                                  "name": "Identifier",
                                  "src": "5676:4:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "lValueRequested": false,
                                    "member_name": "sender",
                                    "referencedDeclaration": null,
                                    "type": "address payable"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": -15,
                                        "type": "msg",
                                        "value": "msg"
                                      },
                                      "id": 462,
                                      "name": "Identifier",
                                      "src": "5689:3:0"
                                    }
                                  ],
                                  "id": 463,
                                  "name": "MemberAccess",
                                  "src": "5689:10:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 22,
                                    "type": "uint256",
                                    "value": "deadline"
                                  },
                                  "id": 464,
                                  "name": "Identifier",
                                  "src": "5708:8:0"
                                }
                              ],
                              "id": 465,
                              "name": "FunctionCall",
                              "src": "5589:133:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "hexvalue": "31",
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": true,
                                "lValueRequested": false,
                                "subdenomination": null,
                                "token": "number",
                                "type": "int_const 1",
                                "value": "1"
                              },
                              "id": 466,
                              "name": "Literal",
                              "src": "5723:1:0"
                            }
                          ],
                          "id": 467,
                          "name": "IndexAccess",
                          "src": "5589:136:0"
                        }
                      ],
                      "id": 468,
                      "name": "VariableDeclarationStatement",
                      "src": "5567:158:0"
                    },
                    {
                      "attributes": {
                        "assignments": [
                          470
                        ]
                      },
                      "children": [
                        {
                          "attributes": {
                            "constant": false,
                            "mutability": "mutable",
                            "name": "otherToken",
                            "overrides": null,
                            "scope": 498,
                            "stateVariable": false,
                            "storageLocation": "default",
                            "type": "contract IERC20",
                            "value": null,
                            "visibility": "internal"
                          },
                          "children": [
                            {
                              "attributes": {
                                "contractScope": null,
                                "name": "IERC20",
                                "referencedDeclaration": 770,
                                "type": "contract IERC20"
                              },
                              "id": 469,
                              "name": "UserDefinedTypeName",
                              "src": "5732:6:0"
                            }
                          ],
                          "id": 470,
                          "name": "VariableDeclaration",
                          "src": "5732:17:0"
                        },
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "contract IERC20",
                            "type_conversion": true
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_address",
                                    "typeString": "address"
                                  }
                                ],
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 770,
                                "type": "type(contract IERC20)",
                                "value": "IERC20"
                              },
                              "id": 471,
                              "name": "Identifier",
                              "src": "5752:6:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "type": "address"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "commonType": {
                                      "typeIdentifier": "t_uint256",
                                      "typeString": "uint256"
                                    },
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "lValueRequested": false,
                                    "operator": "==",
                                    "type": "bool"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 333,
                                        "type": "uint256",
                                        "value": "_amount0"
                                      },
                                      "id": 472,
                                      "name": "Identifier",
                                      "src": "5759:8:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "hexvalue": "30",
                                        "isConstant": false,
                                        "isLValue": false,
                                        "isPure": true,
                                        "lValueRequested": false,
                                        "subdenomination": null,
                                        "token": "number",
                                        "type": "int_const 0",
                                        "value": "0"
                                      },
                                      "id": 473,
                                      "name": "Literal",
                                      "src": "5771:1:0"
                                    }
                                  ],
                                  "id": 474,
                                  "name": "BinaryOperation",
                                  "src": "5759:13:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 361,
                                    "type": "address",
                                    "value": "token0"
                                  },
                                  "id": 475,
                                  "name": "Identifier",
                                  "src": "5775:6:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 370,
                                    "type": "address",
                                    "value": "token1"
                                  },
                                  "id": 476,
                                  "name": "Identifier",
                                  "src": "5784:6:0"
                                }
                              ],
                              "id": 477,
                              "name": "Conditional",
                              "src": "5759:31:0"
                            }
                          ],
                          "id": 478,
                          "name": "FunctionCall",
                          "src": "5752:39:0"
                        }
                      ],
                      "id": 479,
                      "name": "VariableDeclarationStatement",
                      "src": "5732:59:0"
                    },
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "bool",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_address_payable",
                                    "typeString": "address payable"
                                  },
                                  {
                                    "typeIdentifier": "t_uint256",
                                    "typeString": "uint256"
                                  }
                                ],
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "member_name": "transfer",
                                "referencedDeclaration": 719,
                                "type": "function (address,uint256) external returns (bool)"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 470,
                                    "type": "contract IERC20",
                                    "value": "otherToken"
                                  },
                                  "id": 480,
                                  "name": "Identifier",
                                  "src": "5797:10:0"
                                }
                              ],
                              "id": 482,
                              "name": "MemberAccess",
                              "src": "5797:19:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "member_name": "sender",
                                "referencedDeclaration": null,
                                "type": "address payable"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": -15,
                                    "type": "msg",
                                    "value": "msg"
                                  },
                                  "id": 483,
                                  "name": "Identifier",
                                  "src": "5817:3:0"
                                }
                              ],
                              "id": 484,
                              "name": "MemberAccess",
                              "src": "5817:10:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 445,
                                "type": "uint256",
                                "value": "amountRequired"
                              },
                              "id": 485,
                              "name": "Identifier",
                              "src": "5829:14:0"
                            }
                          ],
                          "id": 486,
                          "name": "FunctionCall",
                          "src": "5797:47:0"
                        }
                      ],
                      "id": 487,
                      "name": "ExpressionStatement",
                      "src": "5797:47:0"
                    },
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "bool",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_address_payable",
                                    "typeString": "address payable"
                                  },
                                  {
                                    "typeIdentifier": "t_uint256",
                                    "typeString": "uint256"
                                  }
                                ],
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "member_name": "transfer",
                                "referencedDeclaration": 719,
                                "type": "function (address,uint256) external returns (bool)"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 470,
                                    "type": "contract IERC20",
                                    "value": "otherToken"
                                  },
                                  "id": 488,
                                  "name": "Identifier",
                                  "src": "5850:10:0"
                                }
                              ],
                              "id": 490,
                              "name": "MemberAccess",
                              "src": "5850:19:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "member_name": "origin",
                                "referencedDeclaration": null,
                                "type": "address payable"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": -26,
                                    "type": "tx",
                                    "value": "tx"
                                  },
                                  "id": 491,
                                  "name": "Identifier",
                                  "src": "5870:2:0"
                                }
                              ],
                              "id": 492,
                              "name": "MemberAccess",
                              "src": "5870:9:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "commonType": {
                                  "typeIdentifier": "t_uint256",
                                  "typeString": "uint256"
                                },
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "operator": "-",
                                "type": "uint256"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 456,
                                    "type": "uint256",
                                    "value": "amountReceived"
                                  },
                                  "id": 493,
                                  "name": "Identifier",
                                  "src": "5881:14:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 445,
                                    "type": "uint256",
                                    "value": "amountRequired"
                                  },
                                  "id": 494,
                                  "name": "Identifier",
                                  "src": "5898:14:0"
                                }
                              ],
                              "id": 495,
                              "name": "BinaryOperation",
                              "src": "5881:31:0"
                            }
                          ],
                          "id": 496,
                          "name": "FunctionCall",
                          "src": "5850:63:0"
                        }
                      ],
                      "id": 497,
                      "name": "ExpressionStatement",
                      "src": "5850:63:0"
                    }
                  ],
                  "id": 498,
                  "name": "Block",
                  "src": "4844:1074:0"
                }
              ],
              "id": 499,
              "name": "FunctionDefinition",
              "src": "4722:1196:0"
            },
            {
              "attributes": {
                "documentation": null,
                "functionSelector": "5b3bc4fe",
                "implemented": true,
                "isConstructor": false,
                "kind": "function",
                "modifiers": [
                  null
                ],
                "name": "BiswapCall",
                "overrides": null,
                "scope": 670,
                "stateMutability": "nonpayable",
                "virtual": false,
                "visibility": "external"
              },
              "children": [
                {
                  "children": [
                    {
                      "attributes": {
                        "constant": false,
                        "mutability": "mutable",
                        "name": "_sender",
                        "overrides": null,
                        "scope": 669,
                        "stateVariable": false,
                        "storageLocation": "default",
                        "type": "address",
                        "value": null,
                        "visibility": "internal"
                      },
                      "children": [
                        {
                          "attributes": {
                            "name": "address",
                            "stateMutability": "nonpayable",
                            "type": "address"
                          },
                          "id": 500,
                          "name": "ElementaryTypeName",
                          "src": "5949:7:0"
                        }
                      ],
                      "id": 501,
                      "name": "VariableDeclaration",
                      "src": "5949:15:0"
                    },
                    {
                      "attributes": {
                        "constant": false,
                        "mutability": "mutable",
                        "name": "_amount0",
                        "overrides": null,
                        "scope": 669,
                        "stateVariable": false,
                        "storageLocation": "default",
                        "type": "uint256",
                        "value": null,
                        "visibility": "internal"
                      },
                      "children": [
                        {
                          "attributes": {
                            "name": "uint",
                            "type": "uint256"
                          },
                          "id": 502,
                          "name": "ElementaryTypeName",
                          "src": "5971:4:0"
                        }
                      ],
                      "id": 503,
                      "name": "VariableDeclaration",
                      "src": "5971:13:0"
                    },
                    {
                      "attributes": {
                        "constant": false,
                        "mutability": "mutable",
                        "name": "_amount1",
                        "overrides": null,
                        "scope": 669,
                        "stateVariable": false,
                        "storageLocation": "default",
                        "type": "uint256",
                        "value": null,
                        "visibility": "internal"
                      },
                      "children": [
                        {
                          "attributes": {
                            "name": "uint",
                            "type": "uint256"
                          },
                          "id": 504,
                          "name": "ElementaryTypeName",
                          "src": "5991:4:0"
                        }
                      ],
                      "id": 505,
                      "name": "VariableDeclaration",
                      "src": "5991:13:0"
                    },
                    {
                      "attributes": {
                        "constant": false,
                        "mutability": "mutable",
                        "name": "_data",
                        "overrides": null,
                        "scope": 669,
                        "stateVariable": false,
                        "storageLocation": "calldata",
                        "type": "bytes",
                        "value": null,
                        "visibility": "internal"
                      },
                      "children": [
                        {
                          "attributes": {
                            "name": "bytes",
                            "type": "bytes"
                          },
                          "id": 506,
                          "name": "ElementaryTypeName",
                          "src": "6011:5:0"
                        }
                      ],
                      "id": 507,
                      "name": "VariableDeclaration",
                      "src": "6011:20:0"
                    }
                  ],
                  "id": 508,
                  "name": "ParameterList",
                  "src": "5943:92:0"
                },
                {
                  "attributes": {
                    "parameters": [
                      null
                    ]
                  },
                  "children": [],
                  "id": 509,
                  "name": "ParameterList",
                  "src": "6045:0:0"
                },
                {
                  "children": [
                    {
                      "attributes": {
                        "assignments": [
                          514
                        ]
                      },
                      "children": [
                        {
                          "attributes": {
                            "constant": false,
                            "mutability": "mutable",
                            "name": "path",
                            "overrides": null,
                            "scope": 668,
                            "stateVariable": false,
                            "storageLocation": "memory",
                            "type": "address[]",
                            "value": null,
                            "visibility": "internal"
                          },
                          "children": [
                            {
                              "attributes": {
                                "length": null,
                                "type": "address[]"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "name": "address",
                                    "type": "address"
                                  },
                                  "id": 512,
                                  "name": "ElementaryTypeName",
                                  "src": "6051:7:0"
                                }
                              ],
                              "id": 513,
                              "name": "ArrayTypeName",
                              "src": "6051:9:0"
                            }
                          ],
                          "id": 514,
                          "name": "VariableDeclaration",
                          "src": "6051:21:0"
                        },
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": true,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "address[] memory",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_rational_2_by_1",
                                    "typeString": "int_const 2"
                                  }
                                ],
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": true,
                                "lValueRequested": false,
                                "type": "function (uint256) pure returns (address[] memory)"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "length": null,
                                    "type": "address[]"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "name": "address",
                                        "stateMutability": "nonpayable",
                                        "type": "address"
                                      },
                                      "id": 515,
                                      "name": "ElementaryTypeName",
                                      "src": "6079:7:0"
                                    }
                                  ],
                                  "id": 516,
                                  "name": "ArrayTypeName",
                                  "src": "6079:9:0"
                                }
                              ],
                              "id": 517,
                              "name": "NewExpression",
                              "src": "6075:13:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "hexvalue": "32",
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": true,
                                "lValueRequested": false,
                                "subdenomination": null,
                                "token": "number",
                                "type": "int_const 2",
                                "value": "2"
                              },
                              "id": 518,
                              "name": "Literal",
                              "src": "6089:1:0"
                            }
                          ],
                          "id": 519,
                          "name": "FunctionCall",
                          "src": "6075:16:0"
                        }
                      ],
                      "id": 520,
                      "name": "VariableDeclarationStatement",
                      "src": "6051:40:0"
                    },
                    {
                      "attributes": {
                        "assignments": [
                          522
                        ]
                      },
                      "children": [
                        {
                          "attributes": {
                            "constant": false,
                            "mutability": "mutable",
                            "name": "amountToken",
                            "overrides": null,
                            "scope": 668,
                            "stateVariable": false,
                            "storageLocation": "default",
                            "type": "uint256",
                            "value": null,
                            "visibility": "internal"
                          },
                          "children": [
                            {
                              "attributes": {
                                "name": "uint",
                                "type": "uint256"
                              },
                              "id": 521,
                              "name": "ElementaryTypeName",
                              "src": "6097:4:0"
                            }
                          ],
                          "id": 522,
                          "name": "VariableDeclaration",
                          "src": "6097:16:0"
                        },
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "lValueRequested": false,
                            "type": "uint256"
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "commonType": {
                                  "typeIdentifier": "t_uint256",
                                  "typeString": "uint256"
                                },
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "operator": "==",
                                "type": "bool"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 503,
                                    "type": "uint256",
                                    "value": "_amount0"
                                  },
                                  "id": 523,
                                  "name": "Identifier",
                                  "src": "6116:8:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "hexvalue": "30",
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": true,
                                    "lValueRequested": false,
                                    "subdenomination": null,
                                    "token": "number",
                                    "type": "int_const 0",
                                    "value": "0"
                                  },
                                  "id": 524,
                                  "name": "Literal",
                                  "src": "6128:1:0"
                                }
                              ],
                              "id": 525,
                              "name": "BinaryOperation",
                              "src": "6116:13:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 505,
                                "type": "uint256",
                                "value": "_amount1"
                              },
                              "id": 526,
                              "name": "Identifier",
                              "src": "6132:8:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 503,
                                "type": "uint256",
                                "value": "_amount0"
                              },
                              "id": 527,
                              "name": "Identifier",
                              "src": "6143:8:0"
                            }
                          ],
                          "id": 528,
                          "name": "Conditional",
                          "src": "6116:35:0"
                        }
                      ],
                      "id": 529,
                      "name": "VariableDeclarationStatement",
                      "src": "6097:54:0"
                    },
                    {
                      "attributes": {
                        "assignments": [
                          531
                        ]
                      },
                      "children": [
                        {
                          "attributes": {
                            "constant": false,
                            "mutability": "mutable",
                            "name": "token0",
                            "overrides": null,
                            "scope": 668,
                            "stateVariable": false,
                            "storageLocation": "default",
                            "type": "address",
                            "value": null,
                            "visibility": "internal"
                          },
                          "children": [
                            {
                              "attributes": {
                                "name": "address",
                                "stateMutability": "nonpayable",
                                "type": "address"
                              },
                              "id": 530,
                              "name": "ElementaryTypeName",
                              "src": "6162:7:0"
                            }
                          ],
                          "id": 531,
                          "name": "VariableDeclaration",
                          "src": "6162:14:0"
                        },
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "arguments": [
                              null
                            ],
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "address",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  null
                                ],
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "member_name": "token0",
                                "referencedDeclaration": 1003,
                                "type": "function () view external returns (address)"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "isStructConstructorCall": false,
                                    "lValueRequested": false,
                                    "names": [
                                      null
                                    ],
                                    "tryCall": false,
                                    "type": "contract IUniswapV2Pair",
                                    "type_conversion": true
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": [
                                          {
                                            "typeIdentifier": "t_address_payable",
                                            "typeString": "address payable"
                                          }
                                        ],
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 1075,
                                        "type": "type(contract IUniswapV2Pair)",
                                        "value": "IUniswapV2Pair"
                                      },
                                      "id": 532,
                                      "name": "Identifier",
                                      "src": "6179:14:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "isConstant": false,
                                        "isLValue": false,
                                        "isPure": false,
                                        "lValueRequested": false,
                                        "member_name": "sender",
                                        "referencedDeclaration": null,
                                        "type": "address payable"
                                      },
                                      "children": [
                                        {
                                          "attributes": {
                                            "argumentTypes": null,
                                            "overloadedDeclarations": [
                                              null
                                            ],
                                            "referencedDeclaration": -15,
                                            "type": "msg",
                                            "value": "msg"
                                          },
                                          "id": 533,
                                          "name": "Identifier",
                                          "src": "6194:3:0"
                                        }
                                      ],
                                      "id": 534,
                                      "name": "MemberAccess",
                                      "src": "6194:10:0"
                                    }
                                  ],
                                  "id": 535,
                                  "name": "FunctionCall",
                                  "src": "6179:26:0"
                                }
                              ],
                              "id": 536,
                              "name": "MemberAccess",
                              "src": "6179:33:0"
                            }
                          ],
                          "id": 537,
                          "name": "FunctionCall",
                          "src": "6179:35:0"
                        }
                      ],
                      "id": 538,
                      "name": "VariableDeclarationStatement",
                      "src": "6162:52:0"
                    },
                    {
                      "attributes": {
                        "assignments": [
                          540
                        ]
                      },
                      "children": [
                        {
                          "attributes": {
                            "constant": false,
                            "mutability": "mutable",
                            "name": "token1",
                            "overrides": null,
                            "scope": 668,
                            "stateVariable": false,
                            "storageLocation": "default",
                            "type": "address",
                            "value": null,
                            "visibility": "internal"
                          },
                          "children": [
                            {
                              "attributes": {
                                "name": "address",
                                "stateMutability": "nonpayable",
                                "type": "address"
                              },
                              "id": 539,
                              "name": "ElementaryTypeName",
                              "src": "6220:7:0"
                            }
                          ],
                          "id": 540,
                          "name": "VariableDeclaration",
                          "src": "6220:14:0"
                        },
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "arguments": [
                              null
                            ],
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "address",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  null
                                ],
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "member_name": "token1",
                                "referencedDeclaration": 1008,
                                "type": "function () view external returns (address)"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "isStructConstructorCall": false,
                                    "lValueRequested": false,
                                    "names": [
                                      null
                                    ],
                                    "tryCall": false,
                                    "type": "contract IUniswapV2Pair",
                                    "type_conversion": true
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": [
                                          {
                                            "typeIdentifier": "t_address_payable",
                                            "typeString": "address payable"
                                          }
                                        ],
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 1075,
                                        "type": "type(contract IUniswapV2Pair)",
                                        "value": "IUniswapV2Pair"
                                      },
                                      "id": 541,
                                      "name": "Identifier",
                                      "src": "6237:14:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "isConstant": false,
                                        "isLValue": false,
                                        "isPure": false,
                                        "lValueRequested": false,
                                        "member_name": "sender",
                                        "referencedDeclaration": null,
                                        "type": "address payable"
                                      },
                                      "children": [
                                        {
                                          "attributes": {
                                            "argumentTypes": null,
                                            "overloadedDeclarations": [
                                              null
                                            ],
                                            "referencedDeclaration": -15,
                                            "type": "msg",
                                            "value": "msg"
                                          },
                                          "id": 542,
                                          "name": "Identifier",
                                          "src": "6252:3:0"
                                        }
                                      ],
                                      "id": 543,
                                      "name": "MemberAccess",
                                      "src": "6252:10:0"
                                    }
                                  ],
                                  "id": 544,
                                  "name": "FunctionCall",
                                  "src": "6237:26:0"
                                }
                              ],
                              "id": 545,
                              "name": "MemberAccess",
                              "src": "6237:33:0"
                            }
                          ],
                          "id": 546,
                          "name": "FunctionCall",
                          "src": "6237:35:0"
                        }
                      ],
                      "id": 547,
                      "name": "VariableDeclarationStatement",
                      "src": "6220:52:0"
                    },
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "tuple()",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_bool",
                                    "typeString": "bool"
                                  },
                                  {
                                    "typeIdentifier": "t_stringliteral_1b2638459828301e8cd6c7c02856073bacf975379e0867f689bb14feacb780c5",
                                    "typeString": "literal_string \"Unauthorized\""
                                  }
                                ],
                                "overloadedDeclarations": [
                                  -18,
                                  -18
                                ],
                                "referencedDeclaration": -18,
                                "type": "function (bool,string memory) pure",
                                "value": "require"
                              },
                              "id": 548,
                              "name": "Identifier",
                              "src": "6279:7:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "commonType": {
                                  "typeIdentifier": "t_address",
                                  "typeString": "address"
                                },
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "operator": "==",
                                "type": "bool"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "lValueRequested": false,
                                    "member_name": "sender",
                                    "referencedDeclaration": null,
                                    "type": "address payable"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": -15,
                                        "type": "msg",
                                        "value": "msg"
                                      },
                                      "id": 549,
                                      "name": "Identifier",
                                      "src": "6294:3:0"
                                    }
                                  ],
                                  "id": 550,
                                  "name": "MemberAccess",
                                  "src": "6294:10:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "isStructConstructorCall": false,
                                    "lValueRequested": false,
                                    "names": [
                                      null
                                    ],
                                    "tryCall": false,
                                    "type": "address",
                                    "type_conversion": false
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": [
                                          {
                                            "typeIdentifier": "t_address",
                                            "typeString": "address"
                                          },
                                          {
                                            "typeIdentifier": "t_address",
                                            "typeString": "address"
                                          },
                                          {
                                            "typeIdentifier": "t_address",
                                            "typeString": "address"
                                          }
                                        ],
                                        "isConstant": false,
                                        "isLValue": false,
                                        "isPure": false,
                                        "lValueRequested": false,
                                        "member_name": "pairFor",
                                        "referencedDeclaration": 1896,
                                        "type": "function (address,address,address) pure returns (address)"
                                      },
                                      "children": [
                                        {
                                          "attributes": {
                                            "argumentTypes": null,
                                            "overloadedDeclarations": [
                                              null
                                            ],
                                            "referencedDeclaration": 2272,
                                            "type": "type(library UniswapV2Library)",
                                            "value": "UniswapV2Library"
                                          },
                                          "id": 551,
                                          "name": "Identifier",
                                          "src": "6308:16:0"
                                        }
                                      ],
                                      "id": 552,
                                      "name": "MemberAccess",
                                      "src": "6308:24:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 19,
                                        "type": "address",
                                        "value": "factory"
                                      },
                                      "id": 553,
                                      "name": "Identifier",
                                      "src": "6333:7:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 531,
                                        "type": "address",
                                        "value": "token0"
                                      },
                                      "id": 554,
                                      "name": "Identifier",
                                      "src": "6342:6:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 540,
                                        "type": "address",
                                        "value": "token1"
                                      },
                                      "id": 555,
                                      "name": "Identifier",
                                      "src": "6350:6:0"
                                    }
                                  ],
                                  "id": 556,
                                  "name": "FunctionCall",
                                  "src": "6308:49:0"
                                }
                              ],
                              "id": 557,
                              "name": "BinaryOperation",
                              "src": "6294:63:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "hexvalue": "556e617574686f72697a6564",
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": true,
                                "lValueRequested": false,
                                "subdenomination": null,
                                "token": "string",
                                "type": "literal_string \"Unauthorized\"",
                                "value": "Unauthorized"
                              },
                              "id": 558,
                              "name": "Literal",
                              "src": "6366:14:0"
                            }
                          ],
                          "id": 559,
                          "name": "FunctionCall",
                          "src": "6279:107:0"
                        }
                      ],
                      "id": 560,
                      "name": "ExpressionStatement",
                      "src": "6279:107:0"
                    },
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "tuple()",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_bool",
                                    "typeString": "bool"
                                  }
                                ],
                                "overloadedDeclarations": [
                                  -18,
                                  -18
                                ],
                                "referencedDeclaration": -18,
                                "type": "function (bool) pure",
                                "value": "require"
                              },
                              "id": 561,
                              "name": "Identifier",
                              "src": "6393:7:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "commonType": {
                                  "typeIdentifier": "t_bool",
                                  "typeString": "bool"
                                },
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "operator": "||",
                                "type": "bool"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "commonType": {
                                      "typeIdentifier": "t_uint256",
                                      "typeString": "uint256"
                                    },
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "lValueRequested": false,
                                    "operator": "==",
                                    "type": "bool"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 503,
                                        "type": "uint256",
                                        "value": "_amount0"
                                      },
                                      "id": 562,
                                      "name": "Identifier",
                                      "src": "6401:8:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "hexvalue": "30",
                                        "isConstant": false,
                                        "isLValue": false,
                                        "isPure": true,
                                        "lValueRequested": false,
                                        "subdenomination": null,
                                        "token": "number",
                                        "type": "int_const 0",
                                        "value": "0"
                                      },
                                      "id": 563,
                                      "name": "Literal",
                                      "src": "6413:1:0"
                                    }
                                  ],
                                  "id": 564,
                                  "name": "BinaryOperation",
                                  "src": "6401:13:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "commonType": {
                                      "typeIdentifier": "t_uint256",
                                      "typeString": "uint256"
                                    },
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "lValueRequested": false,
                                    "operator": "==",
                                    "type": "bool"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 505,
                                        "type": "uint256",
                                        "value": "_amount1"
                                      },
                                      "id": 565,
                                      "name": "Identifier",
                                      "src": "6418:8:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "hexvalue": "30",
                                        "isConstant": false,
                                        "isLValue": false,
                                        "isPure": true,
                                        "lValueRequested": false,
                                        "subdenomination": null,
                                        "token": "number",
                                        "type": "int_const 0",
                                        "value": "0"
                                      },
                                      "id": 566,
                                      "name": "Literal",
                                      "src": "6430:1:0"
                                    }
                                  ],
                                  "id": 567,
                                  "name": "BinaryOperation",
                                  "src": "6418:13:0"
                                }
                              ],
                              "id": 568,
                              "name": "BinaryOperation",
                              "src": "6401:30:0"
                            }
                          ],
                          "id": 569,
                          "name": "FunctionCall",
                          "src": "6393:39:0"
                        }
                      ],
                      "id": 570,
                      "name": "ExpressionStatement",
                      "src": "6393:39:0"
                    },
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "lValueRequested": false,
                            "operator": "=",
                            "type": "address"
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": true,
                                "isPure": false,
                                "lValueRequested": true,
                                "type": "address"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 514,
                                    "type": "address[] memory",
                                    "value": "path"
                                  },
                                  "id": 571,
                                  "name": "Identifier",
                                  "src": "6439:4:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "hexvalue": "30",
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": true,
                                    "lValueRequested": false,
                                    "subdenomination": null,
                                    "token": "number",
                                    "type": "int_const 0",
                                    "value": "0"
                                  },
                                  "id": 572,
                                  "name": "Literal",
                                  "src": "6444:1:0"
                                }
                              ],
                              "id": 573,
                              "name": "IndexAccess",
                              "src": "6439:7:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "type": "address"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "commonType": {
                                      "typeIdentifier": "t_uint256",
                                      "typeString": "uint256"
                                    },
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "lValueRequested": false,
                                    "operator": "==",
                                    "type": "bool"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 503,
                                        "type": "uint256",
                                        "value": "_amount0"
                                      },
                                      "id": 574,
                                      "name": "Identifier",
                                      "src": "6449:8:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "hexvalue": "30",
                                        "isConstant": false,
                                        "isLValue": false,
                                        "isPure": true,
                                        "lValueRequested": false,
                                        "subdenomination": null,
                                        "token": "number",
                                        "type": "int_const 0",
                                        "value": "0"
                                      },
                                      "id": 575,
                                      "name": "Literal",
                                      "src": "6461:1:0"
                                    }
                                  ],
                                  "id": 576,
                                  "name": "BinaryOperation",
                                  "src": "6449:13:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 540,
                                    "type": "address",
                                    "value": "token1"
                                  },
                                  "id": 577,
                                  "name": "Identifier",
                                  "src": "6465:6:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 531,
                                    "type": "address",
                                    "value": "token0"
                                  },
                                  "id": 578,
                                  "name": "Identifier",
                                  "src": "6474:6:0"
                                }
                              ],
                              "id": 579,
                              "name": "Conditional",
                              "src": "6449:31:0"
                            }
                          ],
                          "id": 580,
                          "name": "Assignment",
                          "src": "6439:41:0"
                        }
                      ],
                      "id": 581,
                      "name": "ExpressionStatement",
                      "src": "6439:41:0"
                    },
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "lValueRequested": false,
                            "operator": "=",
                            "type": "address"
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": true,
                                "isPure": false,
                                "lValueRequested": true,
                                "type": "address"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 514,
                                    "type": "address[] memory",
                                    "value": "path"
                                  },
                                  "id": 582,
                                  "name": "Identifier",
                                  "src": "6486:4:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "hexvalue": "31",
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": true,
                                    "lValueRequested": false,
                                    "subdenomination": null,
                                    "token": "number",
                                    "type": "int_const 1",
                                    "value": "1"
                                  },
                                  "id": 583,
                                  "name": "Literal",
                                  "src": "6491:1:0"
                                }
                              ],
                              "id": 584,
                              "name": "IndexAccess",
                              "src": "6486:7:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "type": "address"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "commonType": {
                                      "typeIdentifier": "t_uint256",
                                      "typeString": "uint256"
                                    },
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "lValueRequested": false,
                                    "operator": "==",
                                    "type": "bool"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 503,
                                        "type": "uint256",
                                        "value": "_amount0"
                                      },
                                      "id": 585,
                                      "name": "Identifier",
                                      "src": "6496:8:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "hexvalue": "30",
                                        "isConstant": false,
                                        "isLValue": false,
                                        "isPure": true,
                                        "lValueRequested": false,
                                        "subdenomination": null,
                                        "token": "number",
                                        "type": "int_const 0",
                                        "value": "0"
                                      },
                                      "id": 586,
                                      "name": "Literal",
                                      "src": "6508:1:0"
                                    }
                                  ],
                                  "id": 587,
                                  "name": "BinaryOperation",
                                  "src": "6496:13:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 531,
                                    "type": "address",
                                    "value": "token0"
                                  },
                                  "id": 588,
                                  "name": "Identifier",
                                  "src": "6512:6:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 540,
                                    "type": "address",
                                    "value": "token1"
                                  },
                                  "id": 589,
                                  "name": "Identifier",
                                  "src": "6521:6:0"
                                }
                              ],
                              "id": 590,
                              "name": "Conditional",
                              "src": "6496:31:0"
                            }
                          ],
                          "id": 591,
                          "name": "Assignment",
                          "src": "6486:41:0"
                        }
                      ],
                      "id": 592,
                      "name": "ExpressionStatement",
                      "src": "6486:41:0"
                    },
                    {
                      "attributes": {
                        "assignments": [
                          594
                        ]
                      },
                      "children": [
                        {
                          "attributes": {
                            "constant": false,
                            "mutability": "mutable",
                            "name": "token",
                            "overrides": null,
                            "scope": 668,
                            "stateVariable": false,
                            "storageLocation": "default",
                            "type": "contract IERC20",
                            "value": null,
                            "visibility": "internal"
                          },
                          "children": [
                            {
                              "attributes": {
                                "contractScope": null,
                                "name": "IERC20",
                                "referencedDeclaration": 770,
                                "type": "contract IERC20"
                              },
                              "id": 593,
                              "name": "UserDefinedTypeName",
                              "src": "6534:6:0"
                            }
                          ],
                          "id": 594,
                          "name": "VariableDeclaration",
                          "src": "6534:12:0"
                        },
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "contract IERC20",
                            "type_conversion": true
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_address",
                                    "typeString": "address"
                                  }
                                ],
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 770,
                                "type": "type(contract IERC20)",
                                "value": "IERC20"
                              },
                              "id": 595,
                              "name": "Identifier",
                              "src": "6549:6:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "type": "address"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "commonType": {
                                      "typeIdentifier": "t_uint256",
                                      "typeString": "uint256"
                                    },
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "lValueRequested": false,
                                    "operator": "==",
                                    "type": "bool"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 503,
                                        "type": "uint256",
                                        "value": "_amount0"
                                      },
                                      "id": 596,
                                      "name": "Identifier",
                                      "src": "6556:8:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "hexvalue": "30",
                                        "isConstant": false,
                                        "isLValue": false,
                                        "isPure": true,
                                        "lValueRequested": false,
                                        "subdenomination": null,
                                        "token": "number",
                                        "type": "int_const 0",
                                        "value": "0"
                                      },
                                      "id": 597,
                                      "name": "Literal",
                                      "src": "6568:1:0"
                                    }
                                  ],
                                  "id": 598,
                                  "name": "BinaryOperation",
                                  "src": "6556:13:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 540,
                                    "type": "address",
                                    "value": "token1"
                                  },
                                  "id": 599,
                                  "name": "Identifier",
                                  "src": "6572:6:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 531,
                                    "type": "address",
                                    "value": "token0"
                                  },
                                  "id": 600,
                                  "name": "Identifier",
                                  "src": "6581:6:0"
                                }
                              ],
                              "id": 601,
                              "name": "Conditional",
                              "src": "6556:31:0"
                            }
                          ],
                          "id": 602,
                          "name": "FunctionCall",
                          "src": "6549:39:0"
                        }
                      ],
                      "id": 603,
                      "name": "VariableDeclarationStatement",
                      "src": "6534:54:0"
                    },
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "bool",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_address",
                                    "typeString": "address"
                                  },
                                  {
                                    "typeIdentifier": "t_uint256",
                                    "typeString": "uint256"
                                  }
                                ],
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "member_name": "approve",
                                "referencedDeclaration": 739,
                                "type": "function (address,uint256) external returns (bool)"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 594,
                                    "type": "contract IERC20",
                                    "value": "token"
                                  },
                                  "id": 604,
                                  "name": "Identifier",
                                  "src": "6599:5:0"
                                }
                              ],
                              "id": 606,
                              "name": "MemberAccess",
                              "src": "6599:13:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "isStructConstructorCall": false,
                                "lValueRequested": false,
                                "names": [
                                  null
                                ],
                                "tryCall": false,
                                "type": "address",
                                "type_conversion": true
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": [
                                      {
                                        "typeIdentifier": "t_contract$_IUniswapV2Router02_$1468",
                                        "typeString": "contract IUniswapV2Router02"
                                      }
                                    ],
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": true,
                                    "lValueRequested": false,
                                    "type": "type(address)"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "name": "address",
                                        "type": null
                                      },
                                      "id": 607,
                                      "name": "ElementaryTypeName",
                                      "src": "6613:7:0"
                                    }
                                  ],
                                  "id": 608,
                                  "name": "ElementaryTypeNameExpression",
                                  "src": "6613:7:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 24,
                                    "type": "contract IUniswapV2Router02",
                                    "value": "sushiRouter"
                                  },
                                  "id": 609,
                                  "name": "Identifier",
                                  "src": "6621:11:0"
                                }
                              ],
                              "id": 610,
                              "name": "FunctionCall",
                              "src": "6613:20:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 522,
                                "type": "uint256",
                                "value": "amountToken"
                              },
                              "id": 611,
                              "name": "Identifier",
                              "src": "6635:11:0"
                            }
                          ],
                          "id": 612,
                          "name": "FunctionCall",
                          "src": "6599:48:0"
                        }
                      ],
                      "id": 613,
                      "name": "ExpressionStatement",
                      "src": "6599:48:0"
                    },
                    {
                      "attributes": {
                        "assignments": [
                          615
                        ]
                      },
                      "children": [
                        {
                          "attributes": {
                            "constant": false,
                            "mutability": "mutable",
                            "name": "amountRequired",
                            "overrides": null,
                            "scope": 668,
                            "stateVariable": false,
                            "storageLocation": "default",
                            "type": "uint256",
                            "value": null,
                            "visibility": "internal"
                          },
                          "children": [
                            {
                              "attributes": {
                                "name": "uint",
                                "type": "uint256"
                              },
                              "id": 614,
                              "name": "ElementaryTypeName",
                              "src": "6654:4:0"
                            }
                          ],
                          "id": 615,
                          "name": "VariableDeclaration",
                          "src": "6654:19:0"
                        },
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": true,
                            "isPure": false,
                            "lValueRequested": false,
                            "type": "uint256"
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "isStructConstructorCall": false,
                                "lValueRequested": false,
                                "names": [
                                  null
                                ],
                                "tryCall": false,
                                "type": "uint256[] memory",
                                "type_conversion": false
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": [
                                      {
                                        "typeIdentifier": "t_address",
                                        "typeString": "address"
                                      },
                                      {
                                        "typeIdentifier": "t_uint256",
                                        "typeString": "uint256"
                                      },
                                      {
                                        "typeIdentifier": "t_array$_t_address_$dyn_memory_ptr",
                                        "typeString": "address[] memory"
                                      }
                                    ],
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "lValueRequested": false,
                                    "member_name": "getAmountsIn",
                                    "referencedDeclaration": 2271,
                                    "type": "function (address,uint256,address[] memory) view returns (uint256[] memory)"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 2272,
                                        "type": "type(library UniswapV2Library)",
                                        "value": "UniswapV2Library"
                                      },
                                      "id": 616,
                                      "name": "Identifier",
                                      "src": "6676:16:0"
                                    }
                                  ],
                                  "id": 617,
                                  "name": "MemberAccess",
                                  "src": "6676:29:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 19,
                                    "type": "address",
                                    "value": "factory"
                                  },
                                  "id": 618,
                                  "name": "Identifier",
                                  "src": "6713:7:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 522,
                                    "type": "uint256",
                                    "value": "amountToken"
                                  },
                                  "id": 619,
                                  "name": "Identifier",
                                  "src": "6729:11:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 514,
                                    "type": "address[] memory",
                                    "value": "path"
                                  },
                                  "id": 620,
                                  "name": "Identifier",
                                  "src": "6749:4:0"
                                }
                              ],
                              "id": 621,
                              "name": "FunctionCall",
                              "src": "6676:83:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "hexvalue": "30",
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": true,
                                "lValueRequested": false,
                                "subdenomination": null,
                                "token": "number",
                                "type": "int_const 0",
                                "value": "0"
                              },
                              "id": 622,
                              "name": "Literal",
                              "src": "6760:1:0"
                            }
                          ],
                          "id": 623,
                          "name": "IndexAccess",
                          "src": "6676:86:0"
                        }
                      ],
                      "id": 624,
                      "name": "VariableDeclarationStatement",
                      "src": "6654:108:0"
                    },
                    {
                      "attributes": {
                        "assignments": [
                          626
                        ]
                      },
                      "children": [
                        {
                          "attributes": {
                            "constant": false,
                            "mutability": "mutable",
                            "name": "amountReceived",
                            "overrides": null,
                            "scope": 668,
                            "stateVariable": false,
                            "storageLocation": "default",
                            "type": "uint256",
                            "value": null,
                            "visibility": "internal"
                          },
                          "children": [
                            {
                              "attributes": {
                                "name": "uint",
                                "type": "uint256"
                              },
                              "id": 625,
                              "name": "ElementaryTypeName",
                              "src": "6768:4:0"
                            }
                          ],
                          "id": 626,
                          "name": "VariableDeclaration",
                          "src": "6768:19:0"
                        },
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": true,
                            "isPure": false,
                            "lValueRequested": false,
                            "type": "uint256"
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "isStructConstructorCall": false,
                                "lValueRequested": false,
                                "names": [
                                  null
                                ],
                                "tryCall": false,
                                "type": "uint256[] memory",
                                "type_conversion": false
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": [
                                      {
                                        "typeIdentifier": "t_uint256",
                                        "typeString": "uint256"
                                      },
                                      {
                                        "typeIdentifier": "t_uint256",
                                        "typeString": "uint256"
                                      },
                                      {
                                        "typeIdentifier": "t_array$_t_address_$dyn_memory_ptr",
                                        "typeString": "address[] memory"
                                      },
                                      {
                                        "typeIdentifier": "t_address_payable",
                                        "typeString": "address payable"
                                      },
                                      {
                                        "typeIdentifier": "t_uint256",
                                        "typeString": "uint256"
                                      }
                                    ],
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "lValueRequested": false,
                                    "member_name": "swapExactTokensForTokens",
                                    "referencedDeclaration": 1246,
                                    "type": "function (uint256,uint256,address[] memory,address,uint256) external returns (uint256[] memory)"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 24,
                                        "type": "contract IUniswapV2Router02",
                                        "value": "sushiRouter"
                                      },
                                      "id": 627,
                                      "name": "Identifier",
                                      "src": "6790:11:0"
                                    }
                                  ],
                                  "id": 628,
                                  "name": "MemberAccess",
                                  "src": "6790:36:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 522,
                                    "type": "uint256",
                                    "value": "amountToken"
                                  },
                                  "id": 629,
                                  "name": "Identifier",
                                  "src": "6834:11:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 615,
                                    "type": "uint256",
                                    "value": "amountRequired"
                                  },
                                  "id": 630,
                                  "name": "Identifier",
                                  "src": "6854:14:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 514,
                                    "type": "address[] memory",
                                    "value": "path"
                                  },
                                  "id": 631,
                                  "name": "Identifier",
                                  "src": "6877:4:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "lValueRequested": false,
                                    "member_name": "sender",
                                    "referencedDeclaration": null,
                                    "type": "address payable"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": -15,
                                        "type": "msg",
                                        "value": "msg"
                                      },
                                      "id": 632,
                                      "name": "Identifier",
                                      "src": "6890:3:0"
                                    }
                                  ],
                                  "id": 633,
                                  "name": "MemberAccess",
                                  "src": "6890:10:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 22,
                                    "type": "uint256",
                                    "value": "deadline"
                                  },
                                  "id": 634,
                                  "name": "Identifier",
                                  "src": "6909:8:0"
                                }
                              ],
                              "id": 635,
                              "name": "FunctionCall",
                              "src": "6790:133:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "hexvalue": "31",
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": true,
                                "lValueRequested": false,
                                "subdenomination": null,
                                "token": "number",
                                "type": "int_const 1",
                                "value": "1"
                              },
                              "id": 636,
                              "name": "Literal",
                              "src": "6924:1:0"
                            }
                          ],
                          "id": 637,
                          "name": "IndexAccess",
                          "src": "6790:136:0"
                        }
                      ],
                      "id": 638,
                      "name": "VariableDeclarationStatement",
                      "src": "6768:158:0"
                    },
                    {
                      "attributes": {
                        "assignments": [
                          640
                        ]
                      },
                      "children": [
                        {
                          "attributes": {
                            "constant": false,
                            "mutability": "mutable",
                            "name": "otherToken",
                            "overrides": null,
                            "scope": 668,
                            "stateVariable": false,
                            "storageLocation": "default",
                            "type": "contract IERC20",
                            "value": null,
                            "visibility": "internal"
                          },
                          "children": [
                            {
                              "attributes": {
                                "contractScope": null,
                                "name": "IERC20",
                                "referencedDeclaration": 770,
                                "type": "contract IERC20"
                              },
                              "id": 639,
                              "name": "UserDefinedTypeName",
                              "src": "6933:6:0"
                            }
                          ],
                          "id": 640,
                          "name": "VariableDeclaration",
                          "src": "6933:17:0"
                        },
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "contract IERC20",
                            "type_conversion": true
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_address",
                                    "typeString": "address"
                                  }
                                ],
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 770,
                                "type": "type(contract IERC20)",
                                "value": "IERC20"
                              },
                              "id": 641,
                              "name": "Identifier",
                              "src": "6953:6:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "type": "address"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "commonType": {
                                      "typeIdentifier": "t_uint256",
                                      "typeString": "uint256"
                                    },
                                    "isConstant": false,
                                    "isLValue": false,
                                    "isPure": false,
                                    "lValueRequested": false,
                                    "operator": "==",
                                    "type": "bool"
                                  },
                                  "children": [
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "overloadedDeclarations": [
                                          null
                                        ],
                                        "referencedDeclaration": 503,
                                        "type": "uint256",
                                        "value": "_amount0"
                                      },
                                      "id": 642,
                                      "name": "Identifier",
                                      "src": "6960:8:0"
                                    },
                                    {
                                      "attributes": {
                                        "argumentTypes": null,
                                        "hexvalue": "30",
                                        "isConstant": false,
                                        "isLValue": false,
                                        "isPure": true,
                                        "lValueRequested": false,
                                        "subdenomination": null,
                                        "token": "number",
                                        "type": "int_const 0",
                                        "value": "0"
                                      },
                                      "id": 643,
                                      "name": "Literal",
                                      "src": "6972:1:0"
                                    }
                                  ],
                                  "id": 644,
                                  "name": "BinaryOperation",
                                  "src": "6960:13:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 531,
                                    "type": "address",
                                    "value": "token0"
                                  },
                                  "id": 645,
                                  "name": "Identifier",
                                  "src": "6976:6:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 540,
                                    "type": "address",
                                    "value": "token1"
                                  },
                                  "id": 646,
                                  "name": "Identifier",
                                  "src": "6985:6:0"
                                }
                              ],
                              "id": 647,
                              "name": "Conditional",
                              "src": "6960:31:0"
                            }
                          ],
                          "id": 648,
                          "name": "FunctionCall",
                          "src": "6953:39:0"
                        }
                      ],
                      "id": 649,
                      "name": "VariableDeclarationStatement",
                      "src": "6933:59:0"
                    },
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "bool",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_address_payable",
                                    "typeString": "address payable"
                                  },
                                  {
                                    "typeIdentifier": "t_uint256",
                                    "typeString": "uint256"
                                  }
                                ],
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "member_name": "transfer",
                                "referencedDeclaration": 719,
                                "type": "function (address,uint256) external returns (bool)"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 640,
                                    "type": "contract IERC20",
                                    "value": "otherToken"
                                  },
                                  "id": 650,
                                  "name": "Identifier",
                                  "src": "6998:10:0"
                                }
                              ],
                              "id": 652,
                              "name": "MemberAccess",
                              "src": "6998:19:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "member_name": "sender",
                                "referencedDeclaration": null,
                                "type": "address payable"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": -15,
                                    "type": "msg",
                                    "value": "msg"
                                  },
                                  "id": 653,
                                  "name": "Identifier",
                                  "src": "7018:3:0"
                                }
                              ],
                              "id": 654,
                              "name": "MemberAccess",
                              "src": "7018:10:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "overloadedDeclarations": [
                                  null
                                ],
                                "referencedDeclaration": 615,
                                "type": "uint256",
                                "value": "amountRequired"
                              },
                              "id": 655,
                              "name": "Identifier",
                              "src": "7030:14:0"
                            }
                          ],
                          "id": 656,
                          "name": "FunctionCall",
                          "src": "6998:47:0"
                        }
                      ],
                      "id": 657,
                      "name": "ExpressionStatement",
                      "src": "6998:47:0"
                    },
                    {
                      "children": [
                        {
                          "attributes": {
                            "argumentTypes": null,
                            "isConstant": false,
                            "isLValue": false,
                            "isPure": false,
                            "isStructConstructorCall": false,
                            "lValueRequested": false,
                            "names": [
                              null
                            ],
                            "tryCall": false,
                            "type": "bool",
                            "type_conversion": false
                          },
                          "children": [
                            {
                              "attributes": {
                                "argumentTypes": [
                                  {
                                    "typeIdentifier": "t_address_payable",
                                    "typeString": "address payable"
                                  },
                                  {
                                    "typeIdentifier": "t_uint256",
                                    "typeString": "uint256"
                                  }
                                ],
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "member_name": "transfer",
                                "referencedDeclaration": 719,
                                "type": "function (address,uint256) external returns (bool)"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 640,
                                    "type": "contract IERC20",
                                    "value": "otherToken"
                                  },
                                  "id": 658,
                                  "name": "Identifier",
                                  "src": "7051:10:0"
                                }
                              ],
                              "id": 660,
                              "name": "MemberAccess",
                              "src": "7051:19:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "member_name": "origin",
                                "referencedDeclaration": null,
                                "type": "address payable"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": -26,
                                    "type": "tx",
                                    "value": "tx"
                                  },
                                  "id": 661,
                                  "name": "Identifier",
                                  "src": "7071:2:0"
                                }
                              ],
                              "id": 662,
                              "name": "MemberAccess",
                              "src": "7071:9:0"
                            },
                            {
                              "attributes": {
                                "argumentTypes": null,
                                "commonType": {
                                  "typeIdentifier": "t_uint256",
                                  "typeString": "uint256"
                                },
                                "isConstant": false,
                                "isLValue": false,
                                "isPure": false,
                                "lValueRequested": false,
                                "operator": "-",
                                "type": "uint256"
                              },
                              "children": [
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 626,
                                    "type": "uint256",
                                    "value": "amountReceived"
                                  },
                                  "id": 663,
                                  "name": "Identifier",
                                  "src": "7082:14:0"
                                },
                                {
                                  "attributes": {
                                    "argumentTypes": null,
                                    "overloadedDeclarations": [
                                      null
                                    ],
                                    "referencedDeclaration": 615,
                                    "type": "uint256",
                                    "value": "amountRequired"
                                  },
                                  "id": 664,
                                  "name": "Identifier",
                                  "src": "7099:14:0"
                                }
                              ],
                              "id": 665,
                              "name": "BinaryOperation",
                              "src": "7082:31:0"
                            }
                          ],
                          "id": 666,
                          "name": "FunctionCall",
                          "src": "7051:63:0"
                        }
                      ],
                      "id": 667,
                      "name": "ExpressionStatement",
                      "src": "7051:63:0"
                    }
                  ],
                  "id": 668,
                  "name": "Block",
                  "src": "6045:1074:0"
                }
              ],
              "id": 669,
              "name": "FunctionDefinition",
              "src": "5924:1195:0"
            }
          ],
          "id": 670,
          "name": "ContractDefinition",
          "src": "334:9510:0"
        }
      ],
      "id": 671,
      "name": "SourceUnit",
      "src": "32:9812:0"
    },
    "compiler": {
      "name": "solc",
      "version": "0.6.6+commit.6c089d02.Emscripten.clang"
    },
    "networks": {},
    "schemaVersion": "3.4.1",
    "updatedAt": "2021-09-18T05:40:23.691Z",
    "devdoc": {
      "methods": {
        "owner()": {
          "details": "Returns the address of the current owner."
        },
        "renounceOwnership()": {
          "details": "Leaves the contract without owner. It will not be possible to call `onlyOwner` functions anymore. Can only be called by the current owner.     * NOTE: Renouncing ownership will leave the contract without an owner, thereby removing any functionality that is only available to the owner."
        },
        "transferOwnership(address)": {
          "details": "Transfers ownership of the contract to a new account (`newOwner`). Can only be called by the current owner."
        }
      }
    },
    "userdoc": {
      "methods": {}
    }
  };


module.exports = {
    ABI,
  };