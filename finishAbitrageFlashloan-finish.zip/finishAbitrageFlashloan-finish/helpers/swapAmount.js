const swapAmount = 20;

module.exports = swapAmount;