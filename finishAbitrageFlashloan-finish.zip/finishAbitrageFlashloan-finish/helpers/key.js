const key = "37ACJK0978235626ACHWEKCWD3839";

module.exports = key;